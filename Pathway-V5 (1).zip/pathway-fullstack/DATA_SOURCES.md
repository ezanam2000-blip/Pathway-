# Pathway starter data sources

Checked: 2026-09-17

- Ivey AEO / HBA — https://www.ivey.uwo.ca/hba/admissions/secondary-school-students/
- Rotman Commerce (Ontario applicants) — https://rotmancommerce.utoronto.ca/future-students/ontario-applicants/
- Rotman Commerce important dates — https://rotmancommerce.utoronto.ca/future-students/important-dates/
- Queen's Ontario admission requirements — https://www.queensu.ca/admission/applying/admission-requirements/ontario
- Queen's undergraduate admission deadlines — https://www.queensu.ca/admission/applying/dates-deadlines
- Queen's Major Admission Awards — https://www.queensu.ca/registrar/financial-aid/application-required/future-students/major-awards
- 2027 Loran Award application — https://loranscholar.ca/the-program/how-to-apply/
- Loran Award structure/value — https://loranscholar.ca/the-program/how-it-works/

Records should be re-checked before each admission cycle and whenever a source page changes materially.
