from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import smtplib
import time
from collections import defaultdict, deque
from email.message import EmailMessage
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal, Optional

from fastapi import Cookie, Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("PATHWAY_DB_PATH", ROOT / "pathway.db"))
SESSION_COOKIE = "pathway_session"
SESSION_DAYS = 30
PBKDF2_ITERATIONS = 310_000
COOKIE_SECURE = os.getenv("PATHWAY_COOKIE_SECURE", "0") == "1"
APP_BASE_URL = os.getenv("PATHWAY_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
SMTP_HOST = os.getenv("PATHWAY_SMTP_HOST", "").strip()
SMTP_PORT = int(os.getenv("PATHWAY_SMTP_PORT", "587"))
SMTP_USERNAME = os.getenv("PATHWAY_SMTP_USERNAME", "").strip()
SMTP_PASSWORD = os.getenv("PATHWAY_SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("PATHWAY_SMTP_FROM", SMTP_USERNAME or "Pathway <no-reply@pathway.local>")
SMTP_USE_TLS = os.getenv("PATHWAY_SMTP_USE_TLS", "1") == "1"
EMAIL_TOKEN_HOURS = int(os.getenv("PATHWAY_EMAIL_TOKEN_HOURS", "24"))
RESET_TOKEN_HOURS = int(os.getenv("PATHWAY_RESET_TOKEN_HOURS", "1"))
STALE_DAYS = int(os.getenv("PATHWAY_STALE_DAYS", "180"))
APP_VERSION = "1.1.0"
OUTBOX_PATH = Path(os.getenv("PATHWAY_OUTBOX_PATH", ROOT / "dev-email-outbox.log"))

app = FastAPI(title="Pathway API", version=APP_VERSION, docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def dumps(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def loads(value: Optional[str], default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return default


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        PBKDF2_ITERATIONS,
        base64.urlsafe_b64encode(salt).decode().rstrip("="),
        base64.urlsafe_b64encode(digest).decode().rstrip("="),
    )


def _b64decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        salt = _b64decode(salt_b64)
        expected = _b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def serialize_user(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "email": row["email"],
        "grade": row["grade"],
        "interests": loads(row["interests_json"], []),
        "goal": row["goal"],
        "onboarding_completed": bool(row["onboarding_completed"]),
        "is_admin": bool(row["is_admin"]),
        "email_verified": bool(row["email_verified"]) if "email_verified" in row.keys() else False,
        "created_at": row["created_at"],
    }


def content_row_to_dict(row: sqlite3.Row, content_type: str) -> dict[str, Any]:
    base = {
        "id": row["id"],
        "type": content_type,
        "title": row["title"],
        "subtitle": row["subtitle"],
        "description": row["description"],
        "tags": loads(row["tags_json"], []),
        "source_url": row["source_url"],
        "status": row["status"],
        "last_verified_date": row["last_verified_date"],
        "featured": bool(row["featured"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }
    if content_type == "career":
        base.update({
            "education": row["education"],
            "day_to_day": row["day_to_day"],
        })
    elif content_type == "program":
        base.update({
            "university": row["university"],
            "field": row["field"],
            "province": row["province"],
            "requirements": loads(row["requirements_json"], []),
            "deadline": row["deadline"],
            "supplemental": row["supplemental"],
        })
    elif content_type == "scholarship":
        base.update({
            "organization": row["organization"],
            "amount": row["amount"],
            "eligibility": row["eligibility"],
            "deadline": row["deadline"],
        })
    return base



def apply_staleness(con: sqlite3.Connection) -> None:
    cutoff = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).date().isoformat()
    for table in ("programs", "scholarships"):
        con.execute(
            f"UPDATE {table} SET status='needs_review',updated_at=? WHERE status='verified' AND last_verified_date IS NOT NULL AND last_verified_date < ?",
            (now_iso(), cutoff),
        )

def init_db() -> None:
    con = connect()
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            grade TEXT DEFAULT '12',
            interests_json TEXT NOT NULL DEFAULT '[]',
            goal TEXT DEFAULT 'Explore careers',
            onboarding_completed INTEGER NOT NULL DEFAULT 0,
            is_admin INTEGER NOT NULL DEFAULT 0,
            email_verified INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS auth_tokens (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            purpose TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            used_at TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS careers (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            description TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            education TEXT NOT NULL DEFAULT '',
            day_to_day TEXT NOT NULL DEFAULT '',
            source_url TEXT,
            status TEXT NOT NULL DEFAULT 'needs_review',
            last_verified_date TEXT,
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS programs (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            university TEXT NOT NULL,
            field TEXT NOT NULL,
            province TEXT NOT NULL DEFAULT 'Ontario',
            description TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            requirements_json TEXT NOT NULL DEFAULT '[]',
            deadline TEXT,
            supplemental TEXT,
            source_url TEXT,
            status TEXT NOT NULL DEFAULT 'needs_review',
            last_verified_date TEXT,
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS scholarships (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            organization TEXT NOT NULL DEFAULT '',
            amount TEXT,
            description TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            eligibility TEXT NOT NULL DEFAULT '',
            deadline TEXT,
            source_url TEXT,
            status TEXT NOT NULL DEFAULT 'needs_review',
            last_verified_date TEXT,
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS saved_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            item_type TEXT NOT NULL,
            item_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, item_type, item_id)
        );
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            program_id TEXT,
            institution TEXT NOT NULL,
            program_name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Researching',
            deadline TEXT,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS application_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            completed INTEGER NOT NULL DEFAULT 0,
            due_date TEXT,
            sort_order INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS content_change_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            item_type TEXT NOT NULL,
            item_id TEXT NOT NULL,
            action TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    # Lightweight migration for databases created by earlier Pathway versions.
    columns = {r["name"] for r in con.execute("PRAGMA table_info(users)").fetchall()}
    if "email_verified" not in columns:
        con.execute("ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0")
    con.commit()
    seed_content(con)
    apply_staleness(con)
    con.commit()
    seed_admin(con)
    con.close()


def seed_content(con: sqlite3.Connection) -> None:
    """Seed a small launch dataset. Admission/scholarship records marked verified below
    were checked against the listed official source on 2026-09-17.
    """
    ts = now_iso()
    careers = [
        ("career-finance", "Investment Banking", "Business & Finance", "Analyze companies, financing, transactions, and capital markets.", ["Business & Finance", "Math", "Leadership"], "Common routes include commerce, business, economics, and finance programs.", "Research companies, build financial analysis, prepare presentations, and support transactions."),
        ("career-software", "Software Engineering", "Technology", "Design, build, test, and improve software products and systems.", ["Technology", "Problem Solving", "Math"], "Common routes include computer science, software engineering, and related technical programs.", "Write code, review systems, debug problems, collaborate with product teams, and ship features."),
        ("career-health", "Health Sciences", "Medicine & Health", "Explore work focused on human health, research, and patient care.", ["Medicine & Health", "Science", "Working with People"], "Education varies by career and may include undergraduate, college, or professional programs.", "Work may involve patient care, research, health systems, laboratory work, or community support."),
        ("career-law", "Law & Policy", "Law & Government", "Work with legal systems, policy, research, advocacy, and public institutions.", ["Law", "Writing", "Communication"], "Many legal careers require an undergraduate degree followed by professional study; policy careers vary.", "Research issues, interpret rules, communicate arguments, and support clients or organizations."),
        ("career-design", "Product Design", "Arts & Technology", "Design useful digital products through research, prototyping, and testing.", ["Arts & Design", "Technology", "Creativity"], "Common routes include design, HCI, digital media, and related programs.", "Interview users, prototype interfaces, test ideas, and collaborate with engineers."),
        ("career-entre", "Entrepreneurship", "Business", "Build and grow products, services, or organizations around real problems.", ["Entrepreneurship", "Leadership", "Business & Finance"], "There is no single required degree; founders come from many academic and work backgrounds.", "Talk to customers, solve problems, build products, sell, recruit, and manage limited resources."),
    ]
    for row in careers:
        con.execute(
            """INSERT OR IGNORE INTO careers
            (id,title,subtitle,description,tags_json,education,day_to_day,status,featured,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,'needs_review',?, ?, ?)""",
            (*row[:4], dumps(row[4]), row[5], row[6], 1 if row[0] in {"career-finance","career-software","career-health"} else 0, ts, ts),
        )

    verified_date = "2026-09-17"
    programs = [
        {
            "id":"prog-ivey", "title":"Ivey AEO / HBA", "university":"Western University", "field":"Business",
            "description":"Conditional pre-admission pathway to Ivey's HBA program for students beginning at Western or an affiliated university college.",
            "tags":["Business & Finance","Leadership","Entrepreneurship"],
            "requirements":[
                "Competitive AEO applicants present a low-90s average in their best Grade 12 courses, including English.",
                "Complete a mathematics course for university-bound students.",
                "Leadership in extracurricular activities, community involvement, and work experience is considered alongside academics; Ivey states the two components are weighted equally.",
                "The supplemental includes two activity essays (up to 500 words each), up to five additional activities, references, and a mandatory five-question Kira video interview."
            ],
            "deadline":"January 15, 2027 at 11:59 p.m. EST",
            "supplemental":"Separate Ivey AEO supplemental application required in addition to the Western/affiliate application through OUAC.",
            "source":"https://www.ivey.uwo.ca/hba/admissions/secondary-school-students/"
        },
        {
            "id":"prog-rotman", "title":"Rotman Commerce", "university":"University of Toronto", "field":"Commerce",
            "description":"Undergraduate commerce program at the University of Toronto with academic and supplemental application review.",
            "tags":["Business & Finance","Math","Leadership"],
            "requirements":[
                "Ontario applicants need an OSSD and six Grade 12 U/M courses including ENG4U and MCV4U.",
                "Rotman gives special attention to MCV4U and notes that all Grade 11 and 12 U/M courses may be considered.",
                "An overall Grade 11/12 average in the mid-to-high 80s or above is recommended; competitive applicants present English and Calculus in the high 80s or above."
            ],
            "deadline":"January 15, 2027 at 11:59 p.m. EST (early consideration: November 7, 2026)",
            "supplemental":"Mandatory supplemental application. Early consideration supplemental deadline: December 1, 2026. Final supplemental/documents deadline: February 1, 2027 at 11:59 p.m. EST.",
            "source":"https://rotmancommerce.utoronto.ca/future-students/ontario-applicants/"
        },
        {
            "id":"prog-smith", "title":"Smith Commerce", "university":"Queen's University", "field":"Commerce",
            "description":"Queen's University Bachelor of Commerce program with prerequisite-course thresholds and a mandatory supplementary application.",
            "tags":["Business & Finance","Leadership","Communication"],
            "requirements":[
                "Ontario applicants need an OSSD and six Grade 12 4U/4M courses.",
                "Required: ENG4U, MCV4U, and one additional 4U Mathematics course, with minimum grades of 80% in all three prerequisites.",
                "The remaining three courses may be 4U or 4M; no more than two 4M courses may be from the same discipline.",
                "A mandatory supplementary application is required."
            ],
            "deadline":"February 1, 2027",
            "supplemental":"Mandatory Commerce Supplementary Application due February 15, 2027.",
            "source":"https://www.queensu.ca/admission/applying/admission-requirements/ontario"
        },
        {
            "id":"prog-waterloo-cs", "title":"Computer Science", "university":"University of Waterloo", "field":"Technology",
            "description":"Computer science degree focused on computing, mathematics, and problem solving.",
            "tags":["Technology","Math","Problem Solving"],
            "requirements":["Confirm current prerequisites and competitive admission information on the official program page."],
            "deadline":None, "supplemental":"Verify current supplemental requirements.",
            "source":"https://uwaterloo.ca/future-students/programs/computer-science", "status":"needs_review"
        },
        {
            "id":"prog-mcmaster-health", "title":"Health Sciences", "university":"McMaster University", "field":"Health",
            "description":"Health-focused undergraduate program at McMaster University.",
            "tags":["Medicine & Health","Science","Research"],
            "requirements":["Confirm current prerequisites and supplemental requirements on McMaster's official admissions pages."],
            "deadline":None, "supplemental":"Verify current supplemental requirements.",
            "source":"https://future.mcmaster.ca/", "status":"needs_review"
        },
    ]
    for p in programs:
        status=p.get("status","verified")
        con.execute(
            """INSERT INTO programs
            (id,title,subtitle,university,field,province,description,tags_json,requirements_json,deadline,supplemental,source_url,status,last_verified_date,featured,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET title=excluded.title,subtitle=excluded.subtitle,university=excluded.university,field=excluded.field,province=excluded.province,description=excluded.description,tags_json=excluded.tags_json,requirements_json=excluded.requirements_json,deadline=excluded.deadline,supplemental=excluded.supplemental,source_url=excluded.source_url,status=excluded.status,last_verified_date=excluded.last_verified_date,featured=excluded.featured,updated_at=excluded.updated_at""",
            (p["id"],p["title"],p["university"],p["university"],p["field"],"Ontario",p["description"],dumps(p["tags"]),dumps(p["requirements"]),p["deadline"],p["supplemental"],p["source"],status,verified_date if status=="verified" else None,1 if p["id"] in {"prog-ivey","prog-rotman","prog-smith"} else 0,ts,ts),
        )

    scholarships = [
        {
            "id":"sch-loran-2027", "title":"2027 Loran Award", "subtitle":"National undergraduate award", "organization":"Loran Scholars Foundation",
            "amount":"Approximately $150,000 over four years",
            "description":"Four-year leadership-enrichment award combining financial support, mentorship, experiential learning, and a scholar community.",
            "tags":["Leadership","Community","Grade 12"],
            "eligibility":"High school applicants must be entering university for the first time in September 2027, have a minimum cumulative average of 88%, hold Canadian citizenship or permanent resident status, and meet the published age requirement.",
            "deadline":"October 15, 2026 at 12:00 p.m. ET",
            "source":"https://loranscholar.ca/the-program/how-to-apply/"
        },
        {
            "id":"sch-queens-maa-2027", "title":"Queen's Major Admission Awards", "subtitle":"Application-required entrance awards", "organization":"Queen's University",
            "amount":"Varies by award",
            "description":"A group of application-required admission awards for incoming Queen's students. Individual awards use their own academic, leadership, financial-need, nomination, and program criteria.",
            "tags":["Leadership","Academic","Grade 12"],
            "eligibility":"Eligibility varies by award. Applicants should review the official Major Admission Awards page and the criteria for each award before applying.",
            "deadline":"December 8, 2026",
            "source":"https://www.queensu.ca/registrar/financial-aid/application-required/future-students/major-awards"
        },
    ]
    # Remove old demo listings from public use while preserving any saved references.
    con.execute("UPDATE scholarships SET status='archived',updated_at=? WHERE id LIKE 'sch-demo-%'", (ts,))
    for a in scholarships:
        con.execute(
            """INSERT INTO scholarships
            (id,title,subtitle,organization,amount,description,tags_json,eligibility,deadline,source_url,status,last_verified_date,featured,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,'verified',?,1,?,?)
            ON CONFLICT(id) DO UPDATE SET title=excluded.title,subtitle=excluded.subtitle,organization=excluded.organization,amount=excluded.amount,description=excluded.description,tags_json=excluded.tags_json,eligibility=excluded.eligibility,deadline=excluded.deadline,source_url=excluded.source_url,status='verified',last_verified_date=excluded.last_verified_date,featured=excluded.featured,updated_at=excluded.updated_at""",
            (a["id"],a["title"],a["subtitle"],a["organization"],a["amount"],a["description"],dumps(a["tags"]),a["eligibility"],a["deadline"],a["source"],verified_date,ts,ts),
        )
    con.commit()

def seed_admin(con: sqlite3.Connection) -> None:
    email = os.getenv("PATHWAY_ADMIN_EMAIL", "").strip().lower()
    password = os.getenv("PATHWAY_ADMIN_PASSWORD", "")
    if not email or not password:
        return
    existing = con.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
    if existing:
        con.execute("UPDATE users SET is_admin=1, updated_at=? WHERE id=?", (now_iso(), existing["id"]))
    else:
        ts = now_iso()
        con.execute(
            "INSERT INTO users(name,email,password_hash,onboarding_completed,is_admin,email_verified,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
            ("Pathway Admin", email, hash_password(password), 1, 1, 1, ts, ts),
        )
    con.commit()


@app.on_event("startup")
def startup() -> None:
    init_db()


class SignupIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: str
    password: str


class EmailIn(BaseModel):
    email: str = Field(min_length=5, max_length=254)


class PasswordResetConfirmIn(BaseModel):
    token: str = Field(min_length=20, max_length=500)
    password: str = Field(min_length=8, max_length=128)


class OnboardingIn(BaseModel):
    grade: str = Field(default="12", max_length=16)
    interests: list[str] = Field(default_factory=list, max_length=20)
    goal: str = Field(default="Explore careers", max_length=120)


class ProfileIn(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=80)
    grade: Optional[str] = Field(default=None, max_length=16)


class SaveIn(BaseModel):
    item_type: Literal["career", "program", "scholarship"]
    item_id: str


class ApplicationIn(BaseModel):
    program_id: Optional[str] = None
    institution: str = Field(min_length=1, max_length=160)
    program_name: str = Field(min_length=1, max_length=160)
    status: str = Field(default="Researching", max_length=40)
    deadline: Optional[str] = Field(default=None, max_length=40)
    notes: str = Field(default="", max_length=4000)


class ApplicationPatch(BaseModel):
    institution: Optional[str] = Field(default=None, max_length=160)
    program_name: Optional[str] = Field(default=None, max_length=160)
    status: Optional[str] = Field(default=None, max_length=40)
    deadline: Optional[str] = Field(default=None, max_length=40)
    notes: Optional[str] = Field(default=None, max_length=4000)


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=180)
    due_date: Optional[str] = Field(default=None, max_length=40)


class TaskPatch(BaseModel):
    title: Optional[str] = Field(default=None, max_length=180)
    due_date: Optional[str] = Field(default=None, max_length=40)
    completed: Optional[bool] = None


class AdminContentIn(BaseModel):
    id: Optional[str] = Field(default=None, max_length=120)
    title: str = Field(min_length=1, max_length=180)
    subtitle: str = Field(default="", max_length=180)
    description: str = Field(default="", max_length=4000)
    tags: list[str] = Field(default_factory=list, max_length=30)
    source_url: Optional[str] = Field(default=None, max_length=1000)
    status: Literal["draft", "needs_review", "verified", "outdated", "archived"] = "needs_review"
    last_verified_date: Optional[str] = Field(default=None, max_length=40)
    featured: bool = False
    education: Optional[str] = Field(default=None, max_length=4000)
    day_to_day: Optional[str] = Field(default=None, max_length=4000)
    university: Optional[str] = Field(default=None, max_length=180)
    field: Optional[str] = Field(default=None, max_length=120)
    province: Optional[str] = Field(default="Ontario", max_length=120)
    requirements: list[str] = Field(default_factory=list, max_length=50)
    deadline: Optional[str] = Field(default=None, max_length=80)
    supplemental: Optional[str] = Field(default=None, max_length=2000)
    organization: Optional[str] = Field(default=None, max_length=180)
    amount: Optional[str] = Field(default=None, max_length=80)
    eligibility: Optional[str] = Field(default=None, max_length=4000)



_RATE_BUCKETS: dict[str, deque[float]] = defaultdict(deque)


def rate_limit(request: Request, bucket: str, limit: int, window_seconds: int) -> None:
    ip = request.client.host if request.client else "unknown"
    key = f"{bucket}:{ip}"
    now = time.time()
    q = _RATE_BUCKETS[key]
    while q and q[0] <= now - window_seconds:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="Too many requests. Please try again later.")
    q.append(now)


def create_auth_token(user_id: int, purpose: str, hours: int) -> str:
    raw = secrets.token_urlsafe(36)
    expires = datetime.now(timezone.utc) + timedelta(hours=hours)
    con = connect()
    con.execute("DELETE FROM auth_tokens WHERE user_id=? AND purpose=?", (user_id, purpose))
    con.execute(
        "INSERT INTO auth_tokens(token_hash,user_id,purpose,expires_at,created_at) VALUES(?,?,?,?,?)",
        (token_hash(raw), user_id, purpose, expires.replace(microsecond=0).isoformat(), now_iso()),
    )
    con.commit(); con.close()
    return raw


def consume_auth_token(raw: str, purpose: str) -> Optional[int]:
    con = connect()
    row = con.execute(
        "SELECT * FROM auth_tokens WHERE token_hash=? AND purpose=? AND used_at IS NULL AND expires_at>?",
        (token_hash(raw), purpose, now_iso()),
    ).fetchone()
    if not row:
        con.close(); return None
    con.execute("UPDATE auth_tokens SET used_at=? WHERE token_hash=?", (now_iso(), token_hash(raw)))
    con.commit(); con.close()
    return int(row["user_id"])


def send_email(to_email: str, subject: str, text_body: str) -> None:
    """Send through SMTP when configured; otherwise write the exact message to a local dev outbox."""
    if SMTP_HOST:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = SMTP_FROM
        msg["To"] = to_email
        msg.set_content(text_body)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
            if SMTP_USE_TLS:
                server.starttls()
            if SMTP_USERNAME:
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
        return
    OUTBOX_PATH.parent.mkdir(parents=True, exist_ok=True)
    with OUTBOX_PATH.open("a", encoding="utf-8") as f:
        f.write(f"\n--- {now_iso()} ---\nTO: {to_email}\nSUBJECT: {subject}\n{text_body}\n")


def issue_verification_email(user_id: int, email: str) -> None:
    raw = create_auth_token(user_id, "verify_email", EMAIL_TOKEN_HOURS)
    link = f"{APP_BASE_URL}/?verify={raw}"
    send_email(email, "Verify your Pathway email", f"Verify your Pathway email by opening this link:\n\n{link}\n\nThis link expires in {EMAIL_TOKEN_HOURS} hours.")


def issue_reset_email(user_id: int, email: str) -> None:
    raw = create_auth_token(user_id, "password_reset", RESET_TOKEN_HOURS)
    link = f"{APP_BASE_URL}/?reset={raw}"
    send_email(email, "Reset your Pathway password", f"Reset your Pathway password by opening this link:\n\n{link}\n\nThis link expires in {RESET_TOKEN_HOURS} hour(s). If you did not request this, ignore this email.")


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # Same-origin protection for cookie-authenticated state-changing requests.
    if request.method in {"POST", "PUT", "PATCH", "DELETE"} and request.url.path.startswith("/api/"):
        origin = request.headers.get("origin")
        if origin and origin.rstrip("/") != APP_BASE_URL:
            return HTMLResponse("Invalid request origin", status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if COOKIE_SECURE:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

def get_user_from_cookie(pathway_session: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE)) -> Optional[dict[str, Any]]:
    if not pathway_session:
        return None
    con = connect()
    row = con.execute(
        """SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
           WHERE s.token_hash=? AND s.expires_at>?""",
        (token_hash(pathway_session), now_iso()),
    ).fetchone()
    con.close()
    return serialize_user(row) if row else None


def require_user(user: Optional[dict[str, Any]] = Depends(get_user_from_cookie)) -> dict[str, Any]:
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


def require_admin(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    if not user["is_admin"]:
        raise HTTPException(status_code=403, detail="Administrator access required")
    return user


def create_session(response: Response, user_id: int) -> None:
    raw = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    con = connect()
    con.execute("DELETE FROM sessions WHERE user_id=? OR expires_at<=?", (user_id, now_iso()))
    con.execute(
        "INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
        (token_hash(raw), user_id, expires.replace(microsecond=0).isoformat(), now_iso()),
    )
    con.commit()
    con.close()
    response.set_cookie(
        SESSION_COOKIE,
        raw,
        max_age=SESSION_DAYS * 86400,
        httponly=True,
        samesite="lax",
        secure=COOKIE_SECURE,
        path="/",
    )


def clean_email(value: str) -> str:
    email = value.strip().lower()
    if "@" not in email or "." not in email.rsplit("@", 1)[-1]:
        raise HTTPException(status_code=422, detail="Enter a valid email address")
    return email


@app.get("/")
def index() -> FileResponse:
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/privacy")
def privacy_page() -> FileResponse:
    return FileResponse(ROOT / "static" / "privacy.html")


@app.get("/terms")
def terms_page() -> FileResponse:
    return FileResponse(ROOT / "static" / "terms.html")


@app.get("/api/health")
def health() -> dict[str, Any]:
    try:
        con = connect(); con.execute("SELECT 1").fetchone(); con.close()
        db = "ok"
    except Exception:
        db = "error"
    return {"status": "ok" if db == "ok" else "degraded", "database": db, "version": APP_VERSION, "time": now_iso()}


@app.post("/api/auth/signup", status_code=201)
def signup(payload: SignupIn, response: Response, request: Request) -> dict[str, Any]:
    rate_limit(request, "signup", 8, 900)
    email = clean_email(payload.email)
    con = connect()
    if con.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
        con.close()
        raise HTTPException(status_code=409, detail="An account already exists with this email")
    ts = now_iso()
    cur = con.execute(
        "INSERT INTO users(name,email,password_hash,created_at,updated_at) VALUES(?,?,?,?,?)",
        (payload.name.strip(), email, hash_password(payload.password), ts, ts),
    )
    con.commit()
    row = con.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    con.close()
    create_session(response, row["id"])
    try:
        issue_verification_email(row["id"], email)
    except Exception:
        # Account creation should still succeed if an email provider is temporarily unavailable.
        pass
    return {"user": serialize_user(row), "verification_sent": True}


@app.post("/api/auth/login")
def login(payload: LoginIn, response: Response, request: Request) -> dict[str, Any]:
    rate_limit(request, "login", 12, 900)
    email = clean_email(payload.email)
    con = connect()
    row = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    con.close()
    if not row or not verify_password(payload.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    create_session(response, row["id"])
    return {"user": serialize_user(row)}



@app.post("/api/auth/resend-verification")
def resend_verification(request: Request, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    rate_limit(request, "resend-verification", 4, 3600)
    if user.get("email_verified"):
        return {"ok": True}
    issue_verification_email(user["id"], user["email"])
    return {"ok": True}


@app.post("/api/auth/verify-email")
def verify_email(payload: dict[str, str], request: Request) -> dict[str, bool]:
    rate_limit(request, "verify-email", 20, 3600)
    raw = (payload.get("token") or "").strip()
    if not raw:
        raise HTTPException(status_code=422, detail="Verification token required")
    user_id = consume_auth_token(raw, "verify_email")
    if not user_id:
        raise HTTPException(status_code=400, detail="This verification link is invalid or has expired")
    con = connect()
    con.execute("UPDATE users SET email_verified=1,updated_at=? WHERE id=?", (now_iso(), user_id))
    con.commit(); con.close()
    return {"ok": True}


@app.post("/api/auth/password-reset/request")
def request_password_reset(payload: EmailIn, request: Request) -> dict[str, bool]:
    rate_limit(request, "password-reset-request", 5, 3600)
    email = clean_email(payload.email)
    con = connect(); row = con.execute("SELECT id,email FROM users WHERE email=?", (email,)).fetchone(); con.close()
    if row:
        try:
            issue_reset_email(row["id"], row["email"])
        except Exception:
            pass
    # Do not reveal whether an address has an account.
    return {"ok": True}


@app.post("/api/auth/password-reset/confirm")
def confirm_password_reset(payload: PasswordResetConfirmIn, request: Request) -> dict[str, bool]:
    rate_limit(request, "password-reset-confirm", 10, 3600)
    user_id = consume_auth_token(payload.token, "password_reset")
    if not user_id:
        raise HTTPException(status_code=400, detail="This reset link is invalid or has expired")
    con = connect()
    con.execute("UPDATE users SET password_hash=?,updated_at=? WHERE id=?", (hash_password(payload.password), now_iso(), user_id))
    con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
    con.commit(); con.close()
    return {"ok": True}


@app.post("/api/auth/logout")
def logout(response: Response, pathway_session: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE)) -> dict[str, bool]:
    if pathway_session:
        con = connect()
        con.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(pathway_session),))
        con.commit()
        con.close()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@app.get("/api/me")
def me(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    return {"user": user}


@app.patch("/api/me")
def update_me(payload: ProfileIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    fields, params = [], []
    if payload.name is not None:
        fields.append("name=?")
        params.append(payload.name.strip())
    if payload.grade is not None:
        fields.append("grade=?")
        params.append(payload.grade.strip())
    if fields:
        fields.append("updated_at=?")
        params.append(now_iso())
        params.append(user["id"])
        con = connect()
        con.execute(f"UPDATE users SET {', '.join(fields)} WHERE id=?", params)
        con.commit()
        row = con.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        con.close()
        return {"user": serialize_user(row)}
    return {"user": user}



@app.delete("/api/me")
def delete_account(response: Response, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    con.execute("DELETE FROM users WHERE id=?", (user["id"],))
    con.commit(); con.close()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@app.put("/api/me/onboarding")
def onboarding(payload: OnboardingIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    interests = [x.strip() for x in payload.interests if x.strip()][:20]
    con = connect()
    con.execute(
        "UPDATE users SET grade=?,interests_json=?,goal=?,onboarding_completed=1,updated_at=? WHERE id=?",
        (payload.grade.strip(), dumps(interests), payload.goal.strip(), now_iso(), user["id"]),
    )
    con.commit()
    row = con.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    con.close()
    return {"user": serialize_user(row)}


def get_table(content_type: str) -> str:
    mapping = {"career": "careers", "program": "programs", "scholarship": "scholarships"}
    if content_type not in mapping:
        raise HTTPException(status_code=404, detail="Unknown content type")
    return mapping[content_type]


@app.get("/api/content")
def list_content(
    type: Optional[Literal["career", "program", "scholarship"]] = None,
    q: str = "",
    include_preview: bool = False,
    user: Optional[dict[str, Any]] = Depends(get_user_from_cookie),
) -> dict[str, Any]:
    types = [type] if type else ["career", "program", "scholarship"]
    result: list[dict[str, Any]] = []
    can_preview = bool(include_preview and user and user.get("is_admin"))
    con = connect()
    for t in types:
        table = get_table(t)
        if can_preview or t == "career":
            where = ["status != 'archived'"]
        else:
            where = ["status='verified'"]
        params: list[Any] = []
        if q.strip():
            where.append("(title LIKE ? OR subtitle LIKE ? OR description LIKE ? OR tags_json LIKE ?)")
            needle = f"%{q.strip()}%"
            params.extend([needle, needle, needle, needle])
        rows = con.execute(f"SELECT * FROM {table} WHERE {' AND '.join(where)} ORDER BY featured DESC, title COLLATE NOCASE", params).fetchall()
        result.extend(content_row_to_dict(r, t) for r in rows)
    con.close()
    return {"items": result}


@app.get("/api/content/{content_type}/{item_id}")
def content_detail(content_type: str, item_id: str, user: Optional[dict[str, Any]] = Depends(get_user_from_cookie)) -> dict[str, Any]:
    table = get_table(content_type)
    con = connect()
    row = con.execute(f"SELECT * FROM {table} WHERE id=? AND status!='archived'", (item_id,)).fetchone()
    con.close()
    if not row:
        raise HTTPException(status_code=404, detail="Item not found")
    if content_type in {"program", "scholarship"} and row["status"] != "verified" and not (user and user.get("is_admin")):
        raise HTTPException(status_code=404, detail="Item not found")
    return {"item": content_row_to_dict(row, content_type)}


@app.get("/api/saved")
def saved(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    rows = con.execute("SELECT item_type,item_id,created_at FROM saved_items WHERE user_id=? ORDER BY created_at DESC", (user["id"],)).fetchall()
    con.close()
    return {"items": [dict(r) for r in rows]}


@app.post("/api/saved", status_code=201)
def save_item(payload: SaveIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    table = get_table(payload.item_type)
    con = connect()
    if not con.execute(f"SELECT 1 FROM {table} WHERE id=? AND status!='archived'", (payload.item_id,)).fetchone():
        con.close()
        raise HTTPException(status_code=404, detail="Item not found")
    con.execute(
        "INSERT OR IGNORE INTO saved_items(user_id,item_type,item_id,created_at) VALUES(?,?,?,?)",
        (user["id"], payload.item_type, payload.item_id, now_iso()),
    )
    con.commit()
    con.close()
    return {"ok": True}


@app.delete("/api/saved/{item_type}/{item_id}")
def unsave_item(item_type: Literal["career", "program", "scholarship"], item_id: str, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    con.execute("DELETE FROM saved_items WHERE user_id=? AND item_type=? AND item_id=?", (user["id"], item_type, item_id))
    con.commit()
    con.close()
    return {"ok": True}


def score_item(item: dict[str, Any], user: dict[str, Any]) -> tuple[int, str]:
    interests = set(user.get("interests") or [])
    tags = set(item.get("tags") or [])
    matches = list(interests.intersection(tags))
    score = 40 * len(matches)
    goal = (user.get("goal") or "").lower()
    if "scholar" in goal and item["type"] == "scholarship":
        score += 20
    if "program" in goal and item["type"] == "program":
        score += 20
    if "career" in goal and item["type"] == "career":
        score += 20
    if matches:
        reason = "Matches your interest in " + " and ".join(matches[:2]) + "."
    elif user.get("goal"):
        reason = f"Relevant to your goal: {user['goal']}."
    else:
        reason = "Included as an option to explore."
    return score, reason


@app.get("/api/recommendations")
def recommendations(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    items = list_content(include_preview=False, user=user)["items"]
    scored = []
    for item in items:
        score, reason = score_item(item, user)
        scored.append({**item, "score": score, "reason_text": reason})
    scored.sort(key=lambda x: (-x["score"], x["title"].lower()))
    return {"items": scored[:12]}


def serialize_application(con: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    tasks = con.execute(
        "SELECT id,title,completed,due_date,sort_order FROM application_tasks WHERE application_id=? ORDER BY sort_order,id",
        (row["id"],),
    ).fetchall()
    return {
        "id": row["id"],
        "program_id": row["program_id"],
        "institution": row["institution"],
        "program_name": row["program_name"],
        "status": row["status"],
        "deadline": row["deadline"],
        "notes": row["notes"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "tasks": [{**dict(t), "completed": bool(t["completed"])} for t in tasks],
    }


@app.get("/api/applications")
def list_applications(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    rows = con.execute("SELECT * FROM applications WHERE user_id=? ORDER BY updated_at DESC", (user["id"],)).fetchall()
    result = [serialize_application(con, r) for r in rows]
    con.close()
    return {"items": result}


@app.post("/api/applications", status_code=201)
def create_application(payload: ApplicationIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    ts = now_iso()
    con = connect()
    cur = con.execute(
        """INSERT INTO applications(user_id,program_id,institution,program_name,status,deadline,notes,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?)""",
        (user["id"], payload.program_id, payload.institution.strip(), payload.program_name.strip(), payload.status, payload.deadline, payload.notes, ts, ts),
    )
    app_id = cur.lastrowid
    for i, title in enumerate(["Review official requirements", "Prepare required documents", "Complete supplemental requirements", "Submit application"]):
        con.execute("INSERT INTO application_tasks(application_id,title,sort_order) VALUES(?,?,?)", (app_id, title, i))
    con.commit()
    row = con.execute("SELECT * FROM applications WHERE id=?", (app_id,)).fetchone()
    result = serialize_application(con, row)
    con.close()
    return {"application": result}


@app.patch("/api/applications/{application_id}")
def update_application(application_id: int, payload: ApplicationPatch, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    row = con.execute("SELECT * FROM applications WHERE id=? AND user_id=?", (application_id, user["id"])).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Application not found")
    fields, params = [], []
    for field in ["institution", "program_name", "status", "deadline", "notes"]:
        value = getattr(payload, field)
        if value is not None:
            fields.append(f"{field}=?")
            params.append(value)
    if fields:
        fields.append("updated_at=?")
        params.extend([now_iso(), application_id, user["id"]])
        con.execute(f"UPDATE applications SET {', '.join(fields)} WHERE id=? AND user_id=?", params)
        con.commit()
    row = con.execute("SELECT * FROM applications WHERE id=?", (application_id,)).fetchone()
    result = serialize_application(con, row)
    con.close()
    return {"application": result}


@app.delete("/api/applications/{application_id}")
def delete_application(application_id: int, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    cur = con.execute("DELETE FROM applications WHERE id=? AND user_id=?", (application_id, user["id"]))
    con.commit()
    con.close()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Application not found")
    return {"ok": True}


@app.post("/api/applications/{application_id}/tasks", status_code=201)
def add_task(application_id: int, payload: TaskIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    if not con.execute("SELECT 1 FROM applications WHERE id=? AND user_id=?", (application_id, user["id"])).fetchone():
        con.close()
        raise HTTPException(status_code=404, detail="Application not found")
    order = con.execute("SELECT COALESCE(MAX(sort_order),-1)+1 AS n FROM application_tasks WHERE application_id=?", (application_id,)).fetchone()["n"]
    cur = con.execute("INSERT INTO application_tasks(application_id,title,due_date,sort_order) VALUES(?,?,?,?)", (application_id,payload.title.strip(),payload.due_date,order))
    con.commit()
    row = con.execute("SELECT id,title,completed,due_date,sort_order FROM application_tasks WHERE id=?", (cur.lastrowid,)).fetchone()
    con.close()
    return {"task": {**dict(row), "completed": bool(row["completed"])}}


@app.patch("/api/tasks/{task_id}")
def update_task(task_id: int, payload: TaskPatch, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    row = con.execute(
        """SELECT t.* FROM application_tasks t JOIN applications a ON a.id=t.application_id
           WHERE t.id=? AND a.user_id=?""",
        (task_id, user["id"]),
    ).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Task not found")
    fields, params = [], []
    if payload.title is not None:
        fields.append("title=?"); params.append(payload.title)
    if payload.due_date is not None:
        fields.append("due_date=?"); params.append(payload.due_date)
    if payload.completed is not None:
        fields.append("completed=?"); params.append(1 if payload.completed else 0)
    if fields:
        params.append(task_id)
        con.execute(f"UPDATE application_tasks SET {', '.join(fields)} WHERE id=?", params)
        con.execute("UPDATE applications SET updated_at=? WHERE id=?", (now_iso(), row["application_id"]))
        con.commit()
    row = con.execute("SELECT id,title,completed,due_date,sort_order FROM application_tasks WHERE id=?", (task_id,)).fetchone()
    con.close()
    return {"task": {**dict(row), "completed": bool(row["completed"])}}


@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    row = con.execute(
        """SELECT t.id FROM application_tasks t JOIN applications a ON a.id=t.application_id
           WHERE t.id=? AND a.user_id=?""",
        (task_id, user["id"]),
    ).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Task not found")
    con.execute("DELETE FROM application_tasks WHERE id=?", (task_id,))
    con.commit(); con.close()
    return {"ok": True}


def validate_verified(payload: AdminContentIn) -> None:
    if payload.status == "verified" and (not payload.source_url or not payload.last_verified_date):
        raise HTTPException(status_code=422, detail="Verified records require an official source URL and verification date")


def admin_write(content_type: str, payload: AdminContentIn, admin: dict[str, Any], item_id: Optional[str] = None) -> dict[str, Any]:
    validate_verified(payload)
    table = get_table(content_type)
    item_id = item_id or payload.id or f"{content_type}-{secrets.token_hex(6)}"
    ts = now_iso()
    con = connect()
    existing = con.execute(f"SELECT 1 FROM {table} WHERE id=?", (item_id,)).fetchone()
    common = (payload.title.strip(), payload.subtitle.strip(), payload.description.strip(), dumps(payload.tags), payload.source_url, payload.status, payload.last_verified_date, 1 if payload.featured else 0, ts)
    if content_type == "career":
        if existing:
            con.execute("""UPDATE careers SET title=?,subtitle=?,description=?,tags_json=?,source_url=?,status=?,last_verified_date=?,featured=?,updated_at=?,education=?,day_to_day=? WHERE id=?""", (*common,payload.education or "",payload.day_to_day or "",item_id))
        else:
            con.execute("""INSERT INTO careers(id,title,subtitle,description,tags_json,source_url,status,last_verified_date,featured,updated_at,education,day_to_day,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (item_id,*common,payload.education or "",payload.day_to_day or "",ts,))
    elif content_type == "program":
        if existing:
            con.execute("""UPDATE programs SET title=?,subtitle=?,description=?,tags_json=?,source_url=?,status=?,last_verified_date=?,featured=?,updated_at=?,university=?,field=?,province=?,requirements_json=?,deadline=?,supplemental=? WHERE id=?""", (*common,payload.university or payload.subtitle,payload.field or "",payload.province or "Ontario",dumps(payload.requirements),payload.deadline,payload.supplemental,item_id))
        else:
            con.execute("""INSERT INTO programs(id,title,subtitle,description,tags_json,source_url,status,last_verified_date,featured,updated_at,university,field,province,requirements_json,deadline,supplemental,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (item_id,*common,payload.university or payload.subtitle,payload.field or "",payload.province or "Ontario",dumps(payload.requirements),payload.deadline,payload.supplemental,ts))
    else:
        if existing:
            con.execute("""UPDATE scholarships SET title=?,subtitle=?,description=?,tags_json=?,source_url=?,status=?,last_verified_date=?,featured=?,updated_at=?,organization=?,amount=?,eligibility=?,deadline=? WHERE id=?""", (*common,payload.organization or "",payload.amount,payload.eligibility or "",payload.deadline,item_id))
        else:
            con.execute("""INSERT INTO scholarships(id,title,subtitle,description,tags_json,source_url,status,last_verified_date,featured,updated_at,organization,amount,eligibility,deadline,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (item_id,*common,payload.organization or "",payload.amount,payload.eligibility or "",payload.deadline,ts))
    con.execute("INSERT INTO content_change_log(admin_user_id,item_type,item_id,action,created_at) VALUES(?,?,?,?,?)", (admin["id"],content_type,item_id,"updated" if existing else "created",ts))
    con.commit()
    row = con.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
    result = content_row_to_dict(row, content_type)
    con.close()
    return result


@app.get("/api/admin/stats")
def admin_stats(admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    con = connect()
    stats = {
        "users": con.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"],
        "careers": con.execute("SELECT COUNT(*) AS n FROM careers WHERE status!='archived'").fetchone()["n"],
        "programs": con.execute("SELECT COUNT(*) AS n FROM programs WHERE status!='archived'").fetchone()["n"],
        "scholarships": con.execute("SELECT COUNT(*) AS n FROM scholarships WHERE status!='archived'").fetchone()["n"],
        "needs_review": sum(con.execute(f"SELECT COUNT(*) AS n FROM {t} WHERE status='needs_review'").fetchone()["n"] for t in ["careers","programs","scholarships"]),
    }
    con.close()
    return stats


@app.post("/api/admin/content/{content_type}", status_code=201)
def admin_create(content_type: Literal["career", "program", "scholarship"], payload: AdminContentIn, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return {"item": admin_write(content_type, payload, admin)}


@app.put("/api/admin/content/{content_type}/{item_id}")
def admin_update(content_type: Literal["career", "program", "scholarship"], item_id: str, payload: AdminContentIn, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return {"item": admin_write(content_type, payload, admin, item_id)}


@app.delete("/api/admin/content/{content_type}/{item_id}")
def admin_archive(content_type: Literal["career", "program", "scholarship"], item_id: str, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    table = get_table(content_type)
    con = connect()
    cur = con.execute(f"UPDATE {table} SET status='archived',updated_at=? WHERE id=?", (now_iso(),item_id))
    if cur.rowcount:
        con.execute("INSERT INTO content_change_log(admin_user_id,item_type,item_id,action,created_at) VALUES(?,?,?,?,?)", (admin["id"],content_type,item_id,"archived",now_iso()))
    con.commit(); con.close()
    if not cur.rowcount:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"ok": True}


@app.get("/api/admin/change-log")
def admin_log(admin: dict[str, Any] = Depends(require_admin), limit: int = Query(default=50, ge=1, le=200)) -> dict[str, Any]:
    con = connect()
    rows = con.execute("""SELECT l.*,u.email AS admin_email FROM content_change_log l JOIN users u ON u.id=l.admin_user_id ORDER BY l.id DESC LIMIT ?""", (limit,)).fetchall()
    con.close()
    return {"items": [dict(r) for r in rows]}


@app.get("/{path:path}")
def spa_fallback(path: str) -> FileResponse:
    if path.startswith("api/"):
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(ROOT / "static" / "index.html")
