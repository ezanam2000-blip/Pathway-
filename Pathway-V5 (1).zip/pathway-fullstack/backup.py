from __future__ import annotations
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("PATHWAY_DB_PATH", ROOT / "pathway.db"))
BACKUP_DIR = Path(os.getenv("PATHWAY_BACKUP_DIR", ROOT / "backups"))
KEEP = int(os.getenv("PATHWAY_BACKUP_KEEP", "14"))


def main() -> None:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = BACKUP_DIR / f"pathway-{stamp}.db"
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close(); src.close()
    backups = sorted(BACKUP_DIR.glob("pathway-*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[KEEP:]:
        old.unlink(missing_ok=True)
    print(target)


if __name__ == "__main__":
    main()
