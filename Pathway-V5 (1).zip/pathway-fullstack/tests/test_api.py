import importlib
import os
import re
import tempfile
from pathlib import Path


def _latest_token(outbox: Path, kind: str) -> str:
    text = outbox.read_text(encoding="utf-8")
    key = "verify=" if kind == "verify" else "reset="
    matches = re.findall(re.escape(key) + r"([A-Za-z0-9_-]+)", text)
    assert matches
    return matches[-1]


def test_launch_flow():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    outbox = Path(tmp.name + ".outbox")
    os.environ["PATHWAY_DB_PATH"] = tmp.name
    os.environ["PATHWAY_OUTBOX_PATH"] = str(outbox)
    os.environ["PATHWAY_BASE_URL"] = "http://testserver"
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)
        with TestClient(app_module.app) as client:
            health = client.get("/api/health")
            assert health.status_code == 200
            assert health.json()["database"] == "ok"
            assert health.headers["x-content-type-options"] == "nosniff"

            public = client.get("/api/content").json()["items"]
            ids = {x["id"] for x in public}
            assert {"prog-ivey", "prog-rotman", "prog-smith", "sch-loran-2027"}.issubset(ids)
            assert "prog-waterloo-cs" not in ids  # remains under review

            r = client.post("/api/auth/signup", json={"name":"Test Student","email":"student@example.com","password":"strongpass123"})
            assert r.status_code == 201
            assert r.json()["user"]["email_verified"] is False

            token = _latest_token(outbox, "verify")
            r = client.post("/api/auth/verify-email", json={"token": token})
            assert r.status_code == 200
            assert client.get("/api/me").json()["user"]["email_verified"] is True

            r = client.put("/api/me/onboarding", json={"grade":"12","interests":["Business & Finance"],"goal":"Find university programs"})
            assert r.status_code == 200
            assert r.json()["user"]["onboarding_completed"] is True
            recs = client.get("/api/recommendations")
            assert recs.status_code == 200
            assert len(recs.json()["items"]) > 0

            client.post("/api/auth/logout")
            r = client.post("/api/auth/password-reset/request", json={"email":"student@example.com"})
            assert r.status_code == 200
            reset = _latest_token(outbox, "reset")
            r = client.post("/api/auth/password-reset/confirm", json={"token": reset, "password":"newstrongpass456"})
            assert r.status_code == 200
            assert client.post("/api/auth/login", json={"email":"student@example.com","password":"newstrongpass456"}).status_code == 200

            assert client.get("/privacy").status_code == 200
            assert client.get("/terms").status_code == 200
    finally:
        Path(tmp.name).unlink(missing_ok=True)
        outbox.unlink(missing_ok=True)
