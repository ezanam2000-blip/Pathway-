# Pathway — Guided Planning V6

Pathway is a student planning platform for careers, university programs, scholarships, saved options, and application tasks.

## What is implemented

### Student app
- Account creation, login and logout
- Secure PBKDF2 password hashing
- HttpOnly session cookies
- Email verification links
- Password reset links
- Profile/onboarding preferences
- Career, program and scholarship discovery
- Search and filtering
- Explainable rule-based recommendations
- Saved items / My Path
- Application tracker with task checklists
- Account deletion
- Mobile-responsive interface
- Privacy Policy and Terms pages

### Content and admin backend
- Careers, Programs and Scholarships APIs
- Admin-only preview of unverified program/scholarship records
- Verified-content rule requiring an official source and verification date
- Automatic staleness review after a configurable number of days
- Admin create/update/archive APIs
- Admin change log and content statistics
- Verified starter records for Ivey AEO, Rotman Commerce, Smith Commerce, the 2027 Loran Award and Queen's Major Admission Awards

### Production hardening
- Same-origin checks for state-changing API requests
- Security response headers and HSTS when HTTPS cookies are enabled
- Basic in-memory rate limiting for authentication endpoints
- Health endpoint at `/api/health`
- SQLite-safe backup script with retention
- Dockerfile
- Render deployment blueprint with a persistent disk
- SMTP support for verification/reset emails
- Development email outbox when SMTP is not configured
- Automated launch-flow test

## Run locally

```bash
python -m pip install -r requirements.txt
uvicorn app:app --reload
```

Open `http://127.0.0.1:8000`.

On Windows you can run `start.bat`; on macOS/Linux run `./start.sh`.

## Email in development

Without SMTP settings, verification and password-reset emails are written to:

`dev-email-outbox.log`

This makes the full flow testable locally without an email provider.

## Production environment

Copy `.env.example` and configure at minimum:

- `PATHWAY_BASE_URL` — deployed HTTPS URL
- `PATHWAY_ADMIN_EMAIL`
- `PATHWAY_ADMIN_PASSWORD`
- `PATHWAY_COOKIE_SECURE=1`
- SMTP settings for verification/reset mail
- `PATHWAY_DB_PATH` on persistent storage

Never commit real passwords or SMTP credentials.

## Deploy

A `Dockerfile` and `render.yaml` are included. The Render configuration mounts a persistent disk at `/var/data` and stores the database there. After creating the service, set the secret environment variables in the host dashboard and set `PATHWAY_BASE_URL` to the final HTTPS URL.

The app can also run on another Docker-compatible host. Keep the database on persistent storage.

## Backups

Run:

```bash
python backup.py
```

The script uses SQLite's backup API and retains the most recent backups according to `PATHWAY_BACKUP_KEEP` (default 14). For a real public launch, copy backups to a separate storage provider as well; a backup on the same host is not sufficient for disaster recovery.

## Tests

```bash
python -m pip install -r requirements-dev.txt
pytest -q
```

The test covers health/security headers, public verified-content filtering, sign-up, email verification, onboarding, recommendations, password reset, login, Privacy and Terms.

## Data verification

Records marked `verified` in the seed data were checked on **September 17, 2026** against their stored official source URLs. Pathway automatically moves old verified Program/Scholarship records back to review after `PATHWAY_STALE_DAYS` (default 180 days).

Do not treat Pathway as the official admissions source. The product deliberately links students back to the institution or scholarship provider before an application decision.

## Before a public launch to minors

The included Privacy Policy and Terms are a strong product draft, not legal advice. Because the intended audience includes high-school students, have a parent/guardian or responsible adult involved in the launch process and have the legal/privacy language reviewed for the jurisdictions where Pathway will operate.

For a small pilot, SQLite with a persistent disk is adequate. If usage grows materially, migrate the data layer to a managed PostgreSQL database and replace the in-memory rate limiter with a shared store such as Redis.

## Pathway V6 — guided career and admissions planning

This build expands Pathway from a directory into a guided planning product. It includes:

- Multi-select onboarding for industries, goals, and strengths
- A four-question Career Match that returns several career options with explanations
- Rich career profiles with day-to-day work, education, pay references, career levels, useful school subjects, skills, and practical entry steps
- University/program pages with application timing, requirements, supplemental work, deadlines, recommended preparation, timelines, related careers, and official sources
- Personalized checklists generated from a student's stage, selected strengths, and chosen career/program
- A My Plan page with persistent checklist progress, saved options, and application tracking
- More industry coverage including finance, technology, healthcare, engineering, law, design, skilled trades, education, and entrepreneurship

Career matching is guidance, not a deterministic career recommendation. Salary figures are labour-market references and are not guarantees. Admission preparation guidance is intended to help students organize and strengthen their preparation; institutions make all admission decisions.

## V7 career explorer

V7 adds a large career catalog (100+ searchable paths) and broadens Pathway beyond business and finance. The catalog includes under-the-radar options such as actuarial work, supply chain, procurement, policy, bioinformatics, urban planning, environmental science, cybersecurity, health policy, technical writing, operations, and specialized engineering roles.

Career Match now returns a more diverse set of results instead of allowing one industry to dominate every suggestion. The Career Explorer also adds industry filters, a result count, broader search examples, and progressive loading for a large library.

## Pathway V8 changes

V8 focuses on trust, clarity, mobile use, and early validation rather than adding more feature surface.

- Decision-first home page with four clear starting paths.
- Shorter, more natural student-facing copy.
- Source, region, and last-checked metadata for volatile career and admissions facts.
- Consolidated career ladder + pay module.
- Consolidated program key-dates timeline.
- A flagship set of 30 deep career guides while keeping the larger searchable catalog.
- Responsive mobile improvements for navigation, cards, modals, timelines, and detail pages.
- Basic product analytics for activation: saving a career or starting a plan.
- Optional managed PostgreSQL support through `DATABASE_URL`; SQLite still works locally.

### Production database

For production, use a persistent database. The safest default is managed PostgreSQL.

Set:

```
DATABASE_URL=postgresql://...
```

If `DATABASE_URL` is absent, Pathway uses SQLite at `PATHWAY_DB_PATH` (or `pathway.db` by default). A production SQLite deployment must use a persistent disk.
