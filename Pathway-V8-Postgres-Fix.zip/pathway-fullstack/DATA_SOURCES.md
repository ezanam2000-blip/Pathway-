# Pathway starter data sources

Checked: 2026-09-17

- Ivey AEO / HBA — https://www.ivey.uwo.ca/hba/admissions/secondary-school-students/
- Rotman Commerce (Ontario applicants) — https://rotmancommerce.utoronto.ca/future-students/ontario-applicants/
- Rotman Commerce important dates — https://rotmancommerce.utoronto.ca/future-students/important-dates/
- Queen's Ontario admission requirements — https://www.queensu.ca/admission/applying/admission-requirements/ontario
- Queen's undergraduate admission deadlines — https://www.queensu.ca/admission/applying/dates-deadlines
- Queen's Major Admission Awards — https://www.queensu.ca/registrar/financial-aid/application-required/future-students/major-awards
- 2027 Loran Award application — https://loranscholar.ca/the-program/how-to-apply/
- Loran Award structure/value — https://loranscholar.ca/the-program/how-it-works/

Records should be re-checked before each admission cycle and whenever a source page changes materially.


## V6 career labour-market sources (verified 2026-09-18)

Career wage references are drawn from Government of Canada Job Bank occupation pages. Pathway displays them as labour-market references, not guaranteed compensation.

- Investment Banking: Job Bank Investment Analyst, Toronto Region (used as a labour-market proxy; investment-banking bonuses are not captured)
- Software Engineering: Job Bank Computer Software Engineer, Toronto Region
- Registered Nurse: Job Bank Registered Nurse, Toronto Region
- Mechanical Engineering: Job Bank Mechanical Engineer, Toronto Region
- Lawyer: Job Bank Lawyer, Ontario
- UX / Product Design: Job Bank User Interface Designer, Toronto Region
- Electrician: Job Bank Electrician, Ontario
- Secondary School Teacher: Job Bank Secondary School Teacher, Ontario

## V6 admissions sources (verified 2026-09-18)

- Ivey AEO: Ivey HBA secondary-school admissions page
- Rotman Commerce: Rotman Commerce Ontario applicants page + U of T 2027 dates/deadlines
- Smith Commerce: Queen's Ontario admission requirements
- U of T Computer Science: U of T program page + 2027 dates/deadlines
- U of T Computer Engineering: U of T program page + 2027 dates/deadlines
- Waterloo Mechanical Engineering: Waterloo program page + 2027 deadlines/AIF pages
- U of T Biology for Health Sciences: U of T program page + 2027 dates/deadlines

## V7 expanded career library — September 26, 2026

Pathway V7 expands the searchable career library to more than 100 career profiles across technology, engineering, healthcare, science, law and public policy, business and operations, supply chain, education, design and media, architecture and construction, aviation, and skilled technical work.

### Wage reference

Career compensation references are based on the Government of Canada Job Bank Ontario wage report:

- https://www.jobbank.gc.ca/wagereport/location/ON
- Job Bank reports that the wage data on this page were updated November 19, 2025.
- Job Bank describes its low wage as generally corresponding to the 10th percentile, the median as the middle of the wage distribution, and the high wage as generally corresponding to the 90th percentile.
- Wage methodology: https://www.jobbank.gc.ca/trend-analysis/search-wages/wage-methodology

Some Pathway titles are more specialized than the official NOC occupational group. In those cases, the career page explicitly describes the displayed wage as a **related Job Bank benchmark** rather than an exact salary survey for that specialized title.

The library is meant for exploration, not salary guarantees. Students should use the linked Job Bank tools to compare current regional wages, job requirements, and outlooks before making education or career decisions.
