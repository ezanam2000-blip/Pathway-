import importlib
import os
import tempfile
from pathlib import Path


def test_v8_trust_home_and_activation():
    tmp=tempfile.NamedTemporaryFile(suffix=".db", delete=False); tmp.close()
    os.environ.pop("DATABASE_URL", None)
    os.environ["PATHWAY_DB_PATH"] = tmp.name
    os.environ["PATHWAY_BASE_URL"] = "http://testserver"
    os.environ["PATHWAY_OUTBOX_PATH"] = tmp.name + ".outbox"
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)
        with TestClient(app_module.app) as client:
            items=client.get("/api/content").json()["items"]
            careers=[x for x in items if x["type"]=="career"]
            deep=[x for x in careers if x["featured"]]
            assert len(careers) >= 100
            assert 20 <= len(deep) <= 35
            actuary=next(x for x in careers if x["title"]=="Actuary")
            assert actuary["salary_source_url"]
            assert actuary["salary_last_verified_date"]
            assert actuary["salary_region"] == "Ontario"
            rotman=next(x for x in items if x["id"]=="prog-rotman")
            assert rotman["requirements_source_url"]
            assert rotman["deadline_source_url"]
            assert rotman["deadline_last_verified_date"]
            assert "tuition" in rotman

            assert client.post("/api/auth/signup",json={"name":"Activation Student","email":"activation@example.com","password":"strongpass123"}).status_code==201
            assert client.post("/api/saved",json={"item_type":"career","item_id":actuary["id"]}).status_code==201
            assert client.post("/api/plan/generate",json={"item_type":"career","item_id":actuary["id"]}).status_code==201

        js=(Path(app_module.ROOT)/"static"/"app.js").read_text()
        assert "What are you trying to figure out?" in js
        assert "Deep guide" in js
        assert "Key dates" in js
        assert "Official source" in js
    finally:
        Path(tmp.name).unlink(missing_ok=True)
        Path(tmp.name + ".outbox").unlink(missing_ok=True)
