import importlib, os, tempfile
from pathlib import Path


def test_v7_has_large_diverse_career_library():
    tmp=tempfile.NamedTemporaryFile(suffix=".db",delete=False);tmp.close()
    os.environ["PATHWAY_DB_PATH"]=tmp.name
    os.environ["PATHWAY_OUTBOX_PATH"]=tmp.name+".outbox"
    os.environ["PATHWAY_BASE_URL"]="http://testserver"
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)
        with TestClient(app_module.app) as client:
            careers=client.get("/api/content?type=career").json()["items"]
            assert len(careers) >= 100
            titles={x["title"] for x in careers}
            for title in ["Actuary","Supply Chain Analyst","Data Scientist","Physiotherapist","Aerospace Engineer","Urban Planner","Technical Writer"]:
                assert title in titles
            industries={x["industry"] for x in careers}
            assert len(industries) >= 8
            actuary=next(x for x in careers if x["title"]=="Actuary")
            assert "Job Bank" in actuary["pay_range"]
            assert len(actuary["success_tips"]) >= 4
    finally:
        try: os.unlink(tmp.name)
        except OSError: pass
