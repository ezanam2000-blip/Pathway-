import importlib
import os
import tempfile
from pathlib import Path


def test_v13_adaptive_routes_and_top_five():
    tmp = tempfile.NamedTemporaryFile(suffix='.db', delete=False); tmp.close()
    os.environ.pop('DATABASE_URL', None)
    os.environ['PATHWAY_DB_PATH'] = tmp.name
    os.environ['PATHWAY_OUTBOX_PATH'] = tmp.name + '.outbox'
    os.environ['PATHWAY_BASE_URL'] = 'http://testserver'
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)
        with TestClient(app_module.app) as client:
            careers = client.get('/api/content?type=career').json()['items']
            by_title = {x['title']: x for x in careers}
            for title in ['Electrician', 'Plumber', 'HVAC / Refrigeration Mechanic', 'Police Officer', 'Firefighter', 'Paramedic', 'Emergency Services Dispatcher']:
                assert title in by_title
                assert by_title[title]['route_options']

            finance = client.post('/api/career-quiz', json={'answers':[
                'interest:finance','route:university','finance:deals','finance:numbers',
                'income:high','balance:intense_ok','value:income','value:challenge',
                'future:income_growth','pace:competitive'
            ]}).json()['items']
            assert len(finance) == 5
            assert finance[0]['title'] == 'Investment Banking'
            assert sum(x['title'] in {'Investment Banking','Investment Analyst','Actuary','Accountant','Financial Analyst','Financial Advisor'} for x in finance) >= 4

            trades = client.post('/api/career-quiz', json={'answers':[
                'interest:skilled_trades','route:apprenticeship','trade:plumbing_hvac','focus:repair',
                'income:balanced','balance:some','value:stability','entrepreneurship:maybe',
                'future:income_growth','environment:field_site'
            ]}).json()['items']
            assert len(trades) == 5
            assert {x['title'] for x in trades[:3]}.issuperset({'Plumber','HVAC / Refrigeration Mechanic'})

            safety = client.post('/api/career-quiz', json={'answers':[
                'interest:public_safety','route:college','safety:police','safety:community',
                'income:balanced','balance:some','value:helping_people','entrepreneurship:no',
                'future:specialist','safety:structured'
            ]}).json()['items']
            assert len(safety) == 5
            assert safety[0]['title'] == 'Police Officer'
            assert all(x['industry'] == 'Public Safety' for x in safety)

        js = (Path(app_module.ROOT) / 'static' / 'app.js').read_text()
        assert 'Police, fire & public safety' in js
        assert 'Which hands-on path interests you most?' in js
        assert 'Which part of finance interests you?' in js
        assert 'Your top 5 matches' in js
        assert 'No single career grade average' in js
    finally:
        Path(tmp.name).unlink(missing_ok=True)
        Path(tmp.name + '.outbox').unlink(missing_ok=True)
