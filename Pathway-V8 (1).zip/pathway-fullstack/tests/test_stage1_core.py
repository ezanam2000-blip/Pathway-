import importlib
import os
import tempfile
from pathlib import Path


def test_stage1_core_loop():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    os.environ.pop("DATABASE_URL", None)
    os.environ["PATHWAY_DB_PATH"] = tmp.name
    os.environ["PATHWAY_BASE_URL"] = "http://testserver"
    os.environ["PATHWAY_OUTBOX_PATH"] = tmp.name + ".outbox"
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)

        with TestClient(app_module.app) as client:
            items = client.get("/api/content").json()["items"]
            careers = [x for x in items if x["type"] == "career"]
            ib = next(x for x in careers if x["title"] == "Investment Banking")
            assert ib["quiz_weights"]["interest:finance"] > 0
            assert ib["hours"]
            assert ib["growth"]
            assert ib["competitiveness"]
            assert ib["remote_potential"]
            assert len(ib["career_timeline"]) >= 8
            assert [x["stage"] for x in ib["career_timeline"][:3]] == ["High school", "University", "Internships"]
            assert len(ib["roadmap"]) >= 5

            quiz = client.post("/api/career-quiz", json={"answers":[
                "interest:finance","environment:office_team","income:high","education:bachelor",
                "balance:intense_ok","entrepreneurship:maybe","value:income","value:challenge",
                "style:data","pace:competitive","output:business"
            ]})
            assert quiz.status_code == 200
            results = quiz.json()["items"]
            assert 5 <= len(results) <= 8
            assert all(x["quiz_reason"] for x in results)
            assert any(x["title"] == "Investment Banking" for x in results)

        js = (Path(app_module.ROOT) / "static" / "app.js").read_text()
        assert js.count("title:'") >= 10
        assert "Find My Career" in js
        assert "Career path" in js
        assert "Build My Plan" in js
        assert "Career Match results" in js
    finally:
        Path(tmp.name).unlink(missing_ok=True)
        Path(tmp.name + ".outbox").unlink(missing_ok=True)
