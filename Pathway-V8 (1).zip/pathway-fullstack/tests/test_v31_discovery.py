import importlib
import os

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client(tmp_path):
    os.environ.pop('DATABASE_URL', None)
    os.environ['PATHWAY_DB_PATH'] = str(tmp_path/'discovery.db')
    os.environ['PATHWAY_OUTBOX_PATH'] = str(tmp_path/'outbox')
    import app
    importlib.reload(app)
    with TestClient(app.app) as client:
        yield client


def signup(client, email='discovery@example.test'):
    response = client.post('/api/auth/signup', json={
        'name': 'QA explorer', 'email': email, 'password': 'local-test-only-123',
    })
    assert response.status_code == 201, response.text


def test_guest_skip_and_meaningful_preferences(client):
    assert len(client.get('/api/content').json()['items']) > 210
    for answers in ([], ['interest:open', 'route:open', 'stage:career'], ['not:a-real-preference']):
        response = client.post('/api/career-quiz', json={'answers': answers})
        assert response.status_code == 200
        assert response.json()['items'] == []
    first = client.post('/api/career-quiz', json={'answers': [
        'interest:technology', 'strength:analysis', 'subject:computing',
        'route:university', 'setting:desk', 'balance:priority',
    ]}).json()
    assert len(first['items']) == 5
    assert any('computing' in c['quiz_matches'] for c in first['items'])
    assert all(c['fit_notes'] and c['quiz_reason'] for c in first['items'])
    stage = client.post('/api/career-quiz', json={'answers': [
        'interest:technology', 'strength:analysis', 'subject:computing',
        'route:university', 'setting:desk', 'balance:priority', 'stage:career',
    ]}).json()
    assert [c['id'] for c in first['items']] == [c['id'] for c in stage['items']]


def test_discovery_document_persists_and_is_private(client):
    assert client.get('/api/me/discovery').status_code == 401
    assert client.put('/api/me/discovery', json={}).status_code == 401
    signup(client)
    careers = client.get('/api/content?type=career').json()['items']
    ids = [c['id'] for c in careers[:3]]
    document = {'answers': {'interest': ['interest:technology'], 'strengths': []},
                'step': 2, 'compare_ids': ids, 'comparisons': [{'ids': ids[:2]}],
                'result_ids': ids, 'completed': False}
    assert client.put('/api/me/discovery', json=document).status_code == 200
    saved = client.get('/api/me/discovery').json()['document']
    assert saved['answers'] == document['answers']
    assert saved['comparisons'] == document['comparisons']
    client.post('/api/auth/logout')
    signup(client, 'other-explorer@example.test')
    assert client.get('/api/me/discovery').json()['document'] is None
    client.post('/api/auth/logout')
    assert client.post('/api/auth/login', json={'email':'discovery@example.test', 'password':'local-test-only-123'}).status_code == 200
    assert client.get('/api/me/discovery').json()['document'] == saved
    assert client.delete('/api/me/discovery').status_code == 200
    assert client.get('/api/me/discovery').json()['document'] is None


@pytest.mark.parametrize('document', [
    {'step': 1000}, {'answers': {'email':['email:a@example.test']}},
    {'answers': {'interest':['a']*100}}, {'compare_ids':['x']*4},
    {'comparisons':[{'ids':['x','x']}]}, {'answers':{'strengths':['x'*81]}},
])
def test_discovery_bounds(client, document):
    signup(client)
    assert client.put('/api/me/discovery', json=document).status_code == 422


def test_history_clear_does_not_remove_bookmarks(client):
    signup(client)
    career = client.get('/api/content?type=career').json()['items'][0]
    assert client.post('/api/saved', json={'item_type':'career','item_id':career['id']}).status_code == 201
    client.put('/api/me/discovery', json={'answers':{'interest':['interest:science']}})
    client.delete('/api/me/discovery')
    assert len(client.get('/api/saved').json()['items']) == 1
    assert client.request('DELETE','/api/me',json={'password':'local-test-only-123'}).status_code == 200
    # The FK must clear discovery data when an account is deleted.
    import app
    con = app.connect()
    assert con.execute('SELECT COUNT(*) FROM discovery_states').fetchone()[0] == 0
    con.close()


def test_day_profiles_and_assets_are_complete(client):
    careers = client.get('/api/content?type=career').json()['items']
    for career in careers:
        profile = career['day_in_life']
        assert 1 <= len(profile['schedule']) <= 3
        assert all(s['phase'] and s['task'] for s in profile['schedule'])
        assert all(profile.get(k) for k in ('basis','environment','reward','reality','misconception'))
        assert profile['basis'].startswith('Illustrative')
    for path in ('/', '/privacy', '/terms', '/static/discovery.js', '/static/discovery.css'):
        assert client.get(path).status_code == 200
    index = client.get('/').text
    assert index.index('/static/app.js') < index.index('/static/discovery.js')


def test_new_roles_have_separate_overview_and_pay_provenance(client):
    careers = {c['title']:c for c in client.get('/api/content?type=career').json()['items']}
    assert len(careers) >= 219
    for title in ('Industrial Ecologist','Wind Energy Operations Manager','Medical Dosimetrist'):
        career = careers[title]
        assert career['source_url'].startswith(('https://www.onetonline.org/', 'https://www.bls.gov/'))
        assert career['last_verified_date'] == '2026-10-21'
        assert career['salary_last_verified_date'] is None
        assert career['salary_source_url'] is None
        assert career['outlook_last_verified_date'] is None
        assert 'Not yet verified' in career['pay_range']


def test_preference_words_do_not_match_unrelated_substrings():
    from discovery_state import context_matches
    website = {'title':'Website designer','day_to_day':'Build a website carefully.'}
    assert not context_matches(website, ['setting:outdoors','strength:people'])
    assert not context_matches({'title':'Biomedical researcher','industry':'Science & Environment'}, ['interest:environment'])
    assert context_matches({'skills':['Mathematics','Data analysis']}, ['subject:math'])


def test_discovery_survives_database_reinitialization(client):
    signup(client)
    client.put('/api/me/discovery', json={'answers':{'interest':['interest:science']},'step':1})
    with TestClient(client.app) as restarted:
        restarted.cookies.update(client.cookies)
        document = restarted.get('/api/me/discovery').json()['document']
        assert document['step'] == 1
        assert document['answers']['interest'] == ['interest:science']


def test_every_career_can_open_its_primary_roadmap(client):
    careers = client.get('/api/content?type=career').json()['items']
    for career in careers:
        routes = career.get('route_options') or []
        route = routes[0].get('type', 'open') if routes else 'open'
        result = client.get('/api/roadmaps/preview', params={
            'career_id':career['id'], 'grade':'Grade 11', 'route_key':route,
        })
        assert result.status_code == 200, (career['title'], result.text)
        assert result.json()['phases']
