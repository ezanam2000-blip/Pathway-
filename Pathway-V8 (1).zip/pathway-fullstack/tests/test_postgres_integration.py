"""Opt-in integration check; never use a production database URL."""
import os
from pathlib import Path
import subprocess
import sys
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
import uuid

import pytest


@pytest.mark.skipif(not os.getenv('PATHWAY_TEST_DATABASE_URL'), reason='No disposable PostgreSQL database configured')
def test_postgres_http_journey_in_isolated_schema(tmp_path):
    import psycopg
    from psycopg import sql
    url = os.environ['PATHWAY_TEST_DATABASE_URL']
    parsed = urlsplit(url)
    assert parsed.scheme in {'postgres', 'postgresql'}, 'Supply a disposable PostgreSQL URL.'
    schema = 'pathway_test_' + uuid.uuid4().hex
    params = [(k,v) for k,v in parse_qsl(parsed.query) if k != 'options']
    params.append(('options', '-csearch_path=' + schema))
    isolated_url = urlunsplit((parsed.scheme,parsed.netloc,parsed.path,urlencode(params),parsed.fragment))
    # This connection manages only a uniquely named test schema.
    with psycopg.connect(url, autocommit=True) as setup:
        setup.execute(sql.SQL('CREATE SCHEMA {}').format(sql.Identifier(schema)))
        try:
            environment = {**os.environ, 'DATABASE_URL':isolated_url, 'PATHWAY_ENV':'test', 'RENDER':'false',
                           'PATHWAY_BASE_URL':'http://testserver', 'PATHWAY_COOKIE_SECURE':'0',
                           'PATHWAY_ADMIN_EMAIL':'', 'PATHWAY_ADMIN_PASSWORD':'',
                           'PATHWAY_SMTP_HOST':'', 'PATHWAY_OUTBOX_PATH':str(tmp_path/'outbox')}
            subprocess.run([sys.executable, '-c', '''
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient
import app
with TestClient(app.app) as client:
    assert client.get('/api/health').status_code == 200
    assert len(client.get('/api/content?type=career').json()['items']) == 219
    assert client.get('/api/content?q=SOFTWARE').json()['items']
    assert not client.get('/api/content', params={'q':'%'}).json()['items']
    result=client.post('/api/auth/signup',json={'name':'Postgres QA','email':'postgres@example.test','password':'disposable-test-123'})
    assert result.status_code == 201, result.text
    user_id=client.get('/api/me').json()['user']['id']
    assert client.post('/api/saved',json={'item_type':'career','item_id':'career-software'}).status_code == 201
    assert client.put('/api/me/discovery',json={'answers':{'interest':['interest:technology']}}).status_code == 200
    token=app.create_auth_token(user_id,'password_reset',1)
    with ThreadPoolExecutor(max_workers=2) as executor:
        claims=list(executor.map(lambda _:app.consume_auth_token(token,'password_reset'),range(2)))
    assert claims.count(user_id) == 1 and claims.count(None) == 1
    assert client.request('DELETE','/api/me',json={'password':'disposable-test-123'}).status_code == 200
    for _ in range(6):
        assert client.get('/api/content?q=SOFTWARE').status_code == 200
    assert app._DB_POOL.get_stats()['pool_available'] >= 1
assert app._DB_POOL is None
'''], cwd=Path(__file__).resolve().parents[1], env=environment, check=True, timeout=90)
        finally:
            setup.execute(sql.SQL('DROP SCHEMA {} CASCADE').format(sql.Identifier(schema)))
