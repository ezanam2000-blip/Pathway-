from test_v31_discovery import client


def test_removed_feature_does_not_load_and_old_url_redirects(client):
    page = client.get('/').text
    assert 'international.js' not in page
    assert '/static/discovery.js?v=35' in page
    assert client.get('/static/international.js').status_code == 404
    old_link = client.get('/study-abroad', follow_redirects=False)
    assert old_link.status_code == 307
    assert old_link.headers['location'] == '/#/education'
    assert client.get('/education').status_code == 200
    for path in ('/api/content?type=program', '/api/content?type=scholarship'):
        assert client.get(path).json()['items']
