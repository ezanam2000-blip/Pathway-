from career_clarity import ALL_EXPLANATIONS
from test_v31_discovery import client


def test_every_live_career_has_a_short_complete_explanation(client):
    careers = client.get('/api/content?type=career').json()['items']
    assert len(ALL_EXPLANATIONS) == 220
    assert len(careers) == 219
    assert set(ALL_EXPLANATIONS)-{c['title'] for c in careers} == {'Entrepreneurship'}
    for career in careers:
        copy = career['description']
        assert copy == ALL_EXPLANATIONS[career['title']]
        assert copy.endswith('.')
        assert 18 <= len(copy.split()) <= 65, career['title']
        assert career['plain_tasks'] and career['plain_tasks'].endswith('.')
        assert '…' not in copy


def test_creative_portfolio_is_not_investment_matching(client):
    careers = client.get('/api/content?type=career').json()['items']
    for title in ('Music Metadata Specialist', 'Graphic Designer', 'UX Designer', 'Product Designer'):
        item = next(c for c in careers if c['title'] == title)
        assert not any(k.startswith('finance:') for k in item['quiz_weights']), title
        assert not item['quiz_weights'].get('interest:finance'), title
    response = client.post('/api/career-quiz', json={'answers': [
        'interest:finance', 'route:university', 'finance:markets',
        'finance:numbers', 'strength:analysis', 'subject:math',
    ]}).json()
    assert len(response['items']) == 5
    for item in response['items'] + ([response['discovery_pick']] if response['discovery_pick'] else []):
        assert len(item['quiz_matches']) == len(set(item['quiz_matches']))
        if item['title'] == 'Music Metadata Specialist':
            assert 'markets' not in item['quiz_reason']


def test_updated_page_uses_current_assets(client):
    page = client.get('/').text
    assert '/static/discovery.js?v=35' in page
    assert client.get('/api/health').json()['version'] == '6.6.0'
