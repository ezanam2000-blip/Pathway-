/* Real HTTP API + actual renderer/event-handler tests in a lightweight DOM stub.
 * This does NOT claim browser layout, screen-reader or real-device coverage.
 * Run from the project root: node tests/frontend_v31.cjs
 * Install requirements-dev.txt and set PYTHON to that interpreter if necessary.
 */
const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const assert=require('node:assert/strict'),os=require('node:os');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'pathway-v31-'));
const server=spawn(process.env.PYTHON||'python',['-m','uvicorn','app:app','--host','127.0.0.1','--port','8765'],
  {cwd:root,env:{...process.env,DATABASE_URL:'',PATHWAY_DB_PATH:path.join(temp,'test.db'),PATHWAY_OUTBOX_PATH:path.join(temp,'outbox')},stdio:['ignore','pipe','pipe']});
let cookie='';const storage=new Map(),appElement={innerHTML:''};
async function httpFetch(url,init={}){
  const response=await fetch('http://127.0.0.1:8765'+url,{...init,headers:{...init.headers,...(cookie?{cookie}:{})}});
  const set=response.headers.get('set-cookie');if(set)cookie=set.split(';')[0];return response;
}
function context(){
  const listeners=new Map(),entries=[];let index=-1;
  const location={search:'',pathname:'/',hash:'',origin:'https://pathway.example.test'};
  const window={scrollY:0,scrollTo(x,y){this.scrollY=y||0},addEventListener(name,fn){listeners.set(name,fn)}};
  const history={get state(){return entries[index]?.state||null},get length(){return entries.length},
    replaceState(state,title,url){if(index<0){index=0;entries.push({})}entries[index]={state:structuredClone(state),url:url||entries[index]?.url||location.hash};if(url!==undefined)location.hash=url},
    pushState(state,title,url){entries.splice(index+1);entries.push({state:structuredClone(state),url});index++;location.hash=url},
    back(){if(index>0){index--;location.hash=entries[index].url;listeners.get('popstate')?.({state:this.state})}},
    forward(){if(index+1<entries.length){index++;location.hash=entries[index].url;listeners.get('popstate')?.({state:this.state})}}};
  const document={addEventListener(){},activeElement:null,getElementById:id=>id==='app'?appElement:null,
    querySelector:()=>null,querySelectorAll:()=>[],body:{style:{},insertAdjacentHTML(){}},documentElement:{classList:{add(){}}}};
  const ctx=vm.createContext({console,assert,TypeError,URLSearchParams,AbortController,Response,fetch:httpFetch,confirm:()=>true,
    location,history,navigator:{},
    setTimeout:()=>0,clearTimeout(){},window,document,
    localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,val)=>storage.set(key,val),removeItem:key=>storage.delete(key)}});
  for(const file of ['app.js','discovery.js'])vm.runInContext(fs.readFileSync(path.join(root,'static',file),'utf8').replace('configureIOSApp().finally(()=>bootstrap());',''),ctx,{filename:file});
  return ctx;
}
const run=(ctx,script)=>vm.runInContext(script,ctx);
function handlersCompile(html){
  const decode=s=>s.replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
  for(const match of html.matchAll(/\bon(?:click|change|input|submit|keydown)="([^"]*)"/g)){
    assert.doesNotThrow(()=>new vm.Script('(function(event){'+decode(match[1])+'})'),match[1]);
  }
}
(async()=>{
  await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('Local API did not start.')),12000);
    server.once('error',reject);server.stderr.on('data',data=>{if(String(data).includes('Application startup complete')){clearTimeout(timeout);resolve()}});
    server.once('exit',code=>reject(new Error('Local API stopped: '+code)));});
  let ctx=context();await run(ctx,'bootstrap()');
  assert.ok(run(ctx,"state.content.filter(x=>x.type==='career').length")>=217);
  assert.equal(run(ctx,'state.screen'),'landing');assert.ok(run(ctx,'landing()').includes('Discover My Path'));
  // Selecting an answer must update the existing controls, not replace them.
  run(ctx, `startCareerQuiz(true);
    const originalAll=document.querySelectorAll,originalQuery=document.querySelector;
    const originalRender=render;let selectionRenders=0;
    const marker={textContent:'+'},selectionStatus={textContent:''},nextControl={disabled:true};
    const stableControl={classList:{toggle(name,value){this.selected=value}},
      getAttribute(){return 'interest:technology'},setAttribute(name,value){this[name]=value},querySelector(){return marker}};
    document.querySelectorAll=selector=>selector==='[data-quiz-value]'?[stableControl]:[];
    document.querySelector=selector=>selector==='.v27-selected-status'?selectionStatus:selector==='.discovery-quiz-actions .btn.primary'?nextControl:null;
    render=()=>{selectionRenders++};toggleQuiz('interest:technology');
    assert.equal(selectionRenders,0);assert.equal(stableControl['aria-pressed'],'true');assert.equal(nextControl.disabled,false);assert.equal(marker.textContent,'✓');
    toggleQuiz('interest:technology');assert.equal(nextControl.disabled,true);assert.equal(marker.textContent,'+');
    render=originalRender;document.querySelectorAll=originalAll;document.querySelector=originalQuery;
  `);
  run(ctx,"setView('explore')");assert.ok(appElement.innerHTML.includes('career-card'));assert.ok(!run(ctx,'topbar()').includes('profile-btn'));
  // Actual history snapshots restore search, filters, quiz steps and details.
  run(ctx,`state.query='data';state.category='Technology';state.careerLimit=48;render();
    const firstCareer=state.content.find(x=>x.type==='career');openDetail('career',firstCareer.id);
    assert.ok(location.hash.startsWith('#/career/'));history.back();
    assert.equal(state.detail,null);assert.equal(state.query,'data');assert.equal(state.category,'Technology');
    history.forward();assert.equal(state.detail.id,firstCareer.id);closeDetail();
    openCompare();returnFromCompare();assert.equal(state.view,'explore');
    history.back();assert.notEqual(state.view,'compare');
    startCareerQuiz(true);toggleQuiz('interest:technology');nextQuiz();
    assert.equal(state.quizStep,1);history.back();assert.equal(state.quizStep,0);
    assert.equal(state.quizAnswersByStep.interest[0],'interest:technology');
    const privateSnapshot={...navigationSnapshot(),owner:999,screen:'app',view:'mypath'};
    restoreNavigation(privateSnapshot);assert.equal(state.screen,'landing');assert.equal(state.view,'home');
    startCareerQuiz(true);setView('explore');
  `);
  run(ctx, `state.query='  nursing  ';assert.ok(filteredCareers().some(c=>c.title==='Registered Nurse'));
    state.query='coding';assert.ok(filteredCareers().some(c=>c.title==='Software Engineering'));
    state.query='data scientist';assert.equal(filteredCareers()[0].title,'Data Scientist');
    state.category='Technology';state.careerLimit=48;openCompare();returnFromCompare();
    assert.equal(state.view,'explore');assert.equal(state.query,'data scientist');assert.equal(state.category,'Technology');assert.equal(state.careerLimit,48);
    browseHobby('music');assert.equal(state.category,'all');assert.ok(filteredCareers().some(c=>c.title==='Music Metadata Specialist'));
    state.query='zzxx-no-career';assert.ok(explore().includes('Show all careers'));clearCareerFilters();
  `);
  run(ctx,"startCareerQuiz();toggleQuiz('interest:technology');nextQuiz();toggleQuiz('strength:analysis');nextQuiz();toggleQuiz('subject:computing');nextQuiz();toggleQuiz('route:university');nextQuiz();toggleQuiz('focus:code');nextQuiz();toggleQuiz('style:data');nextQuiz();toggleQuiz('setting:desk');nextQuiz();toggleQuiz('balance:priority');nextQuiz();toggleQuiz('value:challenge');nextQuiz();toggleQuiz('stage:senior')");
  assert.equal(run(ctx,'currentQuizQuestion().id'),'stage');
  await run(ctx,'finishCareerQuiz()');assert.equal(run(ctx,'state.quizStep'),10);
  assert.equal((run(ctx,'careerQuiz()').match(/class="v27-match-card /g)||[]).length,3);
  const resultHTML=run(ctx,'careerQuiz()');
  assert.ok(resultHTML.includes('compact-pay'));
  assert.ok(!resultHTML.includes('Typical education'));
  assert.ok(!resultHTML.includes('Common routes include'));
  assert.ok(resultHTML.includes('View career →'));
  assert.ok(!run(ctx,'careerDetail(state.quizResults[0])').includes('mobile-career-accordion" open'));
  run(ctx,'state.showAllMatches=true');assert.equal((run(ctx,'careerQuiz()').match(/class="v27-match-card /g)||[]).length,5);
  await run(ctx,"toggleSave('career',state.quizResults[0].id)");run(ctx,'toggleCompare(state.quizResults[0].id);toggleCompare(state.quizResults[1].id);saveComparison()');
  assert.equal(run(ctx,'state.comparisons.length'),1);
  run(ctx,'toggleCompare(state.quizResults[2].id);toggleCompare(state.quizResults[3].id)');
  assert.equal(run(ctx,'state.compareIds.length'),3);assert.ok(run(ctx,'state.toast').includes('three'));
  // Mobile comparison uses the same values as desktop for every chosen job.
  const comparison=run(ctx,'comparisonPage()');
  assert.ok(comparison.includes('class="mobile-comparison"'));
  assert.ok(comparison.includes('desktop-comparison'));
  assert.ok(!comparison.includes('scroll sideways on a phone'));
  const mobile=run(ctx,"mobileComparison(allCompareCareers(),[['Pay',x=>esc(x.pay_range||'No verified benchmark')]])");
  for(const career of run(ctx,'allCompareCareers()')){
    assert.ok(mobile.includes(career.title));
    assert.ok(mobile.includes(career.pay_range||'No verified benchmark'));
    assert.ok(mobile.includes(career.id));
  }
  run(ctx,'toggleCompare(state.quizResults[2].id);saveComparison()');assert.equal(run(ctx,'state.comparisons.length'),1);
  assert.ok(!run(ctx,'comparisonPage()').includes('Education cost'));
  run(ctx,'state.compareExpanded=true');
  assert.ok(run(ctx,'comparisonPage()').includes('Education cost'));
  assert.ok(run(ctx,'comparisonPage()').includes('Not verified. Depends'));
  run(ctx,'state.compareExpanded=false');
  // Simulated page refresh: a new JS realm, same local storage and actual API.
  ctx=context();await run(ctx,'bootstrap()');assert.equal(run(ctx,'state.quizStep'),10);
  assert.equal(run(ctx,'state.saved.length'),1);assert.equal(run(ctx,'state.compareIds.length'),2);assert.equal(run(ctx,'state.comparisons.length'),1);
  run(ctx,"editQuizAnswers();toggleQuiz('interest:technology');toggleQuiz('interest:finance')");
  assert.equal(run(ctx,'state.quizAnswersByStep.path_detail.length'),0); // changed branch only
  assert.equal(run(ctx,'state.quizAnswersByStep.balance[0]'),'balance:priority');
  assert.equal(run(ctx,'state.quizAnswersByStep.subjects[0]'),'subject:computing');
  run(ctx,"toggleQuiz('interest:business');toggleQuiz('interest:healthcare');toggleQuiz('interest:science');toggleQuiz('interest:creative')");
  assert.ok(run(ctx,'state.toast').includes('up to 4'));
  run(ctx,"state.quizLoading=true;const before=JSON.stringify(state.quizAnswersByStep);toggleQuiz('interest:open');nextQuiz();assert.equal(JSON.stringify(state.quizAnswersByStep),before);state.quizLoading=false");
  run(ctx,"startCareerQuiz(true)");for(let i=0;i<9;i++)run(ctx,'skipQuiz()');await run(ctx,'finishCareerQuiz()');
  assert.equal(run(ctx,'state.quizResults.length'),0);assert.ok(run(ctx,'careerQuiz()').includes('Browse all careers'));
  // A late response from an abandoned quiz must not overwrite a new attempt.
  const originalFetch=ctx.fetch;let releaseQuiz;
  ctx.fetch=(url,init)=>url==='/api/career-quiz'?new Promise(resolve=>{releaseQuiz=()=>resolve({ok:true,text:async()=>JSON.stringify({items:[{id:'stale-career'}]})})}):originalFetch(url,init);
  const oldQuiz=run(ctx,'finishCareerQuiz()');run(ctx,'startCareerQuiz(true)');releaseQuiz();await oldQuiz;
  assert.equal(run(ctx,'state.quizStep'),0);assert.equal(run(ctx,'state.quizResults.length'),0);assert.equal(run(ctx,'state.quizLoading'),false);
  ctx.fetch=originalFetch;
  // Account persistence and guest/account separation through the real API.
  await run(ctx,"(async()=>{const r=await api('/api/auth/signup',{method:'POST',body:JSON.stringify({name:'QA explorer',email:'vm@example.test',password:'disposable-test-123'})});resetDiscoveryMemory();state.user=r.user;await refreshAll();await restoreDiscovery();startCareerQuiz();toggleQuiz('interest:science');nextQuiz();await syncDiscovery()})()");
  const saved=await run(ctx,"api('/api/me/discovery')");assert.equal(JSON.stringify(saved.document.answers.interest),JSON.stringify(['interest:science']));
  // Repeated taps during an account save must make only one server write.
  const accountFetch=ctx.fetch;let releaseSave,savePosts=0;
  const saveGate=new Promise(resolve=>{releaseSave=resolve});
  ctx.fetch=async(url,init)=>{if(url==='/api/saved'&&init?.method==='POST'){savePosts++;await saveGate}return accountFetch(url,init)};
  const saveCommand="toggleSave('career',state.content.find(c=>c.type==='career').id)";
  const firstSave=run(ctx,saveCommand),secondSave=run(ctx,saveCommand);
  assert.equal(savePosts,1);releaseSave();await Promise.all([firstSave,secondSave]);ctx.fetch=accountFetch;
  assert.equal(run(ctx,'state.saved.length'),1);
  assert.ok(run(ctx,'discoveryDashboard()').includes('Saved careers & education'));
  ctx=context();await run(ctx,'bootstrap()');assert.equal(run(ctx,'state.quizAnswers[0]'),'interest:science');assert.equal(run(ctx,'state.quizStep'),1);
  const realFetch=ctx.fetch;let failDiscoveryRead=true;
  run(ctx,'localStorage.removeItem(discoveryKey());state.quizAnswersByStep={};state.quizAnswers=[]');
  ctx.fetch=async(url,init)=>{if(url==='/api/me/discovery'&&(!init?.method||init.method==='GET')&&failDiscoveryRead){failDiscoveryRead=false;throw new TypeError('offline')}return realFetch(url,init)};
  await run(ctx,'restoreDiscovery()');assert.equal(run(ctx,'state.discoveryReady'),false);
  await run(ctx,'retryDiscoverySync()');assert.equal(run(ctx,'state.quizAnswers[0]'),'interest:science');
  assert.equal((await run(ctx,"api('/api/me/discovery')")).document.answers.interest[0],'interest:science');
  ctx.fetch=realFetch;
  run(ctx,'state.planTasks=[{id:1,title:"Keep this task",completed:false}]');await run(ctx,'forgetDiscovery()');
  assert.equal(run(ctx,'state.planTasks.length'),1);assert.equal(run(ctx,'state.quizAnswers.length'),0);
  assert.equal((await run(ctx,"api('/api/me/discovery')")).document,null);
  await run(ctx,'logout()');assert.equal(run(ctx,'state.user'),null);
  // Closed awards must be unmistakable on cards and detail pages.
  run(ctx,`const closedAward=state.content.find(x=>x.id==='sch-loran-2027');
    assert.ok(scholarshipCard(closedAward).includes('Deadline passed'));
    assert.ok(scholarshipDetail(closedAward).includes('This application deadline has passed.'));
    assert.ok(scholarshipDetail(closedAward).includes('A new deadline has not been recorded.'));
  `);
  // Quotes and backslashes in data must remain one literal handler argument.
  const hostileName=`Student's \\ School ");globalThis.injected=true;//`;
  ctx.hostileName=hostileName;
  const hostileHTML=run(ctx,'universityCard(hostileName)');handlersCompile(hostileHTML);
  const universityHandler=hostileHTML.match(/onclick="([^"]*)"/)[1].replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
  run(ctx,universityHandler);assert.equal(run(ctx,'state.detail.name'),hostileName);assert.equal(run(ctx,'globalThis.injected'),undefined);
  run(ctx,'closeDetail()');
  // Password confirmation, errors and double taps through the actual API.
  await run(ctx,`(async()=>{const account=await api('/api/auth/login',{method:'POST',body:JSON.stringify({email:'vm@example.test',password:'disposable-test-123'})});state.user=account.user;await restoreDiscovery();state.screen='app';deleteAccount()})()`);
  assert.ok(run(ctx,'accountDeleteDialog()').includes('Confirm your current password'));
  await run(ctx,"confirmAccountDeletion({preventDefault(){},target:{querySelector(){return {value:'wrong-password'}}}})");
  assert.ok(run(ctx,'state.deleteError').length>0);assert.ok(run(ctx,'state.user'));assert.equal((await run(ctx,"api('/api/me')")).user.email,'vm@example.test');
  const deleteFetch=ctx.fetch;let releaseDelete,deletes=0;
  const deleteGate=new Promise(resolve=>{releaseDelete=resolve});
  ctx.fetch=async(url,init)=>{if(url==='/api/me'&&init?.method==='DELETE'){deletes++;await deleteGate}return deleteFetch(url,init)};
  const deletion="confirmAccountDeletion({preventDefault(){},target:{querySelector(){return {value:'disposable-test-123'}}}})";
  const firstDelete=run(ctx,deletion),secondDelete=run(ctx,deletion);assert.equal(deletes,1);releaseDelete();await Promise.all([firstDelete,secondDelete]);
  assert.equal(run(ctx,'state.user'),null);assert.equal(run(ctx,'state.detail'),null);assert.equal(run(ctx,'state.screen'),'landing');ctx.fetch=deleteFetch;
  // All visible handlers compile across every career and main navigation view.
  for(const view of ['home','explore','universities','scholarships','careerquiz','compare','mypath','tools','admissions','advisor']){
    run(ctx,`setView('${view}')`);handlersCompile(appElement.innerHTML);
    assert.doesNotMatch(appElement.innerHTML,/openStudyAbroad|studyForCareer|Study abroad|International funding/);
  }
  const count=run(ctx,"state.content.filter(x=>x.type==='career').length");
  for(let i=0;i<count;i++){
    const careerHTML=run(ctx,`careerDetail(state.content.filter(x=>x.type==='career')[${i}])`);
    handlersCompile(careerHTML);assert.doesNotMatch(careerHTML,/studyForCareer|openStudyAbroad/);
  }
  run(ctx,`assert.equal(typeof studyAbroad,'undefined');assert.equal(typeof openStudyAbroad,'undefined');
    assert.equal(typeof INTERNATIONAL_GUIDES,'undefined');
    location.hash='#/study-abroad';restoreInitialRoute();render();assert.equal(state.view,'universities');
    assert.equal(location.hash,'#/education');setView('studyabroad');assert.equal(state.view,'universities');
    setView('scholarships');assert.ok(scholarships().includes('Search scholarships'));
    state.query='zz-no-award';assert.ok(scholarships().includes('Try fewer words.'));state.query='';
  `);
  assert.equal(run(ctx,'payGrowthBlock({pay_range:"$40,000–$90,000"})'),'');
  // Corrupt/blocked storage and structured API errors must be readable.
  storage.set('pathway:discovery:1:guest','{bad');assert.equal(run(ctx,'readDiscovery()'),null);
  run(ctx,"localStorage.setItem=()=>{throw Error('blocked')};persistDiscovery()");assert.ok(run(ctx,'discoverySaveText()').includes('unavailable'));
  ctx.fetch=async()=>({ok:false,status:422,text:async()=>JSON.stringify({detail:[{msg:'bad'}]})});
  await assert.rejects(run(ctx,"api('/api/career-quiz')"),/Check your answers/);
  ctx.fetch=async()=>{throw new TypeError('network')};await run(ctx,'retryCatalog()');assert.ok(run(ctx,'state.catalogError').includes('Unable to connect'));
  // A previously fetched catalog is available when a later refresh fails.
  const cacheEntries=new Map();ctx.window.caches={open:async()=>({put:async(key,response)=>cacheEntries.set(key,response.clone()),match:async key=>cacheEntries.get(key)?.clone()})};
  ctx.fetch=originalFetch;await run(ctx,'loadCatalog()');assert.ok(cacheEntries.has('/api/content'));
  ctx.fetch=async()=>{throw new TypeError('offline')};const offline=await run(ctx,'loadCatalog()');
  assert.ok(offline.items.length>210);assert.equal(run(ctx,'state.catalogOffline'),true);
  ctx.fetch=originalFetch;await run(ctx,'loadCatalog()');assert.equal(run(ctx,'state.catalogOffline'),false);
  console.log(`V35 full-stack checks passed: compact cards, mobile comparison content, stable selections, search/filter return, browser history, stale quiz protection, guest resume/saves, study-abroad removal, account isolation/deletion, closed awards, safe data arguments, catalog fallback and readable errors; all ${count} career renderers and 10 navigation views. Layout/device QA remains separate.`);
})().catch(error=>{console.error(error);process.exitCode=1}).finally(()=>{
  server.kill('SIGTERM');server.once('exit',()=>fs.rmSync(temp,{recursive:true,force:true}));
});
