"""V27: short discovery experience, less obvious careers, cautious international links."""
import importlib
import os
import tempfile
from pathlib import Path


def test_v27_discovery_study_abroad_and_compact_results():
    f = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
    f.close()
    os.environ.pop('DATABASE_URL', None)
    os.environ['PATHWAY_DB_PATH'] = f.name
    os.environ['PATHWAY_OUTBOX_PATH'] = f.name + '.outbox'
    os.environ['PATHWAY_BASE_URL'] = 'http://testserver'
    try:
        from fastapi.testclient import TestClient
        import app as application
        importlib.reload(application)
        with TestClient(application.app) as client:
            health = client.get('/api/health')
            assert health.status_code == 200 and health.json()['version'] == application.APP_VERSION
            response = client.get('/api/content?type=career')
            assert response.status_code == 200
            careers = response.json()['items']
            assert len(careers) >= 185
            named = {item['title']: item for item in careers}
            for title in ('Accessibility Designer', 'GIS Mapping Analyst', 'Forensic Accountant', 'Digital Preservation Specialist', 'Supply Chain Sustainability Analyst'):
                assert title in named
                assert 'Unexpected Path' in named[title]['tags']
                assert 'occupation group' in named[title]['pay_note']
            matches = client.post('/api/career-quiz', json={'answers':[
                'interest:finance','route:university','finance:markets','finance:numbers',
                'income:high','balance:some','value:challenge',
                'entrepreneurship:maybe','future:income_growth','focus:business',
            ]})
            assert matches.status_code == 200, matches.text
            payload = matches.json()
            assert len(payload['items']) == 5
            assert 'discovery_pick' in payload
            if payload['discovery_pick']:
                assert payload['discovery_pick']['quiz_score'] > 0
                assert payload['discovery_pick']['id'] not in {c['id'] for c in payload['items']}
                assert 'Unexpected Path' in payload['discovery_pick']['tags']
        js = (Path(application.ROOT)/'static/app.js').read_text() + (Path(application.ROOT)/'static/international.js').read_text()
        for token in ('function dayInLife(', 'function studyAbroad(', 'function comparisonPage(', 'state.showAllMatches', 'v27-match-card', 'Show 2 more careers', 'What you may actually do', 'educationusa.state.gov', 'study-uk.britishcouncil.org', 'daad.de', 'studyaustralia.gov.au'):
            assert token in js, token
        css = (Path(application.ROOT)/'static/styles.css').read_text()
        assert '.v27-match-card' in css and '.v27-abroad-card' in css
        index = (Path(application.ROOT)/'static/index.html').read_text()
        assert '/static/app.js?v=' in index
        assert '/static/discovery.js?v=' in index
    finally:
        Path(f.name).unlink(missing_ok=True)
        Path(f.name+'.outbox').unlink(missing_ok=True)
