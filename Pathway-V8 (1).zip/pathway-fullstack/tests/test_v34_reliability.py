"""Regression checks for the uploaded audit. All data is disposable."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date
import pytest
from fastapi import HTTPException, Response
from fastapi.testclient import TestClient
from test_v31_discovery import client, signup
from reliability import application_deadline_status, postgres_sql


def operator(client):
    signup(client)
    import app
    with app.connect() as con:
        con.execute('UPDATE users SET is_admin=1,email_verified=1')
        con.commit()
    return client.get('/api/me').json()['user']


def test_admin_edits_and_archives_survive_restarts(client):
    import app
    admin = operator(client)
    for kind, item_id in [('career','career-finance'), ('program','prog-smith'), ('scholarship','sch-loran-2027')]:
        data = app.AdminContentIn(title='Edited by operator', description='Keep this description.',
                                  status='needs_review', deadline='Review a new cycle')
        app.admin_write(kind, data, admin, item_id)
        app.init_db()
        item = client.get(f'/api/content/{kind}/{item_id}').json()['item']
        assert item['title'] == 'Edited by operator' and item['status'] == 'needs_review'
        assert item['description'] == 'Keep this description.'
        app.admin_archive(kind, item_id, admin)
        app.init_db()
        assert client.get(f'/api/content/{kind}/{item_id}').status_code == 404


def test_existing_signup_cannot_become_seed_admin(client, monkeypatch):
    signup(client, 'operator@example.test')
    import app
    monkeypatch.setenv('PATHWAY_ADMIN_EMAIL', 'operator@example.test')
    monkeypatch.setenv('PATHWAY_ADMIN_PASSWORD', 'a-different-bootstrap-secret')
    app.init_db()
    assert not client.get('/api/me').json()['user']['is_admin']
    assert client.get('/api/admin/stats').status_code == 403


def test_operator_recovery_requires_explicit_promotion_and_revokes_sessions(client):
    signup(client)
    from manage_admin import reset_admin
    with pytest.raises(ValueError, match='not an admin'):
        reset_admin('discovery@example.test', 'replacement-test-password')
    assert client.get('/api/me').status_code == 200
    reset_admin('discovery@example.test', 'replacement-test-password', grant_admin=True)
    assert client.get('/api/me').status_code == 401
    assert client.post('/api/auth/login', json={'email':'discovery@example.test','password':'local-test-only-123'}).status_code == 401
    assert client.post('/api/auth/login', json={'email':'discovery@example.test','password':'replacement-test-password'}).status_code == 200
    assert client.get('/api/me').json()['user']['is_admin']


def test_two_devices_and_session_cap(client):
    signup(client)
    import app
    second = TestClient(app.app)
    try:
        assert second.post('/api/auth/login', json={'email':'discovery@example.test','password':'local-test-only-123'}).status_code == 200
        assert client.get('/api/me').status_code == second.get('/api/me').status_code == 200
        assert second.post('/api/auth/logout').status_code == 200
        assert client.get('/api/me').status_code == 200
        user_id = client.get('/api/me').json()['user']['id']
        for _ in range(12):
            app.create_session(Response(), user_id)
        with app.connect() as con:
            assert con.execute('SELECT COUNT(*) AS n FROM sessions WHERE user_id=?', (user_id,)).fetchone()['n'] == 10
    finally:
        second.close()


def test_drafts_are_private_in_lists_details_quiz_and_roadmaps(client):
    import app
    with app.connect() as con:
        con.execute("UPDATE careers SET status='draft' WHERE id='career-finance'")
        con.commit()
    assert 'career-finance' not in {c['id'] for c in client.get('/api/content?include_preview=true').json()['items']}
    assert client.get('/api/content/career/career-finance').status_code == 404
    assert client.get('/api/roadmaps/preview?career_id=career-finance&grade=Grade%2011&route_key=university').status_code == 404
    quiz = client.post('/api/career-quiz', json={'answers':['interest:finance']}).json()
    assert 'career-finance' not in {c['id'] for c in quiz['items']}
    signup(client)
    assert client.post('/api/saved', json={'item_type':'career','item_id':'career-finance'}).status_code == 404


def test_expired_awards_have_closed_status_and_are_not_featured(client):
    items = client.get('/api/content?type=scholarship').json()['items']
    loran = next(x for x in items if x['id'] == 'sch-loran-2027')
    assert loran['deadline_date'] == '2026-10-15'
    assert loran['deadline_status'] == 'closed' and not loran['featured']
    assert application_deadline_status('2026-10-22', date(2026,10,22)) == 'due_today'
    assert application_deadline_status(None) == 'check_source'


def test_catalog_compression_etags_literal_search_and_missing_assets(client):
    response = client.get('/api/content', headers={'Accept-Encoding':'gzip'})
    assert response.headers['content-encoding'] == 'gzip'
    assert client.get('/api/content', headers={'If-None-Match':response.headers['etag']}).status_code == 304
    for term in ('%', '_', 'zz-no-such-role'):
        assert client.get('/api/content', params={'q':term}).json()['items'] == []
    assert client.get('/api/content?q=SOFTWARE').json()['items']
    assert client.get('/api/content', params={'q':'a'*161}).status_code == 422
    assert client.get('/').headers['cache-control'] == 'no-cache'
    for path in ('/favicon.ico','/missing.js','/api/not-a-route','/unknown-route'):
        assert client.get(path).status_code == 404
    assert client.get('/manifest.json').json()['name'] == 'Pathway'
    assert client.get('/support').status_code == 200


def test_account_limits_persist_and_ignore_forwarded_header_rotation(client):
    signup(client)
    import app
    for index in range(8):
        response = client.post('/api/auth/login', json={'email':'discovery@example.test','password':'wrong'}, headers={'X-Forwarded-For':f'192.0.2.{index}'})
        assert response.status_code == 401
    app.init_db()
    response = client.post('/api/auth/login', json={'email':'discovery@example.test','password':'wrong'}, headers={'X-Forwarded-For':'198.51.100.1'})
    assert response.status_code == 429 and int(response.headers['retry-after']) > 0


def test_analytics_and_request_sizes_are_bounded(client):
    huge = {'event_name':'career_search','metadata':{'source':'x'*3000}}
    assert client.post('/api/analytics/event', json=huge).status_code == 422
    assert client.post('/api/analytics/event', content=b'x'*70000, headers={'Content-Type':'application/json'}).status_code == 413
    import app
    assert client.post('/api/analytics/event', json={'event_name':'career_search','metadata':{'email':'do-not-keep@example.test','count':1}}).status_code == 201
    with app.connect() as con:
        row=con.execute("SELECT metadata_json FROM analytics_events ORDER BY id DESC LIMIT 1").fetchone()
        assert 'email' not in row['metadata_json'] and 'count' in row['metadata_json']
    for _ in range(39):
        assert client.post('/api/analytics/event', json={'event_name':'career_search'}).status_code == 201
    assert client.post('/api/analytics/event', json={'event_name':'career_search'}).status_code == 429


def test_tokens_can_only_be_claimed_once_even_concurrently(client):
    signup(client)
    import app
    user_id=client.get('/api/me').json()['user']['id']
    token=app.create_auth_token(user_id, 'password_reset', 1)
    with ThreadPoolExecutor(max_workers=2) as executor:
        results=list(executor.map(lambda _:app.consume_auth_token(token,'password_reset'), range(2)))
    assert results.count(user_id) == 1 and results.count(None) == 1


def test_password_confirmation_for_account_deletion(client):
    signup(client)
    assert client.request('DELETE','/api/me',json={'password':'wrong'}).status_code == 401
    assert client.get('/api/me').status_code == 200
    assert client.request('DELETE','/api/me',json={'password':'local-test-only-123'}).status_code == 200
    assert client.get('/api/me').status_code == 401


def test_new_accounts_get_no_fake_personalization_and_quiz_drives_recommendations(client):
    signup(client)
    assert client.get('/api/recommendations').json()['items'] == []
    client.put('/api/me/discovery',json={'answers':{'interest':['interest:law']},'completed':True})
    careers=client.get('/api/recommendations').json()['items']
    assert len(careers) == 5
    assert all(any(word in c['title'].lower() for word in ('lawyer','paralegal','legal','policy','government','compliance','labour')) for c in careers)
    assert all(c['reason_text'] == c['quiz_reason'] for c in careers)


def test_unsafe_source_urls_and_ids_are_rejected(client):
    admin=operator(client)
    for url in ('javascript:alert(1)','data:text/html,test','https://user:pass@example.test/x','https://example.test/\nunsafe'):
        assert client.post('/api/admin/content/career',json={'title':'Unsafe source','source_url':url}).status_code == 422
    assert client.put('/api/admin/content/career/bad%27id',json={'title':'Bad id'}).status_code == 422


def test_connections_close_when_a_route_raises(client, monkeypatch):
    import app
    captured=[]
    original=app.connect
    def track():
        con=original();captured.append(con);return con
    monkeypatch.setattr(app,'connect',track)
    @app.app.get('/api/disposable-test-failure')
    def fail():
        con=app.connect();con.execute('SELECT 1')
        raise HTTPException(409,'Simulated failure')
    app.app.router.routes.insert(0, app.app.router.routes.pop())
    assert client.get('/api/disposable-test-failure').status_code == 409
    assert captured and all(con.closed for con in captured)


def test_ai_is_opt_in_and_needs_verified_email(client, monkeypatch):
    signup(client)
    monkeypatch.setenv('OPENAI_API_KEY','test-key-that-is-never-sent')
    question={'question':'What does an accountant do?'}
    assert client.post('/api/advisor/ask',json=question).json()['mode'] == 'source_summary'
    assert client.post('/api/advisor/ask',json={**question,'allow_ai':True}).status_code == 403
    assert 'OpenAI' in client.get('/privacy').text


def test_health_fails_when_database_is_unavailable(client, monkeypatch):
    import app
    def broken():
        raise RuntimeError('Simulated unavailable database')
    monkeypatch.setattr(app,'connect',broken)
    response=client.get('/api/health')
    assert response.status_code == 503 and response.json()['database'] == 'error'
    assert 'Simulated' not in response.text


def test_postgres_translation_keeps_literal_question_marks():
    query="SELECT '?' AS literal, ? AS value, 'it''s ?' AS quoted, '50%' AS percent -- ? comment\nWHERE id=?"
    translated=postgres_sql(query)
    assert "'?' AS literal, %s AS value" in translated
    assert "'it''s ?'" in translated and "'50%%'" in translated
    assert '-- ? comment' in translated and translated.endswith('id=%s')
