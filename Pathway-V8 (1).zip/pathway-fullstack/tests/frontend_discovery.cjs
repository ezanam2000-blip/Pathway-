// Stable entry point retained for existing test commands. V31 supersedes the
// index-based V30 quiz fixtures with real-API journey and persistence checks.
require('./frontend_v31.cjs');
