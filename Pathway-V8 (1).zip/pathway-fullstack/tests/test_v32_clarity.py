from career_clarity import clarify_career
from discovery_profiles import day_profile


def test_finance_roles_explain_distinct_work():
    investment = clarify_career({'title': 'Investment Analyst', 'description': 'old'})
    financial = clarify_career({'title': 'Financial Analyst', 'description': 'old'})
    assert 'where to put money' in investment['description']
    assert 'build budgets' in financial['description']
    assert investment['description'] != financial['description']


def test_generic_environment_is_not_a_role_specific_challenge():
    profile = day_profile({'title': 'Other occupation', 'description': 'Explain records.',
                           'day_to_day': 'Check records and explain findings.',
                           'work_environment': 'Office.'})
    assert profile['role_specific'] is False
    profile = day_profile({'title': 'Investment Analyst', 'description': 'Study investments.'})
    assert profile['role_specific'] is True
    assert 'changing markets' in profile['reality']
    assert len(profile['activities']) == 3
