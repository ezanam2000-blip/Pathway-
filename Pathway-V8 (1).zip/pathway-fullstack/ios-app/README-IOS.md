# Pathway iOS — App Store only

This folder is intentionally iOS-only. There is no Android/Google Play project.

V35 is a source candidate, not a signed iOS release. Deploy API 6.6.0 / assets 35
before device testing. No generated `ios/` project is included. Server account
storage, email delivery, public support contact, keyboard/VoiceOver behaviour and
the remote shell's cold-offline behaviour remain release checks. Web catalog
fallback alone does not establish native offline support or App Review approval.

## Already wired in
- Capacitor iOS shell for the existing Pathway production app
- iPhone safe-area support
- native haptic feedback on important taps
- native iOS Share Sheet on career pages
- native status-bar handling
- existing Pathway login stays on the same HTTPS origin

## Build on a Mac
Requirements: macOS, Xcode 26+, Node.js 22+.

First deploy the current web update. The iOS shell opens the production URL in
`capacitor.config.ts`, so an older web deployment would still show the older UI.

```bash
cd pathway-fullstack/ios-app
npm install
npm run ios:add
npm run ios:sync
npm run ios:open
```

Run `npm run ios:add` only when the generated `ios` folder does not exist. For
later updates, use `npm run ios:sync` and `npm run ios:open`.

In Xcode:
1. Select the App target.
2. Signing & Capabilities -> choose the Apple Developer team that legally owns the app.
3. Keep Bundle Identifier `com.pathwaycareers.app` if Apple accepts it, otherwise choose a unique identifier and update `capacitor.config.ts` too.
4. Set Deployment Target to iOS 15.0 or later (Capacitor 8 requirement).
5. Set Version to 1.0 and Build to 1.
6. Add the final AppIcon assets.
7. Run on a real iPhone and test sign-up, login, Career Match, Save Career, My Path, and Share Career.
8. Product -> Archive -> Distribute App -> App Store Connect.

Before App Review, complete App Store Connect privacy details, age rating, screenshots, support URL, privacy-policy URL, and review notes. Do not submit until the production database and email verification are ready.

## Step 3: Apple Developer membership

Start at https://developer.apple.com/programs/enroll/ using the Apple Account
that will own Pathway. Turn on two-factor authentication and complete Apple's
identity checks. Membership costs US$99 per year, or the applicable local price
shown at enrollment. The account holder must meet Apple's legal-age requirement.
For an individual account, the seller name is the person's legal name.

Official enrollment help:
https://developer.apple.com/help/account/membership/program-enrollment/

## Step 4: Build and test the iPhone app

Extract this ZIP on a Mac and run the commands above in Terminal. In Xcode,
select the App target, choose the owner's developer team under Signing &
Capabilities, and confirm a unique Bundle Identifier. Use the same identifier in
App Store Connect. Add the final icon and set the version/build numbers.

Run the app on a real iPhone. Check comparison without sideways page scrolling,
education and funding links, the keyboard, quiz,
accounts, saves and share sheet. Then archive and upload through Xcode's
Organizer using Distribute App > App Store Connect. Allow Apple's build
processing to finish and test the uploaded build through TestFlight. External
testing can require Beta App Review.

TestFlight help:
https://developer.apple.com/help/app-store-connect/test-a-beta-version/testflight-overview/

## Step 5: Prepare the listing and submit

In https://appstoreconnect.apple.com/ open Apps and add Pathway with the matching
Bundle Identifier. Complete the app description, category, age rating, privacy
answers, screenshots, support URL and privacy-policy URL. Select the processed
build. Supply working review access for account features and any required review
notes. Add the version for review, then submit the completed submission.

Submission help:
https://developer.apple.com/help/app-store-connect/manage-submissions-to-app-review/submit-an-app/

The ZIP is source code. It is not a signed iPhone archive or an App Store
submission. Apple makes the review decision. The existing web-based shell still
needs device testing and a review of Apple's minimum-functionality requirements.
