"""Small, bounded discovery documents and transparent preference matching.

No grades, names, email addresses or salary projections belong in this document.
Career scores are exploration aids, not suitability probabilities.
"""
import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator

QUESTION_IDS = {
    "interest", "strengths", "subjects", "route", "path_detail", "work_detail",
    "environment", "balance", "value", "stage",
}


class SavedComparison(BaseModel):
    ids: list[str] = Field(min_length=2, max_length=3)

    @field_validator("ids")
    @classmethod
    def unique_ids(cls, values):
        if len(set(values)) != len(values) or any(len(v) > 160 for v in values):
            raise ValueError("Choose two or three different careers.")
        return values


class DiscoveryStateIn(BaseModel):
    schema_version: Literal[1] = 1
    answers: dict[str, list[str]] = Field(default_factory=dict)
    step: int = Field(default=0, ge=0, le=10)
    completed: bool = False
    compare_ids: list[str] = Field(default_factory=list, max_length=3)
    comparisons: list[SavedComparison] = Field(default_factory=list, max_length=8)
    result_ids: list[str] = Field(default_factory=list, max_length=6)

    @field_validator("answers")
    @classmethod
    def bounded_answers(cls, answers):
        if set(answers) - QUESTION_IDS:
            raise ValueError("Unknown question. Refresh Pathway and try again.")
        if any(len(v) > 4 or any(len(t) > 80 or ":" not in t for t in v) for v in answers.values()):
            raise ValueError("Too many answers or an invalid answer.")
        return {key: list(dict.fromkeys(values)) for key, values in answers.items()}

    @field_validator("compare_ids", "result_ids")
    @classmethod
    def bounded_ids(cls, values):
        if any(len(v) > 160 for v in values):
            raise ValueError("Invalid career identifier.")
        return list(dict.fromkeys(values))


# Match against recorded skills/subjects/tasks. Do not infer ability from a grade,
# age, nationality or a protected characteristic. Education stage affects next
# steps in the UI, not which careers a person is allowed to explore.
CONTEXT_RULES = {
    "strength:analysis": ("analysis", ["analys", "math", "data", "research", "problem solving"]),
    "strength:communication": ("communication", ["communication", "writing", "present", "client"]),
    "strength:creativity": ("creative problem solving", ["creativ", "design", "prototype"]),
    "strength:practical": ("hands-on work", ["hands-on", "repair", "equipment", "install"]),
    "strength:people": ("supporting people", ["care", "teach", "counsel", "service", "patient"]),
    "strength:organizing": ("organizing", ["organiz", "coordinat", "project management", "planning"]),
    "subject:math": ("mathematics", ["math", "calculus", "statistics"]),
    "subject:science": ("science subjects", ["biology", "chemistry", "physics", "science"]),
    "subject:computing": ("computing", ["computer", "programming", "coding"]),
    "subject:language": ("languages and writing", ["english", "writing", "language", "communication"]),
    "subject:arts": ("arts and design", ["art", "design", "music", "drama"]),
    "subject:business": ("business subjects", ["business", "economics", "accounting", "finance"]),
    "subject:social": ("social studies", ["history", "social", "psychology", "geography"]),
    "subject:technical": ("practical subjects", ["technology", "construction", "technical", "hands-on"]),
    "setting:outdoors": ("outdoor or field work", ["outdoor", "fieldwork", "field work", "site"]),
    "setting:workshop": ("workshops or labs", ["workshop", "laborator", "equipment", "repair"]),
    "setting:people": ("people-facing settings", ["patient", "client", "student", "customer"]),
    "setting:desk": ("desk-based work", ["office", "software", "computer", "spreadsheet", "data"]),
    "interest:education": ("education", ["teach", "education", "learning"]),
    "interest:environment": ("the environment", ["environment", "climate", "conservation", "ecolog", "wildlife"]),
    "interest:sport": ("sport", ["sport", "athlet", "performance video"]),
}


def context_matches(item, answers):
    text = " ".join(str(item.get(k) or "") for k in (
        "title", "industry", "skills", "school_subjects", "day_to_day", "work_environment",
    )).lower()
    role_text = " ".join(str(item.get(k) or "") for k in ("title", "description", "day_to_day")).lower()
    stems = {"analys", "math", "creativ", "organiz", "coordinat", "teach", "counsel", "patient", "ecolog", "environ", "athlet"}
    def matches(needle, candidate):
        # "site" must not match "website", nor "care" match "career".
        return bool(re.search(r'\b' + re.escape(needle) + (r'\w*' if needle in stems else '') + r'\b', candidate))
    return [(label, 8 if token.startswith("interest:") else 5)
            for token in dict.fromkeys(answers) if token in CONTEXT_RULES
            for label, needles in [CONTEXT_RULES[token]] if any(matches(n, role_text if token.startswith('interest:') else text) for n in needles)]


def fit_notes(item, answers):
    notes = []
    hours = str(item.get("hours") or "").lower()
    if "balance:priority" in answers and any(n in hours for n in ("shift", "long", "evening", "irregular", "weekend")):
        notes.append("Check the schedule: this profile mentions shifts or busy periods, but you prefer predictable hours.")
    preferred = next((a.split(":", 1)[1] for a in answers if a.startswith("route:") and a not in ("route:open", "route:work_sooner")), None)
    routes = {r.get("type") for r in item.get("route_options") or []}
    if preferred and routes and preferred not in routes:
        notes.append("Your preferred learning route is not listed here. Explore the alternatives before deciding.")
    if not notes:
        notes.append("Check local entry rules and talk to a worker: a match is a starting point, not a promise of fit.")
    return notes[:2]
