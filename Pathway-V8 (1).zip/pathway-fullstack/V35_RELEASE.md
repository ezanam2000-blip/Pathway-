# V35: Study Abroad removed

**November 4 update:** API 6.6.1, questionnaire stylesheet revision 36.
See MOBILE_LAYOUT_FIX.md for the mobile card fix, current validation limits
and deployment steps. The October validation below describes the original
V35 build; use the newer deployment version checks in MOBILE_LAYOUT_FIX.md.

Prepared October 23, 2026. API **6.6.0**, assets **35**.

Removed Study Abroad from the landing page, home actions, education tabs, tools,
scholarship page, career education details and expanded comparison. Removed the
international funding banner, country/subject selectors, study-abroad rendering
functions and the international guide data script. The privacy policy no longer
describes those removed inputs. The three remaining home actions use a balanced
layout on desktop and stack on phones.

Ontario programs, recorded scholarships, the course checker, career quiz, saved
items, comparison and roadmaps remain available. Existing saved account data
has not been deleted. An old `#/study-abroad` link and `/study-abroad` URL lead
to Education. Old navigation requests do not render the removed page.

## Validation

- **50 Python tests passed**, one optional PostgreSQL integration check skipped
  because no disposable PostgreSQL server was configured.
- The frontend journey passed with a disposable real API and lightweight DOM
  stub. It covers the remaining ten navigation views, 219 career detail
  renderers, quiz/resume, saves, account deletion, comparisons, browser history
  and error states. No remaining view or career action links to Study Abroad.
- The removed script returns 404, the old page URL redirects, and education and
  funding APIs continue returning their recorded options.
- This is not a physical iPhone or browser-layout test. V34's production
  persistence, SMTP, public support and native-signing checks remain outstanding.

## Publish this version

This package has not been confirmed deployed. The earlier GitHub integration
write returned 403, so the latest source still requires an authorized upload.

Rename a copy of `Pathway-V35-No-Study-Abroad.zip` to exactly
**`Pathway-V8 (1).zip`**, then replace that repository-root file on `main` in
https://github.com/ezanam2000-blip/Pathway- . Keep the ZIP's `pathway-fullstack/`
folder. Deploy the latest commit on the existing Render service.

Confirm `/api/health` reports **6.6.0** and the page loads assets with `v=35`.
Check Home, Education, Funding, Tools, career details and Compare on a phone.
The previous V34 source package is the recoverable version containing the
removed feature; no production database data was removed by this edit.
