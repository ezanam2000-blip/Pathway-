# V34: reliability and launch fixes

Prepared October 23, 2026. API **6.5.0**, assets **34**.
This is the updated source candidate. It has not been confirmed deployed.

## Changes students will notice

- Compact job cards, short explanations, mobile comparison topics, the adaptive
  quiz and the study-abroad submission flow from 33.2 are preserved.
- Browser Back/Forward restores views, quiz steps and career details. Returning
  from Compare preserves the latest search, field and result count. History
  cannot restore another signed-in user's private workspace.
- Existing account sessions survive signing in on another device. Ten active
  sessions are allowed; logout still ends the current session.
- Draft and unreviewed content stays private. There are now 219 public careers;
  the unsourced Entrepreneurship record is no longer publicly recommended.
- Saved account quiz answers drive the dashboard recommendations. Empty
  profiles do not get generic careers presented as personal matches. Law
  matching uses role signals rather than a loose substring connection.
- The Loran award explicitly says its recorded application deadline has passed,
  is not featured and sorts after open records. No new cycle is assumed.
- Account deletion asks for the current password, handles failures and blocks
  repeated submissions. Public career links open the chosen career and use the
  current site's origin.
- Catalog refreshes can use a previously saved public response when the network
  fails. A visible notice explains the saved data and offers a retry. First-ever
  offline loads and an offline native shell are not covered by this cache.
- Textarea caret/focus and open page sections are preserved during relevant
  redraws. Inputs use at least 16px, small text and touch targets are improved,
  dialogs use dynamic viewport height, and page titles follow the current view.

## Backend and security fixes

- `admin_managed` migrations preserve admin edits, review status and archives
  across restarts for careers, programs and scholarships. Existing change logs
  identify earlier edited records. This cannot recover edits already lost.
- Admin bootstrap never promotes an existing public account. The new
  `manage_admin.py` operator command allows deliberate recovery and rotation
  through trusted server access; it revokes old sessions and auth links.
- Request cleanup closes/returns database connections on success and failure.
  PostgreSQL uses a bounded pool. SQL placeholder conversion respects quoted
  question marks, searches are case insensitive, and `%`/`_` are literal input.
- Rate counters persist in the database. Login/reset limits include account
  identifiers; AI includes a user limit. Forwarded-header rotation cannot avoid
  those account limits. Docker no longer trusts all forwarded IP headers.
- Password hashing uses 600,000 PBKDF2-SHA256 iterations. Existing hashes still
  verify and upgrade on successful login. Unknown-account login also hashes.
  Concurrent signup conflicts return 409; auth tokens are claimed atomically.
- Analytics request rate, metadata and total request size are bounded. Extra
  metadata such as an email field is discarded. Old events are pruned after
  90 days, and expired sessions/tokens/request counters are cleaned up.
- AI answers require explicit consent and verified email. Plain record
  summaries work without sending a question to OpenAI. Vendor disclosure is in
  the UI and privacy policy. The external timeout is eight seconds.
- Source URLs must use HTTPS without embedded credentials. Dynamic data used in
  inline handlers is encoded as a JavaScript string and HTML attribute value.
- Production validates public HTTPS configuration and secure cookies. Optional
  additional exact origins support deliberate additional domains. Missing SMTP
  no longer silently reports a local development log as production delivery.
- GZip, ETags and cache controls reduce repeated catalog transfer and stale HTML.
  Unknown assets/routes return 404. Manifest, SVG icon, robots and public
  support routes exist. Database failure makes health return 503.
- Lookup indexes, FastAPI lifespan startup and shutdown, and runtime dependency
  constraints are included. The existing ZIP-based deployment is preserved.

## Validation

Commands run against disposable local data:

```bash
python -m pytest -q
node tests/frontend_discovery.cjs
```

Result: **49 Python tests passed; one PostgreSQL integration test skipped**.
The skipped test needs `PATHWAY_TEST_DATABASE_URL` for a disposable server. The
SQL lexer and SQLite behaviour were tested; real PostgreSQL behaviour was not.
There is one dependency deprecation warning about Starlette's httpx test adapter;
it did not fail a check.

The frontend journey passed with a real local API and a DOM stub: quiz/resume,
search, filters, browser history, comparison return, account isolation,
password-confirmed deletion, duplicate requests, closed awards, quoting-safe
handlers, cached-catalog fallback, 128 study-guide combinations, 219 career
detail renderers and 11 navigation views. All generated visible handlers parse.
This is behaviour coverage, not a visual browser or physical-device test.

## Audit items still requiring work or a production check

| Area | Status and required follow-up |
| --- | --- |
| Live deployment | GitHub write access returned 403. The prepared ZIP must replace the existing root archive before a Render deployment can publish these fixes. |
| iPhone and accessibility | Test the deployed build on iPhone/Safari, tablet and desktop; include comparison width, keyboard, Dynamic Type, VoiceOver, focus and swipe Back. No Lighthouse or real WebKit score is claimed. The browser rejected a local preview; that restriction was not bypassed. |
| PostgreSQL | Optional isolated-schema HTTP journey is included but unrun without a disposable server. Production schema migration, pooling and concurrent load still need a staging check. |
| Production persistence | Verify durable database settings and backup recovery before students rely on saves. Do not change a database URL without migrating data. |
| Email and contact | Configure/test real SMTP and a monitored public `PATHWAY_SUPPORT_EMAIL`. `/support` honestly reports when a contact has not been published. No private email was exposed. |
| Free hosting | This source change does not remove a free host's sleep/cold-start behaviour or upgrade the hosting plan. Confirm cost before choosing an always-on plan. Verify trusted proxy addresses on the actual host. |
| Native release | The Capacitor remote shell still needs an Xcode project, signing, icons, screenshots, privacy answers and a TestFlight/device check. Full cold-offline native use and Apple's minimum-functionality review are not solved by the web response cache. |
| Source data | Seven programs and two scholarship records remain limited coverage. Most pay/admission figures were not reverified in this release. Existing dates are retained. Stale records properly move to review until an editor checks official sources. Missing salaries/costs remain explicit. |
| Architecture | The existing two-layer renderer and inline handlers remain. Encoding and source validation are hardened, but removing CSP `unsafe-inline`, incremental rendering and a smaller summary/detail API need a separate tested refactor. |
| Operations | A source-based deployment and active CI would improve maintainability. The runtime is constrained, but native packages still need a platform build/lock. Audit-log records currently follow the existing administrator deletion cascade; retaining anonymous editorial history needs a separate migration. |

## Upload and deploy

1. Download `Pathway-V34-Reliability.zip`. For the existing repository upload,
   rename a copy to **`Pathway-V8 (1).zip`** and replace that exact root file on
   `main` at https://github.com/ezanam2000-blip/Pathway- . Keep the ZIP's
   `pathway-fullstack/` root folder. Do not put the archive inside another ZIP.
2. Confirm the commit contains the new archive, then deploy that commit on the
   existing Render service. Current build and start commands remain compatible:

```bash
python -m zipfile -e "Pathway-V8 (1).zip" . && pip install -r pathway-fullstack/requirements.txt
```

```bash
cd pathway-fullstack && uvicorn app:app --host 0.0.0.0 --port $PORT
```

3. On https://pathway-v8.onrender.com/ check `/api/health` reports **6.5.0**,
   HTML references `v=34`, the slogan is present, Loran is closed, two-device
   login works, quiz/saves resume, and Compare/Study abroad work on an iPhone.
   Check support contact, email delivery and persistence after restart.

A successful build is not proof that the current UI and production services
have passed these checks. Keep a recoverable database backup and the previous
archive before deploying migrations. Older code will not understand every new
security rule; rolling back source does not roll back the database migration.
