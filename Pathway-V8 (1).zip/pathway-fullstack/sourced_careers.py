"""Small, source-reviewed additions. US role descriptions are not global rules.

We intentionally omit new pay figures until jurisdiction/currency data have a
complete normalized schema. Never silently substitute an Ontario wage group.
"""
REVIEWED = '2026-10-21'
SOURCED_ROLES = [
    {
        'title': 'Industrial Ecologist', 'industry': 'Science & Environment', 'wage': 'science_policy',
        'purpose': 'Help industry use resources more carefully and reduce environmental impacts.',
        'tasks': ['Map materials used in production.', 'Compare ways to reduce waste.', 'Explain environmental trade-offs in a report.'],
        'education': 'Explore environmental science, engineering and analytical training. Specific employer and institution requirements must be checked locally.',
        'environment': 'Research, analysis and collaboration with industrial or environmental teams; settings depend on the employer.',
        'reality': 'A proposed improvement needs evidence; moving waste somewhere else may not solve the underlying problem.',
        'source': 'https://www.onetonline.org/link/summary/19-2041.03',
        'skills': ['Research', 'Data analysis', 'Communication', 'Systems thinking'],
        'subjects': ['Science', 'Mathematics', 'Geography'],
    },
    {
        'title': 'Wind Energy Operations Manager', 'industry': 'Business & Operations', 'wage': 'business_manager',
        'purpose': 'Coordinate people, maintenance and budgets at a wind-energy site.',
        'tasks': ['Review site performance records.', 'Coordinate maintenance and safety work.', 'Plan spending and communicate with the team.'],
        'education': 'Compare technical and management training. This is an operations-management role; local employer qualifications and experience requirements need separate checks.',
        'environment': 'Wind-facility operations and coordination with maintenance teams; duties may combine site visits and office work.',
        'reality': 'Keeping a site running involves records, budgets and safety coordination, not only working with turbines.',
        'source': 'https://www.onetonline.org/link/summary/11-9199.09',
        'skills': ['Organization', 'Leadership', 'Communication', 'Planning'],
        'subjects': ['Technology', 'Mathematics', 'Business'],
    },
    {
        'title': 'Medical Dosimetrist', 'industry': 'Healthcare', 'wage': 'ot',
        'purpose': 'Help an oncology team plan how radiation treatment is delivered.',
        'tasks': ['Review imaging and treatment information.', 'Develop a radiation plan with the clinical team.', 'Check and document the plan.'],
        'education': 'US example: typically a bachelor’s degree plus an accredited medical dosimetry program; employers usually require certification. Other countries may use different routes.',
        'environment': 'Healthcare teams, often with substantial computer-based treatment-planning work.',
        'reality': 'This is careful clinical planning, not simply operating a machine. Training and quality checks matter.',
        'source': 'https://www.bls.gov/ooh/healthcare/medical-dosimetrists.htm',
        'skills': ['Mathematics', 'Attention to detail', 'Teamwork', 'Technology'],
        'subjects': ['Physics', 'Mathematics', 'Biology'],
    },
]


def build_sourced_careers(role_factory):
    items = []
    for record in SOURCED_ROLES:
        item = role_factory(record['title'], record['industry'], record['wage'],
                            record['purpose'], ' '.join(record['tasks']),
                            source=record['source'], verified_date=REVIEWED,
                            education=record['education'], tags=['Unexpected Path'])
        item.update({
            'pay_range': 'Not yet verified for this role and location.',
            'pay_note': 'No local salary benchmark is recorded in Pathway for this profile. The occupational source is US-based; do not treat it as a global salary.',
            'salary_region': 'Not localized', 'salary_source': None, 'salary_verified_date': None,
            'outlook': 'Local employment outlook is not verified in Pathway. The linked US occupational profile is a research starting point, not a local forecast.',
            'outlook_region': 'Not localized', 'outlook_source': None, 'outlook_verified_date': None,
            'skills': record['skills'], 'school_subjects': record['subjects'],
            'work_environment': record['environment'], 'hours': 'Check the employer; a local schedule has not been verified.',
            'growth': 'Not locally verified', 'levels': ['Explore the work', 'Meet the local training requirements', 'Build relevant experience'],
            'route_options': [{'type': 'open', 'name': 'Research the local route',
                               'summary': record['education'],
                               'requirement': 'This occupational overview is not an institution’s admission rule.',
                               'source_url': record['source']}],
        })
        items.append(item)
    return items
