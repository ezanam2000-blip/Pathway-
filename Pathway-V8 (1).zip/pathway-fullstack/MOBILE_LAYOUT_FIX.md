# Questionnaire text fix — November 4, 2026

API 6.6.1. Questionnaire stylesheet revision 36.

The hidden mobile interest icon left its column in a three-column card grid.
Labels then occupied a narrow icon-sized space and wrapped inside words.

The fix assigns explicit columns to icons, labels and selection indicators.
Mobile interest cards use two columns: flexible text and a fixed checkbox.
At 480px and below all quiz choices use one full-width card per row, with
icons hidden. Text wraps at spaces; cards grow vertically for longer labels.
Selection, keyboard focus, back navigation and saved answers retain their
existing implementation. Study Abroad remains removed.

## Validation

The existing frontend journey passed against a disposable local API. It
checks answer selection, back/resume, saved items, comparison content, account
isolation/deletion and all 219 career renderers and ten navigation views.
The browser-based layout check could not run: the test browser download
failed. Phone-width rendering and physical iPhone testing remain required.
The production health endpoint returned HTTP 200 with database ok before
this package was deployed; that response still identifies the old 6.6.0 build.

## Deploy

This source package must be uploaded before the live website changes.
The connected GitHub integration previously rejected writes with HTTP 403.

1. Download the updated Pathway-V35-No-Study-Abroad.zip.
2. Rename the downloaded file to exactly Pathway-V8 (1).zip.
3. Open https://github.com/ezanam2000-blip/Pathway- and replace that file
   at the repository root on main. Do not extract the ZIP before uploading.
4. Deploy the latest commit on the existing Render web service if automatic
   deployment does not start.
5. Confirm https://pathway-v8.onrender.com/api/health reports 6.6.1.
6. Close and reopen Pathway on the iPhone simulator or phone.

The native shell loads this website, so this CSS change does not require
recreating the Xcode project or changing its server URL.

## Launch target

Aim to submit for App Review this week. Apple controls approval timing.
Before submission, test the updated app on a physical iPhone: finish the quiz,
open career details, compare careers, save and reopen items, log in and out,
and confirm account deletion works. Confirm support/privacy links, email
delivery and password recovery against production before accepting users.

Then select the developer signing team in Xcode, archive and upload the app
to App Store Connect. Complete screenshots, description, age rating, privacy
answers and review instructions. Native signing, upload and App Review have
not been performed from this environment.
