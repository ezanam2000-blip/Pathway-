/* V31 discovery layer. The existing catalog, route engine, account checklist,
 * course checker and application tracker stay in app.js. This layer owns the
 * public journey and reusable discovery UI. No framework or tracking SDK added.
 */
Object.assign(state, {comparisons:[], quizSummary:'', catalogError:'', accountError:'', storageError:false,
  syncStatus:'', discoveryReady:false,
  advisorUseAI:false, aiAvailable:document.querySelector('meta[name="pathway-ai-enabled"]')?.content==='1', catalogOffline:false});

const discoveryLegacy = {render, home, mypath, scholarshipCard,
  logout, deleteAccount, openRoadmap, shareCareerNative};
let discoverySyncTimer, discoverySyncRequest=null, discoveryRevision=0, discoveryPaused=false;
let discoveryToastTimer, discoveryModalOpener=null,quizRequest=0;

function discoveryKey(){return `pathway:discovery:1:${state.user?'user:'+state.user.id:'guest'}`}
function readDiscovery(key=discoveryKey()){
  try {const value=JSON.parse(localStorage.getItem(key)||'null');
    if(!value||value.schema_version!==1||!value.answers||typeof value.answers!=='object'||Array.isArray(value.answers))return null;
    for(const key of ['compare_ids','comparisons','result_ids','saved'])if(value[key]!==undefined&&!Array.isArray(value[key]))return null;
    return value;
  } catch {return null}
}
function discoveryDocument(){return {schema_version:1,answers:state.quizAnswersByStep,
  step:Math.min(state.quizStep,QUIZ_QUESTIONS.length),completed:state.quizStep>=QUIZ_QUESTIONS.length,
  compare_ids:state.compareIds,comparisons:state.comparisons.map(x=>({ids:x.ids})),
  result_ids:[...state.quizResults,...(state.quizDiscoveryPick?[state.quizDiscoveryPick]:[])].map(x=>x.id).slice(0,6)}}
function writeDiscovery(dirty=!!state.user){
  try {localStorage.setItem(discoveryKey(),JSON.stringify({...discoveryDocument(),
    saved:state.user?[]:state.saved.map(x=>({item_type:x.item_type,item_id:x.item_id})),dirty}));state.storageError=false}
  catch {state.storageError=true}
}
function persistDiscovery(){
  if(discoveryPaused)return;
  discoveryRevision++;writeDiscovery();
  if(state.user){state.syncStatus='Saved on this device · syncing account…';
    clearTimeout(discoverySyncTimer);discoverySyncTimer=setTimeout(syncDiscovery,450)}
}
async function syncDiscovery(){
  if(!state.user||discoveryPaused)return;
  // A failed first read must not turn a retry into an empty PUT that erases
  // unseen account history. New local edits are explicitly marked dirty.
  if(!state.discoveryReady&&!readDiscovery()?.dirty){await restoreDiscovery();updateDiscoveryStatus();return}
  if(discoverySyncRequest){await discoverySyncRequest;return}
  const userId=state.user.id, revision=discoveryRevision, document=discoveryDocument();
  discoverySyncRequest=api('/api/me/discovery',{method:'PUT',body:JSON.stringify(document)})
    .then(()=>{if(state.user?.id===userId){state.syncStatus='Saved to your account';if(revision===discoveryRevision)writeDiscovery(false)}})
    .catch(()=>{if(state.user?.id===userId)state.syncStatus='Saved on this device · account sync needs retry'})
    .finally(()=>{discoverySyncRequest=null;updateDiscoveryStatus()});
  await discoverySyncRequest;
  if(revision!==discoveryRevision&&state.user?.id===userId&&!discoveryPaused)await syncDiscovery();
}
function updateDiscoveryStatus(){const el=document.getElementById('discovery-save-status');if(el)el.textContent=discoverySaveText();const retry=document.getElementById('discovery-retry-sync');if(retry)retry.hidden=!state.syncStatus.includes('needs retry')}
function discoverySaveText(){return state.storageError?(state.user?`Device storage is unavailable. ${state.syncStatus||'Account progress can sync when online.'}`:'Device storage is unavailable. Keep this tab open to retain progress.'):state.user?(state.syncStatus||'Your account and this browser keep discovery progress.'):'Saved on this device only. No account needed.'}
function discoveryStorageNote(){return `<p class="discovery-storage" id="discovery-save-status" role="status">${esc(discoverySaveText())}</p>${state.user?`<button class="link-btn" id="discovery-retry-sync" ${state.syncStatus.includes('needs retry')?'':'hidden'} onclick="retryDiscoverySync()">Retry account sync</button>`:''}`}
async function retryDiscoverySync(){if(!state.discoveryReady&&!readDiscovery()?.dirty)await restoreDiscovery();else await syncDiscovery();render()}
function resetDiscoveryMemory(){quizRequest++;Object.assign(state,{quizLoading:false,quizError:'',quizStep:0,quizAnswers:[],quizAnswersByStep:{},quizResults:[],quizDiscoveryPick:null,
  quizSummary:'',compareIds:[],comparisons:[],showAllMatches:false,syncStatus:'',discoveryReady:false,saved:[],recommendations:[],planTasks:[],applications:[],activeRoadmap:null})}
function applyDiscovery(doc){
  if(!doc)return;
  state.quizAnswersByStep={};
  QUIZ_QUESTIONS.forEach(q=>{if(Array.isArray(doc.answers[q.id]))state.quizAnswersByStep[q.id]=doc.answers[q.id].filter(x=>typeof x==='string'&&x.length<81).slice(0,q.max||1)});
  rebuildQuizAnswers();reconcileQuizAnswers();
  state.quizStep=doc.completed?QUIZ_QUESTIONS.length:Math.min(Math.max(Number(doc.step)||0,0),QUIZ_QUESTIONS.length-1);
  const valid=id=>typeof id==='string'&&id.length<=160&&(state.catalogError||state.content.some(x=>x.type==='career'&&x.id===id));
  state.compareIds=[...new Set(doc.compare_ids||[])].filter(valid).slice(0,3);
  state.comparisons=(doc.comparisons||[]).filter(x=>x&&Array.isArray(x.ids)).map(x=>({ids:[...new Set(x.ids)].filter(valid).slice(0,3)})).filter(x=>x.ids.length>=2).slice(0,8);
  state.quizResults=(doc.result_ids||[]).slice(0,5).map(id=>state.content.find(x=>x.type==='career'&&x.id===id)).filter(Boolean);
  if(!state.user)state.saved=(doc.saved||[]).filter(s=>s&&typeof s.item_id==='string'&&['career','program','scholarship'].includes(s.item_type)&&(state.catalogError||state.content.some(x=>x.type===s.item_type&&x.id===s.item_id)));
}
async function restoreDiscovery(){
  const local=readDiscovery(),revision=discoveryRevision,userId=state.user?.id;let doc=local;
  if(state.user){try{const remote=await api('/api/me/discovery');if(!local?.dirty)doc=remote.document||local;
      state.discoveryReady=true;state.syncStatus=local?.dirty?'Saved on this device · syncing account…':'Saved to your account'}
    catch{state.discoveryReady=!!local;state.syncStatus=local?'Saved on this device · account sync needs retry':'Account history could not load · needs retry'}}
  if(revision!==discoveryRevision||state.user?.id!==userId)return;
  applyDiscovery(doc);
  if(doc?.completed&&state.quizAnswers.length){try{const result=await api('/api/career-quiz',{method:'POST',body:JSON.stringify({answers:state.quizAnswers})});
    if(revision!==discoveryRevision||state.user?.id!==userId)return;
    state.quizResults=result.items;state.quizDiscoveryPick=result.discovery_pick;state.quizSummary=result.summary||''}
    catch{state.quizSummary='Your previous career list is saved. Retry the quiz to refresh the personal explanations.'}}
  if(state.user&&local?.dirty)syncDiscovery();
}
async function forgetDiscovery(){
  if(!confirm('Clear quiz answers, results and saved comparisons? Saved careers and programs will stay.'))return;
  discoveryPaused=true;clearTimeout(discoverySyncTimer);
  if(discoverySyncRequest)await discoverySyncRequest;
  if(state.user){try{await api('/api/me/discovery',{method:'DELETE'})}catch(e){discoveryPaused=false;toast('Could not clear account history. Try again.');return}}
  Object.assign(state,{quizStep:0,quizAnswers:[],quizAnswersByStep:{},quizResults:[],quizDiscoveryPick:null,quizSummary:'',compareIds:[],comparisons:[],showAllMatches:false,syncStatus:''});
  writeDiscovery(false);discoveryPaused=false;render();toast('Discovery history cleared. Your saved items are unchanged.');
}
function importGuestDiscovery(){
  const guest=readDiscovery('pathway:discovery:1:guest');if(!guest)return;
  if(!confirm('Replace this account’s quiz and comparisons with the exploration saved on this device? Bookmarks are not imported.'))return;
  applyDiscovery(guest);persistDiscovery();render();toast('Device exploration copied to your account.');
}

// Public catalog loading is independent of authentication; a guest is not an
// empty account. Partial account failures must not hide a working catalog.
api=async function(path,options={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);
  try{const res=await fetch(path,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...options,signal:controller.signal});
    const raw=await res.text();let data;try{data=raw?JSON.parse(raw):{}}catch{data={}}
    if(!res.ok){const detail=typeof data.detail==='string'?data.detail:res.status===422?'Check your answers and try again.':'That request could not be completed. Please retry.';
      const error=new Error(detail);error.status=res.status;throw error}return data;
  }catch(e){if(e.name==='AbortError')throw new Error('This is taking longer than expected. Please retry.');
    if(e instanceof TypeError)throw new Error('Unable to connect. Check your connection and retry.');throw e}
  finally{clearTimeout(timer)}
};
async function loadCatalog(){
  try{const data=await api('/api/content');state.catalogOffline=false;
    if(window.caches&&typeof Response!=='undefined')try{const cache=await window.caches.open('pathway-public-catalog');await cache.put('/api/content',new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json','X-Pathway-Saved':new Date().toISOString()}}))}catch{}
    return data;
  }catch(error){if(window.caches)try{const cached=await (await window.caches.open('pathway-public-catalog')).match('/api/content');if(cached){const data=await cached.json();if(Array.isArray(data.items)&&data.items.length){state.catalogOffline=true;return data}}}catch{}throw error}
}
bootstrap=async function(){
  const params=new URLSearchParams(location.search),verify=params.get('verify'),reset=params.get('reset');
  const [catalog,me]=await Promise.allSettled([loadCatalog(),api('/api/me')]);
  if(catalog.status==='fulfilled')state.content=catalog.value.items;else state.catalogError=catalog.reason.message;
  if(me.status==='fulfilled'){state.user=me.value.user;syncOnboardingFromUser();await refreshAll();state.screen='app'}
  else {state.user=null;state.screen='landing';if(me.reason.status!==401)state.authMessage='Account connection unavailable. You can still explore as a guest.'}
  await restoreDiscovery();
  if(verify){try{await api('/api/auth/verify-email',{method:'POST',body:JSON.stringify({token:verify})});state.authMessage='Email verified. You can now log in.'}catch(e){state.authError=e.message}state.screen='login'}
  if(reset){state.resetToken=reset;state.screen='reset'}
  if(verify||reset)history.replaceState({},'',location.pathname);
  const careerId=params.get('career');if(careerId){state.screen='app';state.view='explore';state.detail=state.content.find(x=>x.type==='career'&&x.id===careerId)||null;if(!state.detail)state.catalogError='That career link is unavailable. You can browse the current catalog below.'}
  if(!careerId&&!verify&&!reset)restoreInitialRoute();
  render();
};
async function retryCatalog(){state.catalogError='';state.loading=true;render();try{state.content=(await loadCatalog()).items;applyDiscovery(readDiscovery())}catch(e){state.catalogError=e.message}finally{state.loading=false;render()}}
refreshAll=async function(){
  state.accountError='';
  const requests=[...(!state.content.length?[['content','/api/content']]:[]),['saved','/api/saved'],['recommendations','/api/recommendations'],['applications','/api/applications'],['planTasks','/api/plan/tasks']];
  const results=await Promise.allSettled(requests.map(([,path])=>api(path)));
  results.forEach((r,i)=>{if(r.status==='fulfilled')state[requests[i][0]]=r.value.items;
    else if(requests[i][0]==='content')state.catalogError=r.reason.message;else state.accountError='Some account information could not load. Your public catalog is still available.'});
  try{state.activeRoadmap=(await api('/api/roadmaps/mine')).roadmap}catch{state.activeRoadmap=null}
  if(state.user?.is_admin){try{state.adminStats=await api('/api/admin/stats')}catch{}}
};
async function retryAccount(){state.loading=true;render();await refreshAll();await restoreDiscovery();state.loading=false;render()}
submitAuth=async function(event,mode){
  event.preventDefault();const form=new FormData(event.target);const payload={email:form.get('email'),password:form.get('password')};if(mode==='signup')payload.name=form.get('name');
  state.loading=true;state.authError='';render();
  try{const data=await api(`/api/auth/${mode}`,{method:'POST',body:JSON.stringify(payload)});
    resetDiscoveryMemory();state.user=data.user;syncOnboardingFromUser();await refreshAll();await restoreDiscovery();
    state.screen='app';state.view='mypath';
    if(state.pendingRoadmap){const d=state.pendingRoadmap;state.pendingRoadmap=null;openRoadmap(d.careerId,d.grade,d.routeKey)}}
  catch(e){state.authError=e.message}finally{state.loading=false;render()}
};
logout=async function(){
  clearTimeout(discoverySyncTimer);if(state.user)await syncDiscovery();
  try{await api('/api/auth/logout',{method:'POST',body:'{}'})}catch{toast('Could not log out. Check your connection and retry.');return}
  resetDiscoveryMemory();state.user=null;state.screen='landing';state.profileOpen=false;await restoreDiscovery();render();
};
deleteAccount=function(){state.detail={_deleteAccount:true};state.deleteError='';state.profileOpen=false;render()};
function accountDeleteDialog(){return `<div class="modal-backdrop" onclick="if(event.target===this)closeDetail()"><div class="modal"><div class="modal-head"><h2>Delete your account?</h2><button class="close" onclick="closeDetail()" aria-label="Cancel account deletion">×</button></div><p>Your account, saves and account history will be permanently removed.</p><form onsubmit="confirmAccountDeletion(event)"><label class="delete-password-label" for="delete-password">Confirm your current password<input id="delete-password" type="password" autocomplete="current-password" required maxlength="128"></label>${state.deleteError?`<p class="error" role="alert">${esc(state.deleteError)}</p>`:''}<div class="discovery-detail-actions"><button class="btn secondary" type="button" onclick="closeDetail()">Keep my account</button><button class="btn danger" type="submit" ${state.deleting?'disabled':''}>${state.deleting?'Deleting…':'Delete account permanently'}</button></div></form></div></div>`}
async function confirmAccountDeletion(event){event.preventDefault();if(state.deleting)return;const password=event.target.querySelector('#delete-password')?.value;if(!password)return;state.deleting=true;
  discoveryPaused=true;clearTimeout(discoverySyncTimer);if(discoverySyncRequest)await discoverySyncRequest;
  try{await api('/api/me',{method:'DELETE',body:JSON.stringify({password})});try{localStorage.removeItem(discoveryKey())}catch{}
    resetDiscoveryMemory();state.user=null;state.detail=null;state.screen='landing';state.profileOpen=false;await restoreDiscovery()}
  catch(e){state.deleteError=e.message}finally{discoveryPaused=false;state.deleting=false;render()}
}

landing=function(){const started=Object.keys(state.quizAnswersByStep).length>0;return `<main class="wrap landing-wrap stage1-landing" id="main-content">
  <section class="v27-landing captivating-landing"><div class="hero-copy"><div class="logo"><span class="logo-mark"></span>Pathway</div>
  <span class="eyebrow">Career discovery</span><h1>Your future has <span class="gradient-text">more options.</span></h1>
  <p>See what different jobs involve and how to get started.</p>
  <div class="stage1-hero-actions"><button class="btn primary shine-btn" onclick="startCareerQuiz()">${started?'Continue my discovery':'Discover My Path'} →</button></div>
  <div class="v27-small-note">10 short questions. Skip any. No sign-up needed.</div>
  <div class="discovery-secondary"><button class="link-btn" onclick="setView('explore')">Browse careers</button><button class="link-btn" onclick="showAuth('login')">Log in</button></div>
  ${discoveryStorageNote()}</div><aside class="v27-landing-side"><div class="v27-glow-orb" aria-hidden="true">✦</div><span class="eyebrow">Take your time</span><h2>Look beyond the job title.</h2><p>Learn what people actually do and compare the jobs that interest you.</p><div class="v27-mini-tags"><span>Discover</span><span>Compare</span><span>Explore</span></div></aside></section>
  ${state.catalogError?catalogErrorBlock():''}<div class="trust-strip">Pay figures currently cover Ontario, Canada. Check education requirements with the official provider.</div><div class="legal-links"><a href="/privacy">Privacy</a><a href="/terms">Terms</a></div></main>`};
topbar=function(){const items=[['home','Home'],['explore','Careers'],['universities','Education'],['scholarships','Funding'],['mypath','Saved & plan'],['tools','Tools']];return `<a class="skip-link" href="#main-content">Skip to content</a><header class="topbar"><button class="brand-button" aria-label="Pathway home" onclick="setView('home')"><span class="logo"><span class="logo-mark"></span>Pathway</span></button><nav class="nav" aria-label="Main navigation">${items.map(([v,l])=>`<button ${state.view===v?'aria-current="page"':''} class="${state.view===v?'active':''}" onclick="setView('${v}')">${l}</button>`).join('')}</nav>${state.user?`<button class="profile-btn" aria-label="Account menu" aria-expanded="${state.profileOpen}" onclick="state.profileOpen=!state.profileOpen;render()">${esc(state.user.name[0].toUpperCase())}</button>`:'<button class="btn secondary nav-login" onclick="showAuth(\'login\')">Log in</button>'}${state.profileOpen&&state.user?profileMenu():''}</header>`};
bottomNav=function(){return `<nav class="bottom-nav" aria-label="Quick navigation">${[['home','⌂','Home'],['explore','✦','Careers'],['universities','🎓','Education'],['mypath','✓','Saved'],['tools','◎','Tools']].map(([v,icon,label])=>`<button ${state.view===v?'aria-current="page"':''} class="${state.view===v?'active':''}" onclick="setView('${v}')"><span aria-hidden="true">${icon}</span>${label}</button>`).join('')}</nav>`};
setView=function(v){clearTimeout(careerSearchTimer);state.screen='app';state.view=v==='studyabroad'?'universities':v;state.profileOpen=false;state.detail=null;state.query='';state.category='all';window.scrollTo(0,0);render();focusPageHeading()};
openPostsecondary=function(tab='universities'){state.postsecondaryTab=tab;setView('universities')};
function focusPageHeading(){const h=document.querySelector('#main-content h1');if(h){h.tabIndex=-1;h.focus({preventScroll:true})}}
function catalogErrorBlock(){return `<div class="error" role="alert"><p>${esc(state.catalogError)}</p><button class="btn secondary" onclick="retryCatalog()" ${state.loading?'disabled':''}>${state.loading?'Loading…':'Retry loading'}</button></div>`}
home=function(){return discoveryLegacy.home().replace('Find my career →',Object.keys(state.quizAnswersByStep).length?'Continue my discovery →':'Discover My Path →').replace('One quiz. Ten quick questions.','10 short questions. Skip any. Change your mind anytime.')};

// Answers use question IDs, not screen indexes. Changing a route removes only
// incompatible adaptive choices; unrelated answers are retained.
rebuildQuizAnswers=function(){state.quizAnswers=QUIZ_QUESTIONS.flatMap(q=>state.quizAnswersByStep[q.id]||[])};
quizValues=function(q=currentQuizQuestion()){return state.quizAnswersByStep[q?.id]||[]};
function reconcileQuizAnswers(){
  rebuildQuizAnswers();QUIZ_QUESTIONS.forEach((base,i)=>{const q=currentQuizQuestion(i),allowed=new Set(q.options.map(x=>x[1]));
    if(state.quizAnswersByStep[base.id])state.quizAnswersByStep[base.id]=state.quizAnswersByStep[base.id].filter(x=>allowed.has(x));rebuildQuizAnswers()});
}
startCareerQuiz=function(fresh=false){
  if(fresh){quizRequest++;state.quizLoading=false;state.quizError='';state.quizStep=0;state.quizAnswers=[];state.quizAnswersByStep={};state.quizResults=[];state.quizDiscoveryPick=null;state.quizSummary='';persistDiscovery()}
  state.screen='app';state.view='careerquiz';state.detail=null;state.profileOpen=false;state.showAllMatches=false;window.scrollTo(0,0);render();focusPageHeading();
};
editQuizAnswers=function(){state.quizStep=0;state.quizResults=[];state.quizDiscoveryPick=null;state.screen='app';state.view='careerquiz';persistDiscovery();render();focusPageHeading()};
toggleQuiz=function(value){
  if(state.quizLoading)return;const q=currentQuizQuestion();if(!q||!q.options.some(x=>x[1]===value))return;
  let selected=[...quizValues(q)];
  if(q.multi){const i=selected.indexOf(value);if(i>=0)selected.splice(i,1);else{
    if(value.endsWith(':open'))selected=[];else selected=selected.filter(x=>!x.endsWith(':open'));
    if(selected.length>=q.max){toast(`Choose up to ${q.max}.`);return}selected.push(value)}}else selected=[value];
  state.quizAnswersByStep[q.id]=selected;reconcileQuizAnswers();persistDiscovery();
  // Keep the current controls and focus in place when an answer is selected.
  // Replacing the entire app here interrupted taps, typing and animations.
  const controls=document.querySelectorAll('[data-quiz-value]');
  if(!controls.length){render();return}
  controls.forEach(el=>{const checked=selected.includes(el.getAttribute('data-quiz-value'));
    el.classList.toggle('selected',checked);el.setAttribute('aria-pressed',String(checked));
    const mark=el.querySelector('.checkmark');if(mark)mark.textContent=checked?'✓':'+'});
  const status=document.querySelector('.v27-selected-status');if(status)status.textContent=selected.length?`${selected.length} selected. Change any time.`:'Not sure? Skip this one.';
  const next=document.querySelector('.discovery-quiz-actions .btn.primary');if(next)next.disabled=!selected.length;
  updateDiscoveryStatus();
};
quizCanContinue=function(){return quizValues().length>0};
function moveQuiz(step){state.quizStep=Math.max(0,Math.min(step,QUIZ_QUESTIONS.length-1));persistDiscovery();window.scrollTo(0,0);render();focusPageHeading()}
function skipQuiz(){if(state.quizLoading)return;state.quizAnswersByStep[currentQuizQuestion().id]=[];reconcileQuizAnswers();advanceQuiz()}
function advanceQuiz(){if(state.quizStep===QUIZ_QUESTIONS.length-1)finishCareerQuiz();else moveQuiz(state.quizStep+1)}
nextQuiz=function(){if(state.quizLoading)return;if(!quizCanContinue()){toast('Choose an answer or use Skip for now.');return}advanceQuiz()};
finishCareerQuiz=async function(){
  if(state.quizLoading)return;const request=++quizRequest;state.quizLoading=true;state.quizError='';persistDiscovery();render();
  try{const result=await api('/api/career-quiz',{method:'POST',body:JSON.stringify({answers:state.quizAnswers})});
    if(request!==quizRequest)return;
    state.quizResults=result.items;state.quizDiscoveryPick=result.discovery_pick||null;state.quizSummary=result.summary||'';
    state.quizStep=QUIZ_QUESTIONS.length;state.showAllMatches=false;persistDiscovery()}
  catch(e){if(request===quizRequest)state.quizError=e.message}finally{if(request===quizRequest){state.quizLoading=false;window.scrollTo(0,0);render();focusPageHeading()}}
};
function discoveryPayLabel(x){return x.salary_last_verified_date?`Annual pay · ${x.salary_region||'Check location'} · CAD`:'Pay · research needed'}
function compactCareerPay(x){
  const text=String(x.pay_range||''),median=text.match(/median\s+(\$[\d,]+)/i);
  if(!x.salary_last_verified_date)return 'Pay not listed';
  return median?`${median[1]} / year`:(text.match(/\$[\d,]+\s*[–-]\s*\$?[\d,]+/)||[])[0]||'See pay details';
}
function compactCareerCard(x,match=false){return `<article class="${match?'v27-match-card':'card'} clickable career-card compact-career-card" onclick="openDetail('career',${jsArg(x.id)})">
  <div class="card-top"><span class="tag">${esc(x.industry||'Career')}</span><button class="save-btn ${isSaved(x)?'saved':''}" aria-label="${isSaved(x)?'Unsave':'Save'} ${esc(x.title)}" aria-pressed="${isSaved(x)}" onclick="event.stopPropagation();toggleSave('career',${jsArg(x.id)})">${isSaved(x)?'♥':'♡'}</button></div>
  <h3>${esc(x.title)}</h3><div class="compact-pay"><strong>${esc(compactCareerPay(x))}</strong><span>${x.salary_last_verified_date?`${esc(x.salary_region||'Ontario')} · CAD · ${/median\s+\$/i.test(x.pay_range||'')?'occupation median':'occupation range'}`:'Open for available information'}</span></div>
  <div class="compact-card-actions"><button class="link-btn discovery-open-item" onclick="event.stopPropagation();openDetail('career',${jsArg(x.id)})">View career →</button><button class="btn secondary" onclick="event.stopPropagation();toggleCompare(${jsArg(x.id)})">${state.compareIds.includes(x.id)?'✓ Comparing':'+ Compare'}</button></div></article>`}
careerCard=function(x){return compactCareerCard(x)};
quizResultCard=function(x){return compactCareerCard(x,true)};
careerQuiz=function(){
  if(state.quizStep>=QUIZ_QUESTIONS.length){const gem=state.quizDiscoveryPick;return `<section class="v27-results-head"><span class="eyebrow">YOUR RESULTS</span><h1>${state.quizResults.length?'Careers to take a closer look at.':'Keep looking around.'}</h1><p>${esc(state.quizSummary||'Open a career to see what the work is like.')}</p>${quizChoiceSummary()}<div class="v27-inline-buttons"><button class="btn secondary" onclick="editQuizAnswers()">Edit answers</button><button class="link-btn" onclick="startCareerQuiz(true)">Start again</button></div>${discoveryStorageNote()}</section>
    ${state.quizResults.length?`<div class="v27-results-toolbar"><span>Start with these ${Math.min(3,state.quizResults.length)}.</span><button class="btn secondary" onclick="openCompare()">Compare (${state.compareIds.length}/3) →</button></div><div class="v27-result-list">${state.quizResults.slice(0,state.showAllMatches?5:3).map(quizResultCard).join('')}</div>${!state.showAllMatches&&state.quizResults.length>3?'<div class="v27-more-results"><button class="btn secondary" onclick="state.showAllMatches=true;render()">Show more careers ↓</button></div>':''}`:'<div class="empty"><p>You can browse careers without answering the quiz.</p><button class="btn primary" onclick="setView(\'explore\')">Browse all careers</button></div>'}
    ${gem?`<section class="v27-discovery"><span class="eyebrow">SOMETHING DIFFERENT</span><h2>${esc(gem.title)}</h2><button class="btn secondary" onclick="openDetail('career',${jsArg(gem.id)})">View career →</button></section>`:''}<p class="muted">Looking for something else? <button class="link-btn" onclick="setView('explore')">Browse the full catalog</button> or <button class="link-btn" onclick="setView('mypath')">open saved & plan</button>.</p>`}
  const q=currentQuizQuestion(),selected=quizValues(q),progress=Math.round(state.quizStep/QUIZ_QUESTIONS.length*100);
  return `<section class="quiz-shell stage1-quiz v27-quiz"><div class="v27-quiz-kicker"><span>Discover your path</span><b>Question ${state.quizStep+1} of ${QUIZ_QUESTIONS.length}</b></div><div class="quiz-progress" role="progressbar" aria-label="Questions completed" aria-valuenow="${state.quizStep}" aria-valuemin="0" aria-valuemax="${QUIZ_QUESTIONS.length}"><i style="width:${progress}%"></i></div><h1 id="quiz-question">${esc(q.title)}</h1><p>${esc(q.subtitle)}</p><div class="select-grid quiz-options personalized-options v27-choice-options" role="group" aria-labelledby="quiz-question">${q.options.map(([label,value])=>`<button type="button" class="select-card ${selected.includes(value)?'selected':''}" aria-pressed="${selected.includes(value)}" data-quiz-value="${esc(value)}" ${state.quizLoading?'disabled':''} onclick="chooseQuiz(${jsArg(value)})"><span class="option-icon" aria-hidden="true">${quizOptionIcon(value)}</span><span class="option-label">${esc(label)}</span><span class="checkmark" aria-hidden="true">${selected.includes(value)?'✓':'+'}</span></button>`).join('')}</div><p class="v27-selected-status" role="status">${selected.length?`${selected.length} selected. Change any time.`:'Not sure? Skip this one.'}</p>${state.quizError?`<div class="error" role="alert">${esc(state.quizError)} Your answers are safe. Try again.</div>`:''}<div class="onboard-actions discovery-quiz-actions"><button class="btn secondary" ${state.quizLoading?'disabled':''} onclick="${state.quizStep?'moveQuiz(state.quizStep-1)':"setView('home')"}">Back</button><button class="link-btn" onclick="skipQuiz()" ${state.quizLoading?'disabled':''}>Skip for now</button><button class="btn primary" onclick="nextQuiz()" ${state.quizLoading||!quizCanContinue()?'disabled':''}>${state.quizLoading?'Finding paths…':state.quizStep===QUIZ_QUESTIONS.length-1?'See my paths →':'Next →'}</button></div>${discoveryStorageNote()}<button class="link-btn discovery-pause" onclick="setView('home')">Pause & return later</button></section>`;
};

const pendingSaves=new Set();
toggleSave=async function(type,id){
  const key=type+':'+id,pendingKey=(state.user?.id||'guest')+':'+key;if(pendingSaves.has(pendingKey))return;
  const item=state.content.find(x=>x.type===type&&x.id===id)||state.quizResults.find(x=>x.type===type&&x.id===id);if(!item)return;
  const wasSaved=isSaved(item);
  if(!state.user){if(wasSaved)state.saved=state.saved.filter(s=>savedKey(s)!==itemKey(item));else state.saved.push({item_type:type,item_id:id});persistDiscovery();render();toast(wasSaved?'Removed from saved items.':'Saved on this device.');return}
  const owner=state.user.id;pendingSaves.add(pendingKey);
  try{await api(wasSaved?`/api/saved/${type}/${id}`:'/api/saved',{method:wasSaved?'DELETE':'POST',body:wasSaved?undefined:JSON.stringify({item_type:type,item_id:id})});
    if(state.user?.id!==owner)return;
    if(wasSaved)state.saved=state.saved.filter(s=>savedKey(s)!==key);else if(!isSaved(item))state.saved.push({item_type:type,item_id:id});
    render();toast(wasSaved?'Removed from saved items.':'Saved to your account.')}
  catch(e){if(state.user?.id===owner)toast(e.message)}finally{pendingSaves.delete(pendingKey)}
};
function discoveryDashboard(){const saved=savedItems();return `<section class="discovery-dashboard"><div class="page-title"><span class="eyebrow">SAVED & PLAN</span><h1>Your saved ideas</h1><p>Come back to your careers, comparisons and next steps.</p></div>${discoveryStorageNote()}<div class="discovery-dashboard-actions"><button class="btn primary" onclick="startCareerQuiz()">${state.quizStep>=QUIZ_QUESTIONS.length?'See my results':Object.keys(state.quizAnswersByStep).length?'Continue my quiz':'Discover My Path'} →</button><button class="btn secondary" onclick="openCompare()">Current comparison (${state.compareIds.length}/3)</button></div>
  <section class="section"><h2>Saved comparisons</h2>${state.comparisons.length?`<div class="grid two">${state.comparisons.map((c,i)=>`<article class="card"><h3>${c.ids.map(id=>esc(state.content.find(x=>x.id===id)?.title||'Career unavailable')).join(' &amp; ')}</h3><button class="btn secondary" onclick="restoreComparison(${i})">Open comparison</button><button class="link-btn" onclick="removeComparison(${i})">Remove</button></article>`).join('')}</div>`:emptySmall('Add two careers to compare, then save that comparison.')}</section>
  <section class="section"><h2>Saved careers & education</h2>${saved.length?`<div class="grid">${saved.map(x=>card(x)).join('')}</div>`:emptySmall('Save a career, program or scholarship to keep it here.')}</section>
  ${!state.user?`<div class="notice"><b>Ready for a next step?</b><p>Open a saved career to see training routes and a starter plan.</p><button class="link-btn" onclick="showAuth('signup')">Create an account to save checklists →</button></div>`:''}
  ${state.user&&readDiscovery('pathway:discovery:1:guest')?'<button class="link-btn" onclick="importGuestDiscovery()">Copy this device’s guest exploration to my account</button>':''}
  <details class="discovery-privacy"><summary>Storage & privacy controls</summary><p>Guest answers, bookmarks and comparisons stay in this browser. They are not private from other people using this browser and can be lost if browser data is cleared. Account discovery progress also syncs to Pathway’s server. No grades, email or passwords are stored in this discovery document.</p><p>Existing account profile and application data are separate. Grade inputs in the Ontario checker are not saved. Clearing discovery history does not delete bookmarked items.</p><button class="btn secondary" onclick="forgetDiscovery()">Clear discovery history</button><a href="/privacy">Read privacy policy</a></details></section>`}
mypath=function(){return discoveryDashboard()+(state.user?`<details class="discovery-account-tools"><summary>Account roadmap, checklist & applications</summary>${discoveryLegacy.mypath()}</details>`:'')};

toggleCompare=function(id){
  if(![...state.content,...state.quizResults,...(state.quizDiscoveryPick?[state.quizDiscoveryPick]:[])].some(x=>x.type==='career'&&x.id===id))return;
  if(state.compareIds.includes(id))state.compareIds=state.compareIds.filter(x=>x!==id);
  else if(state.compareIds.length>=3){toast('Compare up to three careers. Remove one first.');return}else state.compareIds.push(id);
  persistDiscovery();render();toast(state.compareIds.includes(id)?'Added to comparison.':'Removed from comparison.');
};
openCompare=function(){clearTimeout(careerSearchTimer);rememberNavigation();if(state.view!=='compare'){state.compareReturn=state.view;state.compareContext={view:state.view,query:state.query,category:state.category,careerLimit:state.careerLimit,scroll:window.scrollY||0}}state.screen='app';state.detail=null;state.view='compare';window.scrollTo(0,0);render();focusPageHeading()};
function returnFromCompare(){const context=state.compareContext;state.screen='app';state.view=context?.view||state.compareReturn||'explore';state.detail=null;if(context){state.query=context.query;state.category=context.category;state.careerLimit=context.careerLimit}render();focusPageHeading();window.scrollTo(0,context?.scroll||0)}
function clearComparison(){state.compareIds=[];persistDiscovery();render()}
function saveComparison(){if(state.compareIds.length<2){toast('Choose at least two careers first.');return}
  const key=[...state.compareIds].sort().join('|');if(state.comparisons.some(c=>[...c.ids].sort().join('|')===key)){toast('This comparison is already saved.');return}
  if(state.comparisons.length>=8){toast('You have eight saved comparisons. Remove one to save another.');return}
  state.comparisons.push({ids:[...state.compareIds]});persistDiscovery();render();toast('Comparison saved. Find it in Saved & plan.');
}
function restoreComparison(index){if(!state.comparisons[index])return;state.compareIds=[...state.comparisons[index].ids];persistDiscovery();openCompare()}
function removeComparison(index){state.comparisons.splice(index,1);persistDiscovery();render();toast('Saved comparison removed.')}
function careerDuration(x){return (String(x.education||'').match(/(?:about\s+)?\d+(?:\s*[–-]\s*\d+)?\s*(?:years?|months?)/i)||[])[0]||'Not recorded. Check the chosen program or apprenticeship.'}
function personalCareer(x){return state.quizResults.find(c=>c.id===x.id)||(state.quizDiscoveryPick?.id===x.id?state.quizDiscoveryPick:x)}
function mobileComparison(careers,rows){return `<div class="mobile-comparison">
  <div class="mobile-compare-picks" aria-label="Chosen careers">${careers.map(x=>`<div><b>${esc(x.title)}</b><button class="link-btn" onclick="toggleCompare(${jsArg(x.id)})" aria-label="Remove ${esc(x.title)} from comparison">Remove ×</button></div>`).join('')}</div>
  <p class="comparison-note">Compare one topic at a time. Each pay figure shows its location and currency.</p>
  ${rows.map(([label,value],i)=>`<section class="mobile-compare-topic" aria-labelledby="compare-topic-${i}"><h2 id="compare-topic-${i}">${label}</h2>${careers.map(x=>`<div class="mobile-compare-value"><h3>${esc(x.title)}</h3><div>${value(x)}</div></div>`).join('')}</section>`).join('')}</div>`}
comparisonPage=function(){const careers=allCompareCareers(),add=state.content.filter(x=>x.type==='career'&&!state.compareIds.includes(x.id)).sort((a,b)=>a.title.localeCompare(b.title));const rows=[
  ['What you do',x=>esc(x.plain_tasks||x.description)],
  ['Why explore it?',x=>esc(personalCareer(x).quiz_reason||'Explore this career freely, or try the quiz for personal connections.')],
  ['Pay · check location & currency',x=>`<small>${esc(discoveryPayLabel(x))}</small><br>${esc(x.pay_range||'No verified benchmark')}${trustLine(x.salary_source_url,x.salary_last_verified_date,x.salary_region)}`],
  ['Education routes',x=>esc(x.education||'Check the local training route.')],
  ['Length of study',x=>esc(careerDuration(x))],
  ['Education cost',()=> 'Not verified. Depends on program, fee status and living costs. Compare official provider quotes.'],
  ['Schedule & balance',x=>esc(x.hours||'Varies by employer; not verified.')],
  ['Daily reality',x=>esc(x.day_in_life?.reality||x.work_environment||'Ask a worker about their typical week.')],
  ['Outlook',x=>`${esc(x.outlook||'Not verified for your location.')}${trustLine(x.outlook_source_url,x.outlook_last_verified_date,x.outlook_region)}`],
  ['Career progression',x=>esc((x.levels||[]).slice(0,4).join(' → ')||'Varies by employer. No guaranteed progression.')],
  ['Worth checking',x=>esc((personalCareer(x).fit_notes||['Check local entry requirements and whether the work fits your priorities.'])[0])],
  ['Go deeper',x=>`<button class="btn primary" onclick="openDetail('career',${jsArg(x.id)})">Explore More →</button>`]
  ];const core=new Set(['What you do','Pay · check location & currency','Education routes','Schedule & balance','Go deeper']);
  const shown=state.compareExpanded?rows:rows.filter(([label])=>core.has(label));
  return `<section class="v27-compare-header"><button class="link-btn" onclick="returnFromCompare()">← Back</button><span class="eyebrow">SIDE BY SIDE</span><h1>Compare careers</h1><p>See what changes from one job to another.</p></section>
  <div class="v24-compare-toolbar"><label for="compare-add">Add a career<select id="compare-add" onchange="if(this.value)toggleCompare(this.value)" ${careers.length>=3?'disabled':''}><option value="">Choose a career</option>${add.map(x=>`<option value="${esc(x.id)}">${esc(x.title)}</option>`).join('')}</select></label><span class="count-pill">${careers.length}/3 chosen</span><button class="btn secondary" onclick="saveComparison()" ${careers.length<2?'disabled':''}>Save comparison</button>${careers.length?'<button class="link-btn" onclick="clearComparison()">Clear picks</button>':''}</div>
  ${careers.length<2?`<div class="notice">${careers.length?'Add one more career to compare.':'Choose two careers above or from your results.'}</div>`:''}
  ${careers.length?`${mobileComparison(careers,shown)}<div class="v27-comparison-scroll desktop-comparison" tabindex="0" role="region" aria-label="Career comparison"><table class="v30-compare-table"><caption>Check each pay figure’s location and currency. Occupation benchmarks can differ from individual jobs.</caption><thead><tr><th scope="col">Compare</th>${careers.map(x=>`<th scope="col">${esc(x.title)}<br><button class="link-btn" onclick="toggleCompare(${jsArg(x.id)})" aria-label="Remove ${esc(x.title)} from comparison">Remove ×</button></th>`).join('')}</tr></thead><tbody>${shown.map(([label,value])=>`<tr><th scope="row">${label}</th>${careers.map(x=>`<td>${value(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><button class="btn secondary compare-details-toggle" aria-expanded="${!!state.compareExpanded}" onclick="state.compareExpanded=!state.compareExpanded;render()">${state.compareExpanded?'Show fewer details':'More comparison details'}</button>`:''}${discoveryStorageNote()}`};

// Source ranges are not career-stage forecasts. Keep the real benchmark and
// descriptive progression; do not invent raises by interpolating low/high pay.
salaryMicrocopy=function(item){return `<div class="salary-helper">${item.salary_last_verified_date?`${esc(item.salary_region)} · CAD · occupation benchmark`:'No verified local pay figure'}</div>`};
paySnapshot=function(x){return `<div class="pay-panel"><b>${esc(x.pay_range||'No verified pay benchmark')}</b><p>${esc(x.pay_note||'Pay varies by employer and region.')}</p><p class="muted">Before tax. Low and high figures do not mean starting and senior salaries. Related-occupation benchmarks may differ from this exact job title.</p>${trustLine(x.salary_source_url,x.salary_last_verified_date,x.salary_region)}</div>`};
payGrowthBlock=function(){return ''};
dayInLife=function(x){const p=x.day_in_life||{};return `<section class="v27-day-life"><h3>What the work involves</h3>${p.role_specific?list(p.activities||[]):`<p>${esc(x.plain_tasks||x.description)}</p>`}<p><b>Where you work</b><br>${esc(p.environment||x.work_environment||'Work settings depend on the employer.')}</p>${p.role_specific?`<p><b>The demanding part</b><br>${esc(p.reality)}</p>`:''}<small>Tasks and schedules vary by employer.</small></section>`};
careerDetail=function(x){const matched=personalCareer(x),related=state.content.filter(p=>p.type==='program'&&(p.related_careers||[]).includes(x.title)).slice(0,4);
  return `<div class="discovery-career-detail"><section class="career-explanation"><h3>What does this job do?</h3><p>${esc(x.description)}</p></section>
  <div class="career-detail-pay"><span>${esc(discoveryPayLabel(x))}</span><strong>${esc(compactCareerPay(x))}</strong><small>${x.salary_last_verified_date?'Occupation benchmark. Full range and source below.':'Pay data has not been recorded for this role.'}</small></div>
  <div class="discovery-detail-actions"><button class="btn primary" onclick="openRoadmap(${jsArg(x.id)})">Explore my next steps</button><button class="btn secondary" onclick="toggleSave('career',${jsArg(x.id)})">${isSaved(x)?'Saved ✓':'Save career'}</button><button class="btn secondary" onclick="toggleCompare(${jsArg(x.id)})">${state.compareIds.includes(x.id)?'✓ Comparing':'Add to compare'}</button><button class="link-btn" onclick="openCompare()">View comparison (${state.compareIds.length}/3)</button></div>
  ${mobileAccordion('Day in the Life','See the tasks behind the title',dayInLife(x))}
  ${mobileAccordion('Education & entry','Training routes and useful subjects',`<p>${esc(x.education||'Check the requirements for the course and location you choose.')}</p>${routeOptionsBlock(x)}<h4>Useful school subjects</h4>${chips(x.school_subjects||[])}<p class="muted">These subjects are preparation. Check each program’s actual entry requirements before applying.</p>${related.length?`<h4>Ontario programs</h4><div class="grid two">${related.map(p=>programCard(p)).join('')}</div>`:''}`)}
  ${mobileAccordion('Pay & outlook','Location, dates and official sources',`${paySnapshot(x)}<h4>Outlook</h4><p>${esc(x.outlook||'No verified outlook for your location.')}</p>${trustLine(x.outlook_source_url,x.outlook_last_verified_date,x.outlook_region)}`)}
  ${mobileAccordion('Career steps','How people get started and progress',`${timelineBlock(x)}${roadmapBlock(x)}${(x.levels||[]).length?list(x.levels):''}`)}
  ${matched.quiz_reason?mobileAccordion('Why this came up','Connections to your answers',`<p>${esc(matched.quiz_reason)}</p>${list(matched.fit_notes||[])}`):''}
  ${mobileAccordion('Other paths to consider','Compare nearby ideas',relatedCareerBlock(x))}
  <details class="career-source"><summary>Career information source</summary><p>Plain-language overview of this occupation. Individual jobs differ by employer.</p>${trustLine(x.overview_source_url||x.source_url,x.overview_reviewed||x.last_verified_date,/onetonline|bls\.gov/.test(x.overview_source_url||x.source_url||'')?'US occupational overview':'Career reference')}</details><button class="link-btn" onclick="shareCareerNative(${jsArg(x.title)})">Share this career ↗</button></div>`;
};
currentStudentGrade=function(){const stage=state.quizAnswers.find(a=>a.startsWith('stage:'));
  if(stage==='stage:early'||stage==='stage:middle')return 'Grade 9';if(stage==='stage:senior')return 'Grade 12';
  if(stage==='stage:postsecondary'||stage==='stage:career')return 'Post-secondary';
  const value=String(state.user?.grade||'');for(const grade of ['9','10','11','12'])if(new RegExp(`\\b${grade}\\b`).test(value))return 'Grade '+grade;
  return 'Grade 11';
};
const discoveryRoadmapModal=roadmapModal;
roadmapModal=function(){return discoveryRoadmapModal().replace('<div class="roadmap-controls">',`<details class="career-source"><summary>About this plan</summary><p>This starter plan uses Ontario education routes. Choose the closest stage and check course or licensing requirements with the official provider.</p><p>If you have not started high school, use Grade 9 as a future starting point.</p></details><div class="roadmap-controls">`)};
const discoveryCreatePlan=createPlanFor,discoveryAddProgram=addProgramFromDetail;
createPlanFor=async function(type,id){if(!state.user){state.detail=null;showAuth('signup');state.authMessage='An account is needed for server checklists. You can keep exploring and saving items on this device without one.';render();return}return discoveryCreatePlan(type,id)};
addProgramFromDetail=async function(id){if(!state.user){state.detail=null;showAuth('signup');state.authMessage='An account is needed for the application tracker. Guest bookmarks remain on this device.';render();return}return discoveryAddProgram(id)};
shareCareerNative=async function(title){const x=state.content.find(c=>c.type==='career'&&c.title===title),url=`${location.origin||'https://pathway-v8.onrender.com'}/${x?'?career='+encodeURIComponent(x.id):''}`;
  try{const share=window.Capacitor?.Plugins?.Share;if(isIOSApp()&&share)await share.share({title:`${title} — Pathway`,text:`Explore ${title} on Pathway.`,url});
    else if(navigator.share)await navigator.share({title:`${title} — Pathway`,url});
    else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);toast('Career link copied.')}else toast(`Copy this career link: ${url}`)}catch(e){if(e.name!=='AbortError')toast('Sharing unavailable. Copy the site address from your browser.')}
};

function deadlineLabel(x){return x.deadline_status==='closed'?'Closed for this cycle':x.deadline_status==='due_today'?'Due today · check closing time':'Deadline · check year'}
scholarshipCard=function(x){return discoveryLegacy.scholarshipCard(x).replace('Deadline</span>',`${deadlineLabel(x)}</span>`).replace(`<span>${statusBadge(x)}</span>`,x.deadline_status==='closed'?'<span class="closed-award">Deadline passed</span>':`<span>${statusBadge(x)}</span>`) };
const discoveryScholarshipDetail=scholarshipDetail;
scholarshipDetail=function(x){return `${x.deadline_status==='closed'?'<div class="notice"><b>This application deadline has passed.</b><p>Check the official site for a future cycle. A new deadline has not been recorded.</p></div>':''}${discoveryScholarshipDetail(x)}`};

// A gentle, optional curiosity activity belongs in exploration, not in the
// required questionnaire. It changes a search, never declares a career fit.
let careerSearchTimer;
function queueCareerSearch(value){state.query=value;state.careerLimit=24;clearTimeout(careerSearchTimer);careerSearchTimer=setTimeout(()=>{if(state.view==='explore'&&!state.detail)render()},180)}
function searchWords(value){return String(value||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
const careerSearchAliases={coding:['coding','code','software','programming'],nursing:['nursing','nurse'],nurses:['nurse'],programmer:['software','developer','programming'],developer:['developer','software'],science:['science','scientist'],tech:['technology','software','computer'],sports:['sport','athlete','athletic'],counselor:['counsellor','counsel','psychologist']};
filteredCareers=function(){let careers=state.content.filter(x=>x.type==='career');
  if(state.category==='different-routes')careers=careers.filter(x=>(x.route_options||[]).some(r=>r.type&&!['university','open'].includes(r.type)));
  else if(state.category!=='all')careers=careers.filter(x=>[x.industry,x.subtitle,...(x.tags||[])].includes(state.category));
  const words=searchWords(state.query).split(' ').filter(Boolean);if(!words.length)return careers;
  const matches=(text,word)=>(careerSearchAliases[word]||[word]).some(term=>term.length<3?text.split(' ').includes(term):text.includes(term));
  return careers.map(x=>{const title=searchWords(x.title),text=searchWords([x.title,x.description,x.industry,...(x.tags||[]),...(x.skills||[])].join(' '));return {x,hit:words.every(w=>matches(text,w)),rank:words.filter(w=>matches(title,w)).length}})
    .filter(r=>r.hit).sort((a,b)=>b.rank-a.rank||a.x.title.localeCompare(b.x.title)).map(r=>r.x);
};
function clearCareerFilters(){clearTimeout(careerSearchTimer);state.query='';state.category='all';state.careerLimit=24;render()}
function browseHobby(query){state.category='all';setCareerQuery(query)}
explore=function(){const careers=filteredCareers(),visible=careers.slice(0,state.careerLimit),industries=[...new Set(state.content.filter(x=>x.type==='career').map(x=>x.industry||x.subtitle))].sort();
  return `<div class="page-title"><span class="eyebrow">CAREERS</span><h1>What would you like to do?</h1><p>Choose a job to see what the work is like.</p></div>
  <div class="catalog-actions"><button class="btn secondary" onclick="startCareerQuiz()">Help me find ideas</button><button class="btn secondary" onclick="openCompare()">Compare (${state.compareIds.length}/3)</button></div>
  <div class="catalog-controls"><label for="career-search">Search careers<input id="career-search" type="search" placeholder="Try nursing, coding or sports" value="${esc(state.query)}" oninput="queueCareerSearch(this.value)"></label><label for="career-industry">Field<select id="career-industry" onchange="setCareerCategory(this.value)"><option value="all" ${state.category==='all'?'selected':''}>All fields</option><option value="Unexpected Path" ${state.category==='Unexpected Path'?'selected':''}>Less obvious careers</option><option value="different-routes" ${state.category==='different-routes'?'selected':''}>College, trades & other routes</option>${industries.map(i=>`<option value="${esc(i)}" ${state.category===i?'selected':''}>${esc(i)}</option>`).join('')}</select></label></div>
  <div class="catalog-count"><p role="status">${careers.length} career${careers.length===1?'':'s'} found</p>${state.query||state.category!=='all'?'<button class="link-btn" onclick="clearCareerFilters()">Clear filters</button>':''}</div>
  ${careers.length?`<div class="grid">${visible.map(careerCard).join('')}</div>${visible.length<careers.length?`<div class="load-more"><button class="btn secondary" onclick="state.careerLimit+=24;render()">Show more careers</button><span>Showing ${visible.length} of ${careers.length}</span></div>`:''}`:'<div class="empty"><h2>No careers found</h2><p>Try fewer words or choose another field.</p><button class="btn secondary" onclick="clearCareerFilters()">Show all careers</button></div>'}
  <p class="catalog-pay-note">Pay figures use Ontario occupation groups. Open a career for the range and source.</p>
  <details class="discovery-hobbies"><summary>Explore a hobby</summary><p>Choose a topic to see related jobs.</p><div class="discovery-secondary">${[['Sport','sport'],['Games','game'],['Music','music'],['The environment','climate'],['Investigating records','forensic'],['Making things','design']].map(([label,query])=>`<button class="chip" onclick="browseHobby('${query}')">${label}</button>`).join('')}</div></details>`};
scholarships=function(){const q=state.query.trim().toLowerCase(),items=state.content.filter(x=>x.type==='scholarship'&&(!q||[x.title,x.organization,x.description,x.eligibility].join(' ').toLowerCase().includes(q))).sort((a,b)=>(a.deadline_status==='closed')-(b.deadline_status==='closed'));
  return `<div class="page-title"><span class="eyebrow">FUNDING</span><h1>Find funding for your studies.</h1><p>Check each award’s current deadline and eligibility before applying.</p></div><div class="toolbar"><div class="search"><span aria-hidden="true">⌕</span><input aria-label="Search scholarships" placeholder="Search scholarships" value="${esc(state.query)}" oninput="state.query=this.value;render()"></div></div><div class="grid">${items.map(scholarshipCard).join('')||emptySmall('No awards match that search. Try fewer words.')}</div>`;
};

// Accessibility enhancements apply to preserved screens too: keyboard card
// activation, associated labels, modal focus trap, focus return and skip links.
const PATHWAY_ROUTES={home:'home',explore:'careers',universities:'education',scholarships:'funding',careerquiz:'quiz',compare:'compare',mypath:'saved',tools:'tools',admissions:'courses',advisor:'ask',admin:'admin'};
let restoringNavigation=false,lastRenderedPage='';
function navigationSnapshot(){const screen=state.screen;if(!['app','landing','login','signup','onboarding','resetRequest'].includes(screen))return null;const detail=state.detail?.type?{type:state.detail.type,id:state.detail.id}:null;return {pathway:1,screen,view:state.view,detail,quizStep:state.view==='careerquiz'?state.quizStep:null,query:state.query,category:state.category,careerLimit:state.careerLimit,owner:state.user?.id||null,scroll:window.scrollY||0}}
function navigationKey(snapshot){return [snapshot.screen,snapshot.view,snapshot.detail?.type||'',snapshot.detail?.id||'',snapshot.quizStep??''].join('|')}
function navigationURL(snapshot){if(snapshot.screen==='landing')return '#/';if(snapshot.screen!=='app')return '#/'+snapshot.screen;if(snapshot.detail?.type==='career')return '#/career/'+encodeURIComponent(snapshot.detail.id);return '#/'+(PATHWAY_ROUTES[snapshot.view]||'home')}
function rememberNavigation(){if(restoringNavigation||!history.replaceState)return;const snapshot=navigationSnapshot();if(!snapshot)return;const old=history.state?.pathway?history.state:null,key=navigationKey(snapshot);snapshot.previousKey=old?.previousKey||null;
  if(!old||old.owner!==snapshot.owner){snapshot.previousKey=null;history.replaceState(snapshot,'',navigationURL(snapshot));return}
  if(navigationKey(old)===key){history.replaceState(snapshot,'',navigationURL(snapshot));return}
  if(old.detail&&!snapshot.detail&&old.view===snapshot.view&&old.screen===snapshot.screen){history.replaceState(snapshot,'',navigationURL(snapshot));return}
  if(old.previousKey===key&&history.back){history.back();return}
  history.replaceState({...old,scroll:window.scrollY||0},'');snapshot.previousKey=navigationKey(old);if(history.pushState)history.pushState(snapshot,'',navigationURL(snapshot));else history.replaceState(snapshot,'',navigationURL(snapshot));
}
function restoreNavigation(snapshot){if(!snapshot?.pathway)return;restoringNavigation=true;try{if(snapshot.owner!==(state.user?.id||null)){state.screen=state.user?'app':'landing';state.view='home';state.detail=null}else{state.screen=snapshot.screen;state.view=PATHWAY_ROUTES[snapshot.view]?snapshot.view:'home';state.query=snapshot.query||'';state.category=snapshot.category||'all';state.careerLimit=snapshot.careerLimit||24;if(state.view==='careerquiz'&&Number.isInteger(snapshot.quizStep))state.quizStep=Math.min(QUIZ_QUESTIONS.length,Math.max(0,snapshot.quizStep));state.detail=snapshot.detail?state.content.find(x=>x.type===snapshot.detail.type&&x.id===snapshot.detail.id)||null:null}state.profileOpen=false;render();focusPageHeading();window.scrollTo(0,snapshot.scroll||0)}finally{restoringNavigation=false}}
window.addEventListener?.('popstate',event=>restoreNavigation(event.state));
function restoreInitialRoute(){const route=String(location.hash||'').replace(/^#\//,'');if(route==='study-abroad'){state.screen='app';state.view='universities';state.detail=null;return}if(route.startsWith('career/')){try{const id=decodeURIComponent(route.slice(7)),career=state.content.find(x=>x.type==='career'&&x.id===id);if(career){state.screen='app';state.view='explore';state.detail=career}}catch{}return}const entry=Object.entries(PATHWAY_ROUTES).find(([,value])=>value===route);if(entry&&(entry[0]!=='admin'||state.user?.is_admin)){state.screen='app';state.view=entry[0]}}
function focusIdentity(el){if(!el)return null;const actionAttribute=['onclick','onchange','oninput'].find(a=>el.getAttribute?.(a));return {id:el.id,action:actionAttribute?el.getAttribute(actionAttribute):null,actionAttribute,text:el.textContent?.trim(),value:el.getAttribute?.('data-quiz-value')}}
function matchingFocus(identity,root=document){if(!identity)return null;if(identity.id)return document.getElementById(identity.id);const candidates=Array.from(root.querySelectorAll('button,a,input,select,textarea,summary,[tabindex]')).filter(el=>el.getClientRects().length);return candidates.find(el=>identity.value?el.getAttribute('data-quiz-value')===identity.value:identity.action&&el.getAttribute(identity.actionAttribute)===identity.action&&el.textContent.trim()===identity.text)||candidates.find(el=>identity.action&&el.getAttribute(identity.actionAttribute)===identity.action)}
render=function(){
  const active=document.activeElement,identity=focusIdentity(active),previousModal=document.querySelector('.modal'),hadModal=!!previousModal,previousTitle=previousModal?.querySelector('h2,h1,h3')?.textContent;
  const modalScroll=previousModal?.scrollTop||0,openSections=previousModal?Array.from(previousModal.querySelectorAll('details')).map(el=>el.open):[];
  const pageKey=state.screen+':'+state.view,pageSections=pageKey===lastRenderedPage?Array.from(document.querySelectorAll('main details')).map(el=>({title:el.querySelector('summary')?.textContent,open:el.open})):[];
  const selection=['INPUT','TEXTAREA'].includes(active?.tagName)?{start:active.selectionStart,end:active.selectionEnd}:null;
  if(state.detail&&!hadModal)discoveryModalOpener=identity;
  discoveryLegacy.render();
  const main=document.querySelector('main');if(main){main.id='main-content';main.tabIndex=-1}
  if(state.catalogError&&state.screen==='app'&&main)main.insertAdjacentHTML('afterbegin',catalogErrorBlock());
  if(state.catalogOffline&&state.screen==='app'&&main)main.insertAdjacentHTML('afterbegin','<div class="notice" role="status"><b>Showing saved career data.</b> Connect to refresh it. Check source dates before using education or funding details. <button class="link-btn" onclick="retryCatalog()">Try refreshing</button></div>');
  if(state.accountError&&state.user&&main)main.insertAdjacentHTML('afterbegin',`<div class="error" role="alert"><p>${esc(state.accountError)}</p><button class="btn secondary" onclick="retryAccount()" ${state.loading?'disabled':''}>Retry account loading</button></div>`);
  document.querySelectorAll('.search input').forEach(el=>el.setAttribute('aria-label',el.getAttribute('placeholder')||'Search'));
  document.querySelectorAll('.field').forEach((field,i)=>{const input=field.querySelector('input,select,textarea'),label=field.querySelector('label');if(input&&label){input.id=input.id||`field-${i}`;label.htmlFor=input.id}});
  document.querySelectorAll('article.clickable').forEach(el=>{el.tabIndex=0;el.setAttribute('role','group');el.setAttribute('aria-label',el.querySelector('h3')?.textContent||'Explore item');
    if(!el.querySelector('.discovery-open-item')){const button=document.createElement('button');button.className='link-btn discovery-open-item';button.textContent='Explore More →';button.setAttribute('onclick',el.getAttribute('onclick'));el.appendChild(button)}});
  document.querySelectorAll('.save-btn').forEach(el=>{if(!el.getAttribute('aria-label'))el.setAttribute('aria-label',`${el.classList.contains('saved')?'Unsave':'Save'} ${el.closest('article')?.querySelector('h3')?.textContent||'item'}`)});
  document.querySelectorAll('.select-card').forEach(el=>{if(!el.hasAttribute('aria-pressed'))el.setAttribute('aria-pressed',el.classList.contains('selected'))});
  document.querySelectorAll('.mini-delete').forEach(el=>el.setAttribute('aria-label','Remove step: '+(el.closest('.plan-task')?.querySelector('b')?.textContent||'planned task')));
  const modal=document.querySelector('.modal');
  document.body.style.overflow=modal?'hidden':'';
  document.querySelectorAll('.topbar,.bottom-nav,main').forEach(el=>{el.inert=!!modal&&!el.contains(modal)});
  if(modal){modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');const title=modal.querySelector('h2,h1,h3');if(title){title.id='dialog-title';title.tabIndex=-1;modal.setAttribute('aria-labelledby','dialog-title')}
    if(hadModal&&previousTitle===title?.textContent){modal.scrollTop=modalScroll;modal.querySelectorAll('details').forEach((el,i)=>{if(i<openSections.length)el.open=openSections[i]})}
    modal.querySelectorAll('.close').forEach(el=>el.setAttribute('aria-label','Close details'));
    if(!hadModal||previousTitle!==title?.textContent)title?.focus({preventScroll:true});else matchingFocus(identity,modal)?.focus({preventScroll:true})}
  else if(hadModal){matchingFocus(discoveryModalOpener)?.focus({preventScroll:true});discoveryModalOpener=null}
  else if(['BUTTON','SELECT','INPUT','TEXTAREA','SUMMARY'].includes(active?.tagName)){const target=matchingFocus(identity);target?.focus({preventScroll:true});if(selection)try{target?.setSelectionRange(selection.start,selection.end)}catch{}}
  if(pageSections.length)document.querySelectorAll('main details').forEach((el,i)=>{if(pageSections[i]?.title===el.querySelector('summary')?.textContent)el.open=pageSections[i].open});
  lastRenderedPage=pageKey;
  const pageTitle=document.querySelector('.modal h2,#main-content h1')?.textContent?.trim();if(pageTitle)document.title=pageTitle+' — Pathway';
  rememberNavigation();
  document.querySelectorAll('.toast').forEach(el=>{el.setAttribute('role','status');el.setAttribute('aria-live','polite')});
};
toast=function(message){state.toast=message;document.querySelectorAll('.toast').forEach(el=>el.remove());
  document.body.insertAdjacentHTML('beforeend',`<div class="toast" role="status" aria-live="polite">${esc(message)}</div>`);
  clearTimeout(discoveryToastTimer);discoveryToastTimer=setTimeout(()=>{state.toast='';document.querySelectorAll('.toast').forEach(el=>el.remove())},4500)
};
document.addEventListener('keydown',event=>{
  const modal=document.querySelector('.modal');
  if(event.key==='Escape'){if(modal){event.preventDefault();closeDetail()}else if(state.profileOpen){state.profileOpen=false;render()}return}
  if(modal&&event.key==='Tab'){const elements=Array.from(modal.querySelectorAll('button,a[href],input,select,textarea,summary,[tabindex="0"]')).filter(x=>!x.disabled&&x.getClientRects().length);
    const first=elements[0],last=elements[elements.length-1];if(!first){event.preventDefault();return}
    if(event.shiftKey&&(document.activeElement===first||document.activeElement?.id==='dialog-title')){event.preventDefault();last.focus()}
    else if(!event.shiftKey&&(document.activeElement===last||document.activeElement?.id==='dialog-title')){event.preventDefault();first.focus()}}
  if((event.key==='Enter'||event.key===' ')&&event.target.matches('article.clickable')){event.preventDefault();event.target.click()}
});

configureIOSApp().finally(()=>bootstrap());
