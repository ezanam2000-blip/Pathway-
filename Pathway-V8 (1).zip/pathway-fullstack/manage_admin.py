"""Operator-only recovery command. Never exposed as an HTTP endpoint."""
import argparse
from getpass import getpass


def reset_admin(email, password, grant_admin=False):
    import app
    if not 8 <= len(password) <= 128:
        raise ValueError('Use a password between 8 and 128 characters.')
    with app.connect() as con:
        user = con.execute('SELECT id,is_admin FROM users WHERE email=?', (email.strip().lower(),)).fetchone()
        if not user:
            raise ValueError('No account has that address. Create the intended account first.')
        if not user['is_admin'] and not grant_admin:
            raise ValueError('This account is not an admin. Verify its owner before using --grant-admin.')
        con.execute('UPDATE users SET password_hash=?,is_admin=1,email_verified=1,updated_at=? WHERE id=?',
                    (app.hash_password(password), app.now_iso(), user['id']))
        con.execute('DELETE FROM sessions WHERE user_id=?', (user['id'],))
        con.execute('DELETE FROM auth_tokens WHERE user_id=?', (user['id'],))
        con.commit()


def main():
    parser = argparse.ArgumentParser(description='Recover an existing admin using trusted server access.')
    parser.add_argument('--email', required=True)
    parser.add_argument('--grant-admin', action='store_true', help='Explicitly grant admin after independently verifying the account owner.')
    args = parser.parse_args()
    password = getpass('New admin password: ')
    if password != getpass('Repeat new password: '):
        parser.error('Passwords do not match.')
    try:
        reset_admin(args.email, password, args.grant_admin)
    except ValueError as error:
        parser.error(str(error))
    print('Admin password updated. Previous sessions and authentication links were revoked.')


if __name__ == '__main__':
    main()
