"""V20 exploratory career roadmaps. These are guidance, not admissions determinations."""
from __future__ import annotations

GRADE_OPTIONS = ('Grade 9', 'Grade 10', 'Grade 11', 'Grade 12', 'Post-secondary')


def grade_index(grade: str) -> int:
    label = str(grade or '').lower()
    for n in ('9', '10', '11', '12'):
        if n in label:
            return int(n)-9
    return 4 if any(x in label for x in ('college', 'university', 'post-', 'early career')) else 3


def route_choices(career: dict) -> list[dict]:
    raw = career.get('route_options') or []
    found = []
    seen = set()
    for i, route in enumerate(raw[:6]):
        key = str(route.get('type') or f'option{i}').lower().strip()
        if key in seen:
            continue
        seen.add(key)
        found.append({'key':key, 'name':route.get('name') or 'Explore this route',
                      'summary':route.get('summary') or '', 'requirement':route.get('requirement') or '',
                      'source_url':route.get('source_url') or None})
    if not found:
        found = [{'key':'open','name':'Explore possible routes',
                  'summary':career.get('education') or 'Research training and entry requirements.',
                  'requirement':'', 'source_url':None}]
    return found


def build_career_roadmap(career: dict, grade: str, route_key: str, programs: list[dict] | None = None) -> dict:
    """Plan anchored to existing career data, not fabricated program prerequisites."""
    routes = route_choices(career)
    chosen = next((r for r in routes if r['key'] == route_key), None)
    if not chosen:
        raise ValueError('Invalid education route for this career')
    subjects = [str(s).strip() for s in (career.get('school_subjects') or []) if str(s).strip()][:4]
    skills = [str(s).strip() for s in (career.get('skills') or []) if str(s).strip()][:3]
    tips = [str(s).strip() for s in (career.get('success_tips') or []) if str(s).strip()][:3]
    path_steps = [str(s).strip() for s in (career.get('pathway_steps') or []) if str(s).strip()]
    subject_text = ', '.join(subjects) if subjects else 'relevant school subjects'
    skill_text = ', '.join(skills[:2]) if skills else 'practical and communication skills'
    route_name = chosen['name']
    name = career['title']

    phases = [
        {'id':'grade9','label':'Grade 9','subtitle':'Explore without closing doors','steps':[
            f'Look into what {name.lower()} professionals do during a typical workday.',
            f'Try a beginner project, club, or class related to {name.lower()}.',
            f'Ask a guidance counsellor which courses keep {subject_text} available later.'
        ]},
        {'id':'grade10','label':'Grade 10','subtitle':'Build your foundation','steps':[
            f'Explore school courses related to {subject_text}; these are suggestions, not confirmed admission prerequisites.',
            f'Practice {skill_text} through a club, class, project, or community activity.',
            'Talk to a teacher, counsellor, or someone working in this field about the reality of the job.'
        ]},
        {'id':'grade11','label':'Grade 11','subtitle':'Explore real options','steps':[
            f'Compare {route_name.lower()} with other routes shown for this career.',
            f'Check Grade 12 prerequisite courses directly on official Ontario program or trade pages; requirements vary.',
            f'{tips[0] if tips else "Try a short volunteer role, project, co-op opportunity, or relevant club."}'
        ]},
        {'id':'grade12','label':'Grade 12','subtitle':'Choose your next move','steps':[
            f'Confirm entry requirements, deadlines, and fees for the {route_name.lower()} directly with the provider.',
            'Make a shortlist of realistic programs, training providers, or entry opportunities, including a backup choice.',
            f'{tips[1] if len(tips)>1 else "Prepare your applications and document the experience you have gained."}'
        ]},
        {'id':'training','label':'After high school','subtitle':'Learn and gain experience','steps':[
            f'Follow the {route_name.lower()}: {chosen["summary"] or "research the specific training and experience expected"}',
            path_steps[2] if len(path_steps)>2 else 'Seek a co-op, apprenticeship placement, portfolio project, internship, or relevant work experience.',
            'Track projects and responsibilities you can explain on a résumé or portfolio.'
        ]},
        {'id':'early','label':'Early career','subtitle':'Get started and keep growing','steps':[
            path_steps[3] if len(path_steps)>3 else f'Identify entry-level opportunities connected to {name.lower()}.',
            path_steps[4] if len(path_steps)>4 else 'Build relevant skills and ask for feedback from people in the field.',
            'Reassess the fit after real experience; career paths and timelines vary.'
        ]}
    ]
    focus = min(grade_index(grade), 4)
    for idx, phase in enumerate(phases):
        phase['state'] = 'now' if idx == focus else ('past' if idx < focus else 'future')

    related = []
    for program in programs or []:
        # These are options to explore. A matching program is not automatically required for the job.
        if program.get('status') != 'verified':
            continue
        related.append({'id':program['id'], 'title':program['title'], 'university':program.get('university') or '',
                        'requirements':(program.get('requirements') or [])[:4],
                        'source_url':program.get('requirements_source_url') or program.get('source_url'),
                        'verified_date':program.get('requirements_last_verified_date') or program.get('last_verified_date'),
                        'status':program.get('status')})
        if len(related) >= 5:
            break
    return {'career':{'id':career['id'],'title':name,'industry':career.get('industry') or '',
                      'education':career.get('education') or '', 'source_url':career.get('source_url'),
                      'last_verified_date':career.get('last_verified_date')},
            'grade':grade,'focus_index':focus,'route':chosen,'routes':routes,
            'phases':phases,'suggested_subjects':subjects,'suggested_skills':skills,
            'related_programs':related, 'region':'Ontario, Canada',
            'disclaimer':'This roadmap is guidance, not a guarantee of admission or employment. Suggested high-school subjects are not verified prerequisites. Confirm courses, entry rules, costs and deadlines with the official institution or trade authority.'}


def starting_tasks(roadmap: dict) -> list[tuple[str,str,int]]:
    """Five manageable, actionable tasks from the student's current stage."""
    index = roadmap['focus_index']
    stages = roadmap['phases']
    tasks = [(title, stages[index]['label'], 1) for title in stages[index]['steps']]
    if index < len(stages)-1:
        tasks.extend((title, stages[index+1]['label'], 2) for title in stages[index+1]['steps'][:2])
    return tasks[:5]
