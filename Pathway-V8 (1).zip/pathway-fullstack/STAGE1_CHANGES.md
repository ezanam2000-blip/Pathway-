# Pathway V9 — Stage 1 Core Experience

Built from the existing V8/PostgreSQL version.

Implemented:
- Homepage with one dominant "Find My Career" CTA and six benefit cards
- Instant cold-start loading shell
- 10-question one-question-per-screen Career Match quiz
- Weighted quiz tags stored with career records
- 5–8 diversified ranked career matches with plain-language reasons
- Guest quiz flow before account creation
- Save Career actions on results
- Career detail facts: pay, education, hours, growth, competition, remote potential, skills
- Clickable structured Career Path timeline
- Investment Banking timeline from high school through Managing Director
- Structured "How to get there" roadmaps for every career
- Plain-language jargon tooltips
- Clear actions: Compare Careers, Build My Pathway, Save Career
- PostgreSQL-compatible migrations for the new career fields

Validation:
- 5/5 pytest tests pass
- JavaScript syntax check passes

- Rewrote key site copy in simpler, more natural language and removed marketing/AI-style wording such as personalized.
