# Pathway V31 — audit, implementation and handoff

Date: October 21, 2026. API version: 6.2.0.

## Status

Implemented in the existing V30 project package, not a replacement app. Production is **not updated** by this source handoff. The connected GitHub integration previously rejected writes with HTTP 403; no bypass, repository write, production-data change or hosting-plan purchase was attempted.

The release contains a tested first-stage discovery journey and honest partial coverage for international research. It is not a claim that the full global education database, comprehensive accessibility certification or production readiness is complete.

## Audit before changes

The live website at https://pathway-v8.onrender.com/ was inspected through its public UI and compared with the matching V30 source archive. What worked and was retained: the navy visual style, existing career and education APIs, adaptive route questions, five-result matcher, niche-role catalog, side-by-side comparison foundation, anonymous roadmap previews, account authentication, checklist/application tracker, Ontario course checker, iOS wrapper and international source links.

| Finding | V31 response |
| --- | --- |
| Guest entry through Study abroad reached the app shell, but the career explorer showed zero careers because only authenticated bootstrap loaded content. | Load the public catalog independently from login; navigation works for guests. |
| Reloading during the quiz returned to the landing screen with lost progress. | Browser-scoped persistence with an explicit Continue action; optional account sync. |
| Questions required an answer; changing an early answer discarded every later answer. | Skip/back/pause/edit; stable question IDs; only incompatible adaptive answers are cleared. |
| Mandatory curiosity/mystery question was weakly connected to a user’s understanding of the quiz. | Replace with meaningful strengths, subjects, environment and stage. Hobby searches are optional in exploration. |
| Guests saw account menus/actions they could not use. | Guest Log in entry, usable local bookmarks, and explicit account boundaries for server checklists and applications. |
| Comparisons could not be saved or resumed; result saves required accounts. | Save comparisons and bookmarks locally; account discovery persists to a user-owned server document. |
| Desktop career details were much denser than mobile. | One progressive-disclosure detail component for every viewport, reusing existing route/timeline components. |
| Low/high salary figures were presented as starting/senior pay and interpolated into a raise ladder. | Remove invented progression figures; retain dated benchmark/source and descriptive career steps. |
| Some clickable cards, icon-only controls and modal flows lacked keyboard/focus support. | Explicit Explore buttons, accessible labels, focus outlines, skip link, modal semantics, focus trap/Escape/return, select-focus retention. |
| Scholarship screen had an unclosed toolbar wrapper. | Replace that screen’s layout while retaining its records, detail pages and save actions. |

## Implemented stages

### 1. Navigation and questionnaire

- One main landing action: Discover My Path, or Continue my discovery when progress exists. Browse careers, study abroad and login are secondary.
- Ten short question screens: interests, strengths, subjects, learning route, adaptive route detail, adaptive work preference, work setting, schedule, priorities and education stage.
- Multi-select cards, visible selection status and progress, back, skip, pause, edit and refresh recovery. All-skipped or unrecognized preferences lead to open browsing, not alphabetical “best matches.”
- Existing finance/trades/public-safety branching is retained. Education stage guides starter steps, not career eligibility. No prestige ranking is offered.
- Device-storage, connection, timeout, validation and partial-account loading states have meaningful messages and retry controls.

### 2. Results, careers and comparisons

- Three concise result cards first, with reasons, annual pay reference or an explicit unknown, general education, Save, Add to compare and Explore More. Two further matches are optional.
- Fit cautions identify potential schedule or preferred-route conflicts. Suggestions are not percentages, assessments of ability or promises of admission/employment.
- Existing 217 unique careers retained; three reviewed additions bring the catalog to **220**: Industrial Ecologist, Wind Energy Operations Manager and Medical Dosimetrist.
- New role overviews use O*NET/BLS US sources reviewed October 21, 2026. They do not inherit unrelated Ontario pay/outlook values or claim global qualifications. See `DATA_SOURCES.md` and `sourced_careers.py`.
- Day in the Life includes illustrative work phases, tasks, setting, challenge, possible reward and misconception. Editorial examples and missing worker interviews/video evidence are clearly identified.
- Two/three-career comparison aligns duties, personal connections, pay provenance, education, recorded study duration, cost unknowns, schedule, reality, outlook, progression and international research. It does not choose a winner.
- Up to eight comparison sets can be saved. Current comparison picks and saved sets survive a refresh; account documents are isolated by authenticated user.

### 3. Saved space and international research

- Guest Saved & plan holds bookmarks, results and comparisons on the device. Existing account roadmap, task and application features remain available in an expandable account section.
- Optional account discovery synchronization, retry status, explicit guest-import choice, history clearing and account deletion support. Clearing discovery history deliberately keeps existing bookmarked items, tasks and applications.
- Destination, subject, home-country and degree/exchange research controls retained across eight country guides. Education-level filtering applies to recorded named awards. An empty award filter explains that other funding may exist.
- Optional yearly budget/currency helps set a research ceiling. It is **not an affordability filter**: there is no verified course-price dataset to filter honestly.
- Domestic versus international fee/entry status, citizenship and award eligibility are distinguished in the interface. Home country alone does not establish them.
- Career profiles connect to the existing roadmap, recorded Ontario education options, official source links and international study research. Suggested subjects, institution prerequisites, minimum eligibility and competitive admission are explicitly distinguished.
- Privacy copy describes guest browser storage, server requests, account copies, non-persisted checker grades and research controls. This is a description of implementation, not legal certification.

## Code organization and compatibility

- `static/app.js` retains established account, catalog and route/checklist features; it defines the revised question data. Startup is moved to the final discovery layer.
- `static/discovery.js` owns public discovery, persistence, shared UI and accessibility enhancements; loaded after the established app, before startup. `static/discovery.css` extends the existing theme without adding a framework.
- `discovery_state.py` bounds the account document and matches new preferences against recorded role information. Substring tests prevent “website” becoming outdoor “site” work or “career” becoming patient “care.”
- `sourced_careers.py` keeps new source-reviewed profiles separate from legacy occupation benchmarks. Salary and outlook provenance can be explicitly absent rather than falsely inheriting an overview date.
- `discovery_states` is an additive SQLite/Postgres-compatible table keyed by authenticated user. Saved career/program APIs and existing tables are unchanged. Database reinitialization is covered by a persistence check.
- Local keys separate guest and account workspaces. No grades, password or email is stored in the discovery document. Account discovery copies can remain in browser storage after logout; privacy copy advises clearing browser data on shared devices.
- No new runtime dependency, media embed, analytics SDK, hosting service or paid resource was added.

## Validation performed

- `python -m pytest -q`: **27 passed**, including existing API/authentication/roadmap/course-checker tests and new guest, scoring, bounds, account isolation, reset, provenance and database-reinitialization tests. All 220 careers can open their primary roadmap preview through the API.
- `node tests/frontend_discovery.cjs`: passed. This starts a disposable real backend and exercises the actual frontend renderer/handlers through guest catalog loading, quiz completion, selective branch edits, all-skip, simulated refresh, bookmarks, comparisons, account sync, logout/isolation, history controls and error cases.
- Every one of the **220** career-detail renderers and **11** navigation views is generated; visible inline handlers are checked for JavaScript syntax. International award-level filters and budget guidance are checked.
- `node --check` validates JavaScript syntax. Existing backend deprecation warnings for FastAPI startup hooks and the test HTTP client remain; tests pass despite them.
- Production guest audit was performed before editing. The isolated cloud browser could not reach the local build, so no local-build browser screenshot, real phone, tablet, screen-reader or visual regression pass is claimed. DOM stubs cannot validate computed layout, native focus behaviour or screen-reader announcements.

## Incomplete work and release gates

1. **Publish the source update.** GitHub write authority is still blocked. The live app remains on the previous deployed source until the correct archive is uploaded and Render finishes deploying it.
2. **Browser/device QA.** Check 320/390/768/1024/1440 widths, portrait/landscape, 200% zoom, keyboard-only navigation, modal focus/return, saved-item announcements, contrast and at least one mobile screen reader. The new responsive CSS is implemented, not certified by automated layout testing.
3. **Verified education dataset.** Exact international degrees, institution prerequisites, tuition, living costs, study duration and admission equivalence remain incomplete. Budget guidance does not filter countries by verified cost. Approximate grades are used only in the existing Ontario checker, not a global eligibility engine.
4. **Scholarship coverage.** Five named award research routes and country funding links are retained. Exact live deadlines/amounts are not invented. Existing award summaries retain their October 12, 2026 review date; the complete set was not freshly reverified in V31. Build a review process for each application cycle.
5. **Local career validation.** Most wage data are Ontario occupation-group benchmarks. Some legacy education/work-environment copy remains industry-wide rather than employer/role-specific. New US overviews deliberately have no local numerical pay/outlook. More role-specific review, progression and costs are still needed.
6. **Professional evidence.** Day schedules are illustrative. Verified interviews, worker-reviewed diaries and videos remain to be collected/licensed; generic reward and misconception prompts are editorial, not survey findings.
7. **Durable production storage.** The inspected Render service uses the free plan and had no attached disk. An external durable `DATABASE_URL` was not verified. Confirm the database configuration and off-host backups before promising durable account saves. Do not treat an included Blueprint as an applied hosting configuration. Render’s documentation explains ephemeral free-service files: https://render.com/docs/free . No paid upgrade was made.
8. **Privacy and operational review.** Confirm age-appropriate consent, jurisdictional obligations, contact details, retention policy, SMTP delivery and recovery, restore tests, monitoring and security review before a broad public launch. This release does not claim global legal compliance.

## Exact current deployment workflow

The existing GitHub repository is https://github.com/ezanam2000-blip/Pathway- and the running Render service is `pathway-v8`. The live service’s build command extracts a specifically named root archive:

```text
python -m zipfile -e "Pathway-V8 (1).zip" . && pip install -r pathway-fullstack/requirements.txt
```

Its start command is:

```text
cd pathway-fullstack && uvicorn app:app --host 0.0.0.0 --port $PORT
```

To use this release with the unchanged configuration:

1. Download the V31 source archive and rename that downloaded ZIP to exactly `Pathway-V8 (1).zip` (spaces and parentheses included). The ZIP itself contains the `pathway-fullstack/` directory. Do not upload an extra enclosing folder or a ZIP of a ZIP.
2. Replace the existing root file with that exact name on the repository’s `main` branch. Keep the previous commit available for rollback. Do not replace unrelated files or the old v5/v6/v7 services.
3. Let the existing service’s configured deployment run. If automatic deployment is off, deploy the new commit manually. Do not trigger duplicate deploys when one is already running. Render deployment reference: https://render.com/docs/deploys .
4. Confirm `/api/health` reports version **6.2.0**, and that `/static/discovery.js?v=31` loads. A healthy old version is not proof this release was installed.
5. Perform the real-browser smoke test below before announcing the update.

No repository upload or live deployment has been performed by this release handoff.

## Post-deployment smoke test

Open a fresh guest browser. Browse Careers before taking the quiz and confirm there are 220 unique roles. Select two interests; go back and change one; skip another question; pause and refresh; continue from saved progress. Finish and check that three useful cards appear. Explore a profile, use the keyboard to close it and verify focus returns. Save two careers, compare them, save the comparison and refresh. Reopen Saved and confirm the same ideas remain. Check education routes, unknown comparison costs and source dates. Try a different country, degree level and exchange option; confirm no missing data is portrayed as eligibility or guaranteed funding. Use disposable QA accounts to check account isolation and logout; do not delete real user records during testing. Finally validate mobile layout and inspect server errors. Keep important application dates outside Pathway until durability has been confirmed.
