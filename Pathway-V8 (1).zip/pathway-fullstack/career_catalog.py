from __future__ import annotations

"""Expanded Pathway career catalog.

Career compensation references use the Government of Canada Job Bank Ontario wage
report.  The low/median/high figures are labour-market reference points for the
related NOC group, not promises, offers, or a literal junior-to-senior salary ladder.
Specialized titles sometimes map to a broader NOC group; those records say so in the
pay note.
"""

JOB_BANK_ON = "https://www.jobbank.gc.ca/wagereport/location/ON"
WAGE_UPDATED = "November 19, 2025"

# key -> (NOC, official occupational group, unit, low, median, high)
WAGES = {
    "finance_analyst": ("11101", "Financial and investment analysts", "hour", 28.21, 43.27, 72.36),
    "advisor": ("11102", "Financial advisors", "hour", 23.08, 36.06, 76.92),
    "securities": ("11103", "Securities agents, investment dealers and brokers", "hour", 22.00, 43.59, 84.61),
    "accountant": ("11100", "Financial auditors and accountants", "hour", 24.73, 40.87, 72.12),
    "financial_officer": ("11109", "Other financial officers", "hour", 23.00, 36.92, 66.46),
    "hr": ("11200", "Human resources professionals", "hour", 25.48, 39.90, 62.02),
    "consulting": ("11201", "Professional occupations in business management consulting", "hour", 27.97, 44.94, 74.36),
    "marketing": ("11202", "Professional occupations in advertising, marketing and public relations", "hour", 20.00, 37.02, 58.97),
    "procurement": ("12102", "Procurement and purchasing agents and officers", "hour", 25.00, 36.41, 58.46),
    "supply_chain": ("12013", "Supervisors, supply chain, tracking and scheduling co-ordination occupations", "hour", 19.08, 27.88, 46.63),
    "business_manager": ("10029", "Other business services managers", "hour", 31.25, 48.72, 84.51),
    "sales_manager": ("60010", "Corporate sales managers", "hour", 38.00, 60.10, 132.57),
    "market_research": ("41402", "Business development officers and market researchers and analysts", "hour", 30.00, 45.64, 71.79),
    "actuary": ("21210", "Mathematicians, statisticians and actuaries", "hour", 38.46, 51.28, 77.33),
    "data_science": ("21211", "Data scientists", "hour", 31.25, 47.69, 71.79),
    "cyber": ("21220", "Cybersecurity specialists", "hour", 30.00, 51.28, 72.12),
    "business_systems": ("21221", "Business systems specialists", "hour", 33.33, 45.13, 62.50),
    "info_systems": ("21222", "Information systems specialists", "hour", 28.59, 47.00, 72.60),
    "database": ("21223", "Database analysts and data administrators", "hour", 24.58, 40.87, 61.54),
    "software_eng": ("21231", "Software engineers and designers", "hour", 36.06, 56.73, 88.00),
    "software_dev": ("21232", "Software developers and programmers", "hour", 30.29, 48.08, 77.40),
    "web_dev": ("21234", "Web developers and programmers", "hour", 21.63, 40.00, 56.41),
    "architect": ("21200", "Architects", "hour", 28.21, 41.03, 80.97),
    "landscape_arch": ("21201", "Landscape architects", "hour", 29.82, 45.76, 74.25),
    "urban_planner": ("21202", "Urban and land use planners", "hour", 27.56, 47.38, 76.00),
    "actuary_math": ("21210", "Mathematicians, statisticians and actuaries", "hour", 38.46, 51.28, 77.33),
    "civil": ("21300", "Civil engineers", "hour", 30.50, 48.08, 72.12),
    "mechanical": ("21301", "Mechanical engineers", "hour", 30.45, 46.42, 72.49),
    "electrical": ("21310", "Electrical and electronics engineers", "hour", 33.65, 50.00, 82.42),
    "computer_eng": ("21311", "Computer engineers (except software engineers and designers)", "hour", 33.65, 52.88, 86.54),
    "chemical_eng": ("21320", "Chemical engineers", "hour", 28.85, 51.28, 72.12),
    "industrial_eng": ("21321", "Industrial and manufacturing engineers", "hour", 27.88, 45.67, 76.92),
    "materials_eng": ("21322", "Metallurgical and materials engineers", "hour", 35.78, 53.14, 79.86),
    "mining_eng": ("21330", "Mining engineers", "hour", 38.46, 57.69, 86.54),
    "geological_eng": ("21331", "Geological engineers", "hour", 25.45, 45.00, 52.88),
    "petroleum_eng": ("21332", "Petroleum engineers", "hour", 52.88, 67.30, 74.52),
    "aerospace_eng": ("21390", "Aerospace engineers", "hour", 31.25, 56.41, 100.00),
    "other_eng": ("21399", "Other professional engineers", "hour", 27.25, 51.14, 87.91),
    "physicist": ("21100", "Physicists and astronomers", "hour", 37.03, 60.08, 92.98),
    "chemist": ("21101", "Chemists", "hour", 27.09, 39.49, 66.67),
    "physical_science": ("21109", "Other professional occupations in physical sciences", "hour", 32.41, 45.99, 75.96),
    "biologist": ("21110", "Biologists and related scientists", "hour", 24.50, 40.00, 69.23),
    "health_manager": ("30010", "Managers in health care", "hour", 35.90, 56.00, 87.18),
    "specialist_physician": ("31100", "Specialists in clinical and laboratory medicine", "year", 110998, 295785, 599836),
    "surgeon": ("31101", "Specialists in surgery", "year", 118538, 403957, 749689),
    "family_physician": ("31102", "General practitioners and family physicians", "year", 84266, 233752, 451418),
    "veterinarian": ("31103", "Veterinarians", "hour", 29.81, 60.00, 86.54),
    "dentist": ("31110", "Dentists", "year", 37561, 104000, 210000),
    "optometrist": ("31111", "Optometrists", "year", 37561, 78000, 156000),
    "slp_audio": ("31112", "Audiologists and speech-language pathologists", "hour", 29.00, 46.70, 59.35),
    "pharmacist": ("31120", "Pharmacists", "hour", 37.00, 53.85, 65.00),
    "dietitian": ("31121", "Dietitians and nutritionists", "hour", 20.00, 42.00, 50.00),
    "psychologist": ("31200", "Psychologists", "hour", 34.62, 51.82, 70.71),
    "physiotherapist": ("31202", "Physiotherapists", "hour", 25.64, 46.00, 54.00),
    "ot": ("31203", "Occupational therapists", "hour", 33.33, 45.00, 55.90),
    "rn": ("31301", "Registered nurses and registered psychiatric nurses", "hour", 29.00, 42.00, 55.00),
    "np": ("31302", "Nurse practitioners", "hour", 40.00, 62.00, 75.00),
    "allied_health": ("31303", "Physician assistants, midwives and allied health professionals", "hour", 24.47, 43.93, 56.37),
    "dental_hygiene": ("32111", "Dental hygienists and dental therapists", "hour", 33.00, 44.00, 53.67),
    "med_lab": ("32120", "Medical laboratory technologists", "hour", 23.00, 42.00, 50.00),
    "lawyer": ("41101", "Lawyers and Quebec notaries", "hour", 32.05, 65.21, 112.98),
    "professor": ("41200", "University professors and lecturers", "hour", 33.65, 64.10, 101.44),
    "college_instructor": ("41210", "College and other vocational instructors", "hour", 24.00, 45.00, 110.00),
    "secondary_teacher": ("41220", "Secondary school teachers", "hour", 29.33, 48.08, 61.54),
    "elementary_teacher": ("41221", "Elementary school and kindergarten teachers", "hour", 27.50, 46.15, 58.79),
    "economist": ("41401", "Economists and economic policy researchers and analysts", "hour", 35.71, 51.28, 71.79),
    "science_policy": ("41400", "Natural and applied science policy researchers, consultants and program officers", "hour", 31.00, 43.59, 67.31),
    "social_policy": ("41403", "Social policy researchers, consultants and program officers", "hour", 26.92, 44.62, 64.10),
    "health_policy": ("41404", "Health policy researchers, consultants and program officers", "hour", 26.50, 44.62, 62.42),
    "education_policy": ("41405", "Education policy researchers, consultants and program officers", "hour", 27.42, 41.43, 57.69),
    "government_program": ("41407", "Program officers unique to government", "hour", 33.33, 46.15, 69.23),
    "librarian": ("51100", "Librarians", "hour", 27.00, 44.24, 68.21),
    "archivist": ("51102", "Archivists", "hour", 28.67, 42.62, 59.43),
    "writer": ("51111", "Authors and writers (except technical)", "hour", 25.82, 40.38, 53.00),
    "technical_writer": ("51112", "Technical writers", "hour", 27.00, 34.98, 59.63),
    "producer": ("51120", "Producers, directors, choreographers and related occupations", "hour", 18.27, 39.90, 56.65),
    "broadcast": ("52112", "Broadcast technicians", "hour", 26.59, 38.03, 51.76),
    "pilot": ("72600", "Air pilots, flight engineers and flying instructors", "hour", 28.85, 63.00, 126.92),
    "power_engineer": ("92100", "Power engineers and power systems operators", "hour", 33.37, 57.00, 87.00),
    "boilermaker": ("72103", "Boilermakers", "hour", 31.21, 48.21, 54.21),
    "ironworker": ("72105", "Ironworkers", "hour", 32.27, 44.34, 50.25),
    "electrician": ("72200", "Electricians (except industrial and power system)", "hour", 20.00, 34.00, 50.50),
    "powerline": ("72203", "Electrical power line and cable workers", "hour", 29.70, 45.00, 62.00),
    "plumber": ("72300", "Plumbers", "hour", 20.00, 32.50, 50.38),
    "construction_supervisor": ("72013", "Contractors and supervisors, carpentry trades", "hour", 24.00, 38.46, 56.73),
    "heavy_equipment_supervisor": ("72021", "Contractors and supervisors, heavy equipment operator crews", "hour", 27.00, 40.00, 55.00),
}


def _money(v: float, unit: str) -> str:
    if unit == "year":
        return f"${v:,.0f}"
    return f"${v:,.2f}".rstrip("0").rstrip(".")


def wage_text(key: str) -> tuple[str, str]:
    noc, group, unit, low, median, high = WAGES[key]
    suffix = "/yr" if unit == "year" else "/hr"
    pay = f"Ontario Job Bank: {_money(low, unit)}–{_money(high, unit)}{suffix}; median {_money(median, unit)}{suffix}"
    note = (
        f"Related Job Bank benchmark: {group} (NOC {noc}), Ontario. Wages updated {WAGE_UPDATED}. "
        "The low, median, and high figures are labour-market reference points, not a guaranteed entry-to-senior pay ladder. "
        "Specialized employers, licensing, bonuses, overtime, location, and experience can change total compensation."
    )
    return pay, note


INDUSTRY_DEFAULTS = {
    "Technology": {
        "tags": ["Technology", "Math", "Problem Solving", "Creativity"],
        "skills": ["Problem Solving", "Digital Literacy", "Communication", "Teamwork", "Continuous Learning"],
        "subjects": ["Computer science", "Advanced mathematics", "English / communication", "Physics can help for hardware-heavy roles"],
        "education": "A bachelor's degree in computer science, software engineering, computer engineering, mathematics, statistics, or a related field is common. Strong projects, internships, co-op, and demonstrable technical skills can matter as much as the exact degree title.",
        "environment": "Computer-focused, team-based work. Many roles mix independent problem solving with meetings, code or design reviews, planning, and collaboration across product or business teams.",
        "steps": ["Build strong math and computing fundamentals", "Complete a relevant degree or equivalent technical training", "Build 2–4 projects that show real problem solving", "Use co-op, internships, research, hackathons, or open-source work to gain experience", "Prepare for technical and behavioural interviews", "Specialize gradually after learning the fundamentals"],
        "tips": ["Do not rely only on certificates; build things you can explain", "Learn version control and how teams ship software", "Practice explaining technical decisions clearly", "Use internships or co-op to test specialties before committing", "Keep a portfolio of projects, results, and lessons learned"],
        "levels": ["Entry / Junior — scoped work with feedback", "Intermediate — owns larger features or systems", "Senior — handles complex work and mentors others", "Staff / Lead — influences architecture or standards across teams", "Manager / Principal / Director — leads major technical or organizational direction"],
    },
    "Engineering": {
        "tags": ["Engineering", "Math", "Science", "Problem Solving"],
        "skills": ["Math", "Technical Analysis", "Problem Solving", "Design", "Communication", "Teamwork"],
        "subjects": ["Advanced mathematics", "Physics", "Chemistry for some disciplines", "Computer science / technology", "English / technical communication"],
        "education": "A bachelor's degree in the relevant engineering discipline is the standard route. In regulated engineering work, graduates commonly progress through engineer-in-training experience toward professional licensure requirements in their province.",
        "environment": "A mix of office, lab, design, plant, site, or field work depending on the discipline. Projects are collaborative and usually involve safety, cost, schedule, technical standards, and documentation.",
        "steps": ["Take strong math and science courses in high school", "Complete an accredited or relevant engineering degree", "Pursue co-op, design teams, labs, or internships", "Build practical CAD, coding, simulation, testing, or field skills as relevant", "Learn professional standards and documentation", "Work toward licensure where the role requires it"],
        "tips": ["Prioritize math and physics fundamentals", "Join a design team, robotics group, maker project, or technical competition if it fits your interests", "Learn to document decisions and explain trade-offs", "Use co-op to test different industries", "Treat safety and professional ethics as core skills, not paperwork"],
        "levels": ["Engineering Intern / EIT — supervised technical work", "Engineer — owns defined analyses, designs, or project work", "Senior Engineer — leads complex technical decisions", "Lead / Principal Engineer — sets standards and reviews critical work", "Engineering Manager / Director — leads teams, budgets, delivery, and technical strategy"],
    },
    "Healthcare": {
        "tags": ["Healthcare", "Medicine & Health", "Science", "Working with People", "Communication"],
        "skills": ["Communication", "Clinical Reasoning", "Attention to Detail", "Teamwork", "Empathy", "Decision Making"],
        "subjects": ["Biology", "Chemistry", "Mathematics", "English / communication", "Physics for some programs"],
        "education": "Education varies by profession. Many healthcare careers require a specific accredited university program, supervised placements, licensing or registration, and continuing professional education. Check the regulator and university requirements for the exact profession.",
        "environment": "Patient, client, laboratory, clinic, hospital, community, or health-system settings. Work can be emotionally demanding and often requires careful documentation, teamwork, confidentiality, and professional standards.",
        "steps": ["Build strong science and communication foundations", "Research the exact accredited program and prerequisites early", "Use volunteering or job shadowing for realistic career exposure where appropriate", "Complete required university or professional education", "Finish clinical placements, exams, and licensing requirements", "Develop a specialty after gaining broad foundational experience"],
        "tips": ["Do not choose healthcare only for status or salary; understand the daily work", "Strengthen biology, chemistry, and communication", "Check licensing requirements before choosing a program", "Seek ethical, age-appropriate exposure to healthcare settings", "Build resilience, teamwork, and documentation habits"],
        "levels": ["Student / Trainee — academic and supervised practical training", "Entry Practitioner — builds judgement under professional standards", "Experienced Practitioner — handles greater complexity or specialization", "Advanced / Specialist — deeper expertise, certification, or graduate training", "Clinical / Professional Leader — leadership, education, research, administration, or independent practice where permitted"],
    },
    "Business & Operations": {
        "tags": ["Business & Operations", "Business & Finance", "Communication", "Problem Solving", "Leadership"],
        "skills": ["Analysis", "Communication", "Excel / Data", "Organization", "Business Judgement", "Teamwork"],
        "subjects": ["Mathematics", "Economics or business", "English / writing", "Data management / statistics", "Computer skills"],
        "education": "Common routes include commerce, business, economics, accounting, mathematics, statistics, supply chain, or another analytical degree. Co-op, internships, case competitions, and applied projects can make the path much clearer.",
        "environment": "Office, client, hybrid, operational, or project-based settings. Work usually combines analysis with meetings, presentations, coordination, and decisions that affect customers, costs, people, or processes.",
        "steps": ["Build strong communication, math, and spreadsheet skills", "Choose a degree that gives you analytical and practical options", "Join projects, clubs, competitions, or part-time work that create measurable responsibility", "Pursue internships or co-op in more than one function", "Learn the tools used in your target role", "Build a track record of results and progress into larger ownership"],
        "tips": ["Learn Excel and basic data analysis", "Practice clear writing and presentations", "Look for internships that expose you to real decisions and deliverables", "Track measurable outcomes from projects and work", "Explore several business functions before specializing"],
        "levels": ["Analyst / Coordinator — research, analysis, execution support", "Senior Analyst / Specialist — owns workstreams and recommendations", "Manager — leads projects, processes, or a small team", "Senior Manager / Director — owns a major function or portfolio", "VP / Executive — sets strategy, allocates resources, and leads large organizations"],
    },
    "Science & Environment": {
        "tags": ["Science & Environment", "Science", "Research", "Math", "Environment"],
        "skills": ["Research", "Data Analysis", "Scientific Reasoning", "Writing", "Problem Solving", "Attention to Detail"],
        "subjects": ["Biology and/or chemistry", "Advanced mathematics", "Physics depending on field", "Computer science / data", "English / research writing"],
        "education": "A bachelor's degree in a relevant science is common for entry roles. Research-intensive careers often value a master's degree or PhD, while applied roles may emphasize laboratory, field, GIS, statistics, programming, or regulatory experience.",
        "environment": "Laboratories, offices, universities, government, consulting firms, field sites, or research organizations. Work often combines data, documentation, technical tools, and long-term projects.",
        "steps": ["Build strong science and math fundamentals", "Complete a relevant science degree", "Learn statistics, research methods, and data tools", "Pursue lab, field, research assistant, co-op, or internship experience", "Decide whether graduate school is necessary for your target role", "Build a specialty through projects, publications, certifications, or applied work"],
        "tips": ["Learn statistics earlier than you think you need it", "Get hands-on research or field experience", "Develop coding or data skills where useful", "Read actual job postings before choosing graduate school", "Practice technical writing and presenting results"],
        "levels": ["Research Assistant / Junior Scientist — supports studies and analysis", "Scientist / Analyst — owns defined projects", "Senior Scientist — leads complex studies or technical decisions", "Principal / Research Lead — sets methods and directs major programs", "Manager / Director / Professor — leads teams, portfolios, research, or policy"],
    },
    "Law & Public Policy": {
        "tags": ["Law & Public Policy", "Law", "Government & Politics", "Writing", "Communication", "Research"],
        "skills": ["Writing", "Research", "Critical Thinking", "Communication", "Negotiation", "Policy Analysis"],
        "subjects": ["English / writing", "History", "Law or social sciences", "Economics", "Mathematics / statistics for policy analysis"],
        "education": "Routes vary. Lawyers require an undergraduate degree or equivalent route followed by law school and licensing. Policy, government, economics, and compliance roles commonly recruit from economics, public policy, political science, law, business, statistics, and other analytical degrees.",
        "environment": "Government, law firms, courts, corporations, regulators, non-profits, think tanks, universities, or consulting organizations. Strong writing, evidence, judgement, and stakeholder communication are central.",
        "steps": ["Build strong writing, research, and argument skills", "Study a field that keeps your options open and develop quantitative skills where possible", "Use internships, student government, debate, policy projects, clinics, or research for exposure", "Complete professional school or graduate training if the target role requires it", "Learn how decisions are documented and defended", "Build credibility through progressively more complex files and responsibilities"],
        "tips": ["Write often and ask for feedback", "Learn to separate evidence from opinion", "Build comfort with data as well as essays", "Seek roles where you can research, brief, present, or negotiate", "Understand licensing before committing to law or another regulated profession"],
        "levels": ["Analyst / Articling / Entry Professional — research and file support", "Professional / Counsel / Advisor — owns files and recommendations", "Senior Advisor / Senior Counsel — handles complex matters", "Manager / Partner / Director — leads teams, major files, or clients", "Executive / Senior Public Leader — shapes policy, strategy, or institutional direction"],
    },
    "Education & Research": {
        "tags": ["Education & Research", "Education", "Research", "Communication", "Working with People"],
        "skills": ["Communication", "Teaching", "Research", "Organization", "Writing", "Mentoring"],
        "subjects": ["Strong knowledge in the subject you want to teach or research", "English / communication", "Research and statistics where relevant"],
        "education": "Most teaching and academic careers require a university degree. K–12 teaching requires teacher education and provincial certification; university research careers often require graduate study, while college instruction requirements vary by field.",
        "environment": "Schools, colleges, universities, libraries, research centres, education companies, or government. Work combines preparation, communication, assessment, research, administration, and student or stakeholder support.",
        "steps": ["Build deep knowledge in a subject you genuinely enjoy", "Complete the required degree and professional training", "Tutor, mentor, coach, or support learning to test your interest", "Build teaching, research, or curriculum experience", "Meet certification requirements where applicable", "Move into specialization, leadership, research, or administration over time"],
        "tips": ["Try tutoring or mentoring before committing", "Learn to explain the same idea in several ways", "Develop patience and organization", "For academic careers, understand the realities of graduate school and research funding", "Use feedback to improve your teaching or research practice"],
        "levels": ["Trainee / Assistant — supervised teaching or research", "Teacher / Instructor / Researcher — owns classes or projects", "Senior / Lead — mentors peers and handles more complex work", "Department / Program Lead — coordinates curriculum or research", "Administrator / Principal / Dean / Director — institutional leadership"],
    },
    "Design & Media": {
        "tags": ["Design & Media", "Arts & Design", "Media", "Creativity", "Communication", "Technology"],
        "skills": ["Creativity", "Communication", "Research", "Design", "Storytelling", "Digital Tools"],
        "subjects": ["English / writing", "Visual arts or media", "Computer science / design technology", "Business can help for client work"],
        "education": "Design, communications, media, journalism, writing, human-computer interaction, or related university programs are common. A strong portfolio of real work is especially important in creative fields.",
        "environment": "Studios, agencies, technology companies, media organizations, in-house teams, production sets, or freelance work. Deadlines, feedback, revision, and collaboration are normal parts of the job.",
        "steps": ["Build a portfolio instead of collecting only course certificates", "Study design, writing, media, technology, or a related field", "Complete internships, student media, freelance, or community projects", "Learn professional tools and how to take feedback", "Show process and outcomes, not only polished final work", "Specialize after trying several types of projects"],
        "tips": ["Keep your best work in a simple portfolio", "Show the problem, your process, and the result", "Learn to accept and use critique", "Understand basic business and client communication", "Build technical skills that complement your creative strengths"],
        "levels": ["Junior / Assistant — executes scoped work and builds portfolio", "Designer / Writer / Producer — owns complete deliverables", "Senior — leads complex projects and mentors others", "Lead / Creative Director — sets quality and direction", "Head / Director / Executive Producer — leads teams, budgets, and strategy"],
    },
    "Architecture & Construction": {
        "tags": ["Architecture & Construction", "Architecture", "Engineering", "Design", "Project Management"],
        "skills": ["Design", "Project Management", "Technical Drawing", "Communication", "Problem Solving", "Cost / Schedule Awareness"],
        "subjects": ["Mathematics", "Physics", "Visual arts / design", "Technology / drafting", "English / communication"],
        "education": "Architecture and planning roles often require a university degree and, for regulated practice, additional supervised experience and licensing. Construction management and estimating can be entered through university, college, or trade-to-management pathways.",
        "environment": "Offices, design studios, construction sites, client meetings, municipal settings, or consulting firms. Work balances design, codes, cost, schedule, safety, contracts, and stakeholder needs.",
        "steps": ["Build math, design, and communication fundamentals", "Study architecture, planning, engineering, construction management, or a related field", "Use co-op, site experience, studios, or internships to understand real projects", "Learn drawings, codes, schedules, costs, and contracts", "Meet licensing requirements where applicable", "Progress toward larger projects and leadership"],
        "tips": ["Learn how buildings and projects are actually delivered, not just designed", "Get site exposure if possible", "Build software skills such as CAD/BIM where relevant", "Practice presenting ideas to non-technical people", "Understand codes, safety, budgets, and schedules"],
        "levels": ["Intern / Coordinator — supports drawings, schedules, or site work", "Professional / Project Specialist — owns defined packages or workstreams", "Senior — leads larger projects or technical scopes", "Project Lead / Associate — manages teams, clients, and delivery", "Principal / Director — leads major projects, business, or organizational strategy"],
    },
    "Aviation & Skilled Technical": {
        "tags": ["Aviation & Skilled Technical", "Skilled Trades", "Technology", "Hands-on Work", "Problem Solving"],
        "skills": ["Technical Skill", "Safety", "Problem Solving", "Attention to Detail", "Teamwork", "Reliability"],
        "subjects": ["Mathematics", "Physics", "Technology / shop courses", "English / technical communication"],
        "education": "These careers do not always require a university degree. Many use apprenticeships, college programs, technical certification, flight training, licensing, or employer-based training. They can be strong alternatives for students who prefer applied work.",
        "environment": "Airports, plants, construction sites, utilities, shops, field locations, or industrial facilities. Safety procedures, practical competence, reliability, and licensing are central.",
        "steps": ["Research the exact apprenticeship, college, licensing, or flight-training route", "Build math, physics, and hands-on problem-solving skills", "Get supervised practical experience", "Complete required hours, exams, and certifications", "Develop a specialty and strong safety record", "Progress into supervisory, inspection, training, or management roles if desired"],
        "tips": ["Compare training cost, time, and licensing before enrolling", "Prioritize safety and quality over speed", "Ask employers what credentials they actually value", "Build a reputation for reliability and careful work", "Consider union, utility, industrial, and specialty pathways when comparing compensation"],
        "levels": ["Trainee / Apprentice — supervised learning and required hours", "Licensed / Qualified Worker — independent work within scope", "Senior / Specialist — advanced systems or complex jobs", "Lead / Supervisor — coordinates crews and quality", "Inspector / Manager / Instructor — oversight, compliance, training, or operations leadership"],
    },
}


def role(title: str, industry: str, wage: str, focus: str, tasks: str, *, tags=None, education=None, route="University", status="verified") -> dict:
    d = INDUSTRY_DEFAULTS[industry]
    pay, pay_note = wage_text(wage)
    slug = "".join(ch.lower() if ch.isalnum() else "-" for ch in title).strip("-")
    while "--" in slug:
        slug = slug.replace("--", "-")
    all_tags = list(dict.fromkeys([industry, route, *(d["tags"]), *(tags or [])]))
    return {
        "id": f"career-{slug}",
        "title": title,
        "subtitle": industry,
        "industry": industry,
        "description": focus,
        "tags": all_tags,
        "education": education or d["education"],
        "day_to_day": tasks,
        "pay_range": pay,
        "pay_note": pay_note,
        "levels": d["levels"],
        "skills": d["skills"],
        "school_subjects": d["subjects"],
        "success_tips": d["tips"],
        "pathway_steps": d["steps"],
        "work_environment": d["environment"],
        "outlook": "Demand varies by region and economic cycle. Use the linked Job Bank wage report and occupation profiles to compare current wages, requirements, and outlooks before making a decision.",
        "source": JOB_BANK_ON,
        "status": status,
    }


ROLES = [
    # Technology — intentionally broad, not finance-heavy.
    ("Backend Software Engineer", "Technology", "software_eng", "Build the server-side systems, APIs, databases, and services that power digital products.", "Design APIs, write and review code, improve performance, debug production issues, work with databases, and coordinate with frontend, product, security, and infrastructure teams."),
    ("Frontend Software Engineer", "Technology", "software_dev", "Build the interfaces people use in web applications and digital products.", "Turn designs into accessible interfaces, manage application state, connect to APIs, test behaviour across devices, improve performance, and work closely with designers and backend engineers."),
    ("Mobile App Developer", "Technology", "software_dev", "Build applications for phones and tablets using native or cross-platform technologies.", "Develop features, integrate device capabilities and APIs, test on different devices, monitor crashes, publish updates, and collaborate with product and design teams."),
    ("Cloud Engineer", "Technology", "info_systems", "Design and operate cloud infrastructure used to run applications reliably at scale.", "Configure cloud services, automate deployments, manage access and networking, monitor systems, control costs, and help development teams ship safely."),
    ("DevOps Engineer", "Technology", "info_systems", "Improve the systems and automation that move software from development into production.", "Build CI/CD pipelines, automate infrastructure, monitor deployments, investigate incidents, improve developer workflows, and strengthen reliability."),
    ("Site Reliability Engineer", "Technology", "software_eng", "Apply software engineering to reliability, performance, monitoring, and large-scale operations.", "Build automation, define reliability targets, respond to incidents, tune systems, remove repetitive operational work, and partner with product engineering teams."),
    ("Data Scientist", "Technology", "data_science", "Use statistics, programming, and domain knowledge to find patterns and support decisions from data.", "Clean and explore data, build models, test hypotheses, communicate findings, create experiments, and work with engineers or business teams to put insights into use."),
    ("Machine Learning Engineer", "Technology", "software_eng", "Build production systems that train, serve, and monitor machine-learning models.", "Prepare data pipelines, train models, write production code, evaluate model behaviour, deploy services, monitor quality, and collaborate with data scientists and product teams."),
    ("AI Research Scientist", "Technology", "data_science", "Research new machine-learning methods and evaluate how well they work on difficult problems.", "Read research, design experiments, train models, analyze results, write papers or technical reports, and collaborate with engineers who turn research into systems."),
    ("Cybersecurity Analyst", "Technology", "cyber", "Protect systems and data by monitoring threats, investigating suspicious activity, and improving security controls.", "Review alerts, investigate incidents, assess vulnerabilities, document risks, improve controls, and communicate with technical and business teams."),
    ("Security Engineer", "Technology", "cyber", "Design security into applications, cloud systems, networks, and development processes.", "Review architectures, automate security checks, test controls, improve identity and access systems, help respond to incidents, and advise engineering teams."),
    ("Penetration Tester", "Technology", "cyber", "Assess authorized systems for security weaknesses and report how to fix them.", "Plan scoped tests, examine configurations and applications, document findings, reproduce weaknesses safely, and explain remediation to system owners."),
    ("Database Engineer", "Technology", "database", "Design and maintain reliable database systems that store important application and business data.", "Model data, tune queries, automate backups, monitor performance, plan migrations, control access, and help teams use databases safely."),
    ("Business Systems Analyst", "Technology", "business_systems", "Translate business problems into system requirements and process improvements.", "Interview users, map processes, write requirements, compare solutions, test changes, coordinate implementation, and explain trade-offs to technical and non-technical teams."),
    ("Solutions Architect", "Technology", "info_systems", "Design technology solutions that connect software, infrastructure, security, and business requirements.", "Meet with stakeholders, document architectures, compare platforms, create technical plans, review integrations, and guide implementation teams."),
    ("Product Manager", "Technology", "business_manager", "Decide what a product team should build, why it matters, and how to measure whether it worked.", "Talk to users, analyze product data, prioritize problems, write product requirements, coordinate design and engineering, launch features, and review outcomes.", {"tags":["Product", "Entrepreneurship"]}),
    ("Technical Product Manager", "Technology", "business_manager", "Lead products that require deeper technical understanding, such as developer tools, infrastructure, APIs, or data platforms.", "Define product strategy, work through technical trade-offs, interview technical users, prioritize roadmaps, and align engineering, design, sales, and support."),
    ("IT Consultant", "Technology", "info_systems", "Help organizations choose, implement, and improve technology systems.", "Assess current systems, interview stakeholders, recommend solutions, plan migrations, coordinate vendors, and document changes and risks."),

    # Engineering
    ("Civil Engineer", "Engineering", "civil", "Design and improve infrastructure such as roads, bridges, water systems, buildings, and public works.", "Perform calculations, prepare designs, review drawings, coordinate with contractors and municipalities, visit sites, and check that work meets codes and specifications."),
    ("Structural Engineer", "Engineering", "civil", "Design structures that safely carry loads in buildings, bridges, and other infrastructure.", "Model structural loads, size components, review drawings, coordinate with architects, inspect conditions, and document calculations and design changes."),
    ("Transportation Engineer", "Engineering", "civil", "Plan and design safer, more efficient transportation systems.", "Analyze traffic and travel data, design road or transit improvements, model demand, review safety, coordinate with planners, and prepare technical reports."),
    ("Mechanical Engineer", "Engineering", "mechanical", "Design and improve machines, products, thermal systems, and mechanical equipment.", "Create calculations and CAD models, select materials, test prototypes, investigate failures, work with manufacturing, and improve performance, cost, and reliability."),
    ("Mechatronics Engineer", "Engineering", "mechanical", "Combine mechanical systems, electronics, controls, and software in automated products and machines.", "Design mechanisms, integrate sensors and actuators, program controllers, test prototypes, troubleshoot systems, and coordinate across mechanical and electrical teams."),
    ("Robotics Engineer", "Engineering", "mechanical", "Build robotic systems that sense, move, and perform tasks in manufacturing, logistics, healthcare, or research.", "Design mechanisms, integrate sensors, program motion and controls, test safety, analyze failures, and improve reliability and precision."),
    ("Electrical Engineer", "Engineering", "electrical", "Design electrical systems for power, electronics, buildings, transportation, industry, or communications.", "Create schematics and calculations, select components, simulate systems, test prototypes, review safety and codes, and support installation or manufacturing."),
    ("Electronics Engineer", "Engineering", "electrical", "Design electronic circuits, devices, sensors, and control systems.", "Develop schematics, select components, simulate circuits, build prototypes, use lab equipment, debug hardware, and work with firmware or manufacturing teams."),
    ("Computer Hardware Engineer", "Engineering", "computer_eng", "Design computer hardware, embedded systems, processors, boards, and connected devices.", "Develop architectures and circuit designs, prototype boards, test hardware, debug interfaces, validate performance, and coordinate with firmware and software engineers."),
    ("Embedded Systems Engineer", "Engineering", "computer_eng", "Build software and electronics that run inside devices such as vehicles, medical equipment, industrial machines, and consumer products.", "Write low-level code, connect sensors and hardware, test timing and reliability, debug interfaces, and work closely with electrical and mechanical engineers."),
    ("Chemical Engineer", "Engineering", "chemical_eng", "Design and improve processes that transform materials at industrial scale.", "Model processes, analyze heat and mass transfer, optimize production, improve safety, investigate quality issues, and work with operations, labs, and equipment teams."),
    ("Process Engineer", "Engineering", "chemical_eng", "Improve industrial processes for safety, quality, efficiency, and cost.", "Review process data, identify bottlenecks, run trials, update procedures, investigate failures, and coordinate changes with operations and maintenance."),
    ("Industrial Engineer", "Engineering", "industrial_eng", "Improve systems involving people, equipment, information, quality, and workflow.", "Map processes, analyze capacity and data, design layouts, reduce waste, improve quality, and work with operations teams to implement changes."),
    ("Manufacturing Engineer", "Engineering", "industrial_eng", "Design and improve how products are manufactured at scale.", "Develop production processes, select equipment, solve quality problems, improve cycle time, support launches, and coordinate with design, suppliers, and operators."),
    ("Materials Engineer", "Engineering", "materials_eng", "Study and select metals, polymers, ceramics, composites, and other materials for demanding applications.", "Test materials, analyze failures, choose treatments or coatings, support product design, improve manufacturing processes, and document performance."),
    ("Mining Engineer", "Engineering", "mining_eng", "Plan safe and economical ways to extract mineral resources.", "Design mine plans, model production, review ventilation and ground conditions, coordinate equipment and safety, analyze costs, and work with geology and operations teams."),
    ("Geological Engineer", "Engineering", "geological_eng", "Apply geology and engineering to foundations, slopes, groundwater, mining, and infrastructure.", "Interpret site data, evaluate soil and rock conditions, design mitigation, review field investigations, and prepare technical recommendations."),
    ("Petroleum Engineer", "Engineering", "petroleum_eng", "Plan and optimize the extraction and production of oil and gas resources.", "Analyze reservoirs and wells, model production, design completion or recovery strategies, review economics, and coordinate with geoscience and field operations."),
    ("Aerospace Engineer", "Engineering", "aerospace_eng", "Design and test aircraft, spacecraft, propulsion, structures, controls, or aerospace systems.", "Run simulations, create designs, analyze loads and performance, plan tests, investigate failures, and coordinate with manufacturing, software, and certification teams."),
    ("Biomedical Engineer", "Engineering", "other_eng", "Apply engineering to medical devices, diagnostics, rehabilitation technology, and healthcare systems.", "Develop prototypes, test devices, analyze safety and performance, document design controls, work with clinicians, and support regulatory or manufacturing processes."),
    ("Environmental Engineer", "Engineering", "other_eng", "Design technical solutions for water, waste, pollution control, remediation, and environmental compliance.", "Model systems, review sampling data, design treatment or remediation, prepare permits and reports, and coordinate with scientists, regulators, and project teams."),
    ("Nuclear Engineer", "Engineering", "other_eng", "Work on nuclear power, radiation systems, reactor safety, fuel, or related engineering projects.", "Analyze systems, review safety cases, model performance, prepare technical documentation, support inspections, and work within strict regulatory requirements."),
    ("Quality Engineer", "Engineering", "industrial_eng", "Build systems that prevent defects and improve product or process quality.", "Analyze failure data, design controls, run root-cause investigations, support audits, improve inspection methods, and work with suppliers and production teams."),

    # Healthcare
    ("Family Physician", "Healthcare", "family_physician", "Diagnose and manage a wide range of health problems across ages and coordinate ongoing patient care.", "See patients, take histories, examine symptoms, order and interpret tests, prescribe treatment, manage chronic conditions, document care, and refer to specialists when needed.", {"education":"A university degree is followed by medical school, residency training in family medicine, licensing exams, and provincial registration. The path is long and highly regulated."}),
    ("Medical Specialist", "Healthcare", "specialist_physician", "Diagnose and treat complex conditions within a focused medical specialty such as cardiology, radiology, psychiatry, pathology, or internal medicine.", "Assess patients or diagnostic information, interpret tests, make treatment decisions, collaborate with other clinicians, document care, and continue specialty-specific learning.", {"education":"A university degree is followed by medical school, residency and often fellowship training, licensing exams, and provincial registration. Specialty length and requirements vary."}),
    ("Surgeon", "Healthcare", "surgeon", "Treat disease or injury through operative and procedural care within a surgical specialty.", "Assess patients, plan procedures, operate with a clinical team, manage perioperative risks, follow patients after surgery, and maintain detailed records and continuing certification.", {"education":"A university degree is followed by medical school, surgical residency, possible fellowship training, licensing exams, and provincial registration."}),
    ("Pharmacist", "Healthcare", "pharmacist", "Help patients use medications safely and effectively in community, hospital, industry, or clinical settings.", "Review prescriptions, check interactions, counsel patients, manage medication records, collaborate with prescribers, and support immunization or clinical services where authorized."),
    ("Dentist", "Healthcare", "dentist", "Diagnose and treat conditions affecting teeth, gums, and oral health.", "Examine patients, interpret imaging, plan treatment, perform procedures, educate patients, manage infection control, and coordinate with hygienists, assistants, and specialists."),
    ("Optometrist", "Healthcare", "optometrist", "Assess vision and eye health, prescribe corrective lenses, and identify conditions that need treatment or referral.", "Perform eye examinations, interpret findings, prescribe lenses, manage certain eye conditions within scope, counsel patients, and refer complex cases."),
    ("Veterinarian", "Healthcare", "veterinarian", "Diagnose, treat, and prevent illness and injury in animals.", "Examine animals, order tests, perform procedures, prescribe medication, communicate with owners, maintain records, and manage preventive care or emergencies."),
    ("Psychologist", "Healthcare", "psychologist", "Assess behaviour and mental health and provide evidence-based psychological services in clinical, school, organizational, or research settings.", "Conduct assessments, provide therapy or consultation, interpret test results, write reports, plan treatment, and collaborate with clients or care teams."),
    ("Physiotherapist", "Healthcare", "physiotherapist", "Help people improve movement, function, and recovery after injury, illness, surgery, or chronic conditions.", "Assess movement, set rehabilitation goals, prescribe exercises, provide treatment, track progress, educate patients, and coordinate with other healthcare professionals."),
    ("Occupational Therapist", "Healthcare", "ot", "Help people participate in daily activities after injury, illness, disability, or changes in function.", "Assess daily tasks and environments, design therapy plans, recommend equipment or adaptations, coach clients and families, and document progress."),
    ("Speech-Language Pathologist", "Healthcare", "slp_audio", "Assess and treat communication and swallowing difficulties across children and adults.", "Evaluate speech, language, voice, or swallowing, create treatment plans, provide therapy, educate families, and collaborate with schools or healthcare teams."),
    ("Audiologist", "Healthcare", "slp_audio", "Assess hearing and balance and help people manage hearing loss or related disorders.", "Run hearing tests, interpret results, fit or recommend hearing technology, counsel clients, document care, and coordinate medical referrals when needed."),
    ("Registered Nurse", "Healthcare", "rn", "Provide and coordinate patient care across hospitals, clinics, community care, public health, and other settings.", "Assess patients, give treatments and medications, monitor changes, educate patients and families, document care, and coordinate with the healthcare team."),
    ("Nurse Practitioner", "Healthcare", "np", "Provide advanced nursing care with authority to assess, diagnose, order tests, and prescribe within provincial scope.", "See patients, diagnose common and complex conditions, order tests, prescribe treatment, manage chronic disease, and collaborate with physicians and other professionals."),
    ("Physician Assistant", "Healthcare", "allied_health", "Provide medical care under a physician-supervised or collaborative model, depending on jurisdiction and setting.", "Take histories, examine patients, order or interpret tests within scope, assist with procedures, develop care plans, and document clinical decisions."),
    ("Midwife", "Healthcare", "allied_health", "Provide pregnancy, birth, and postpartum care within a regulated midwifery scope.", "Conduct prenatal visits, monitor labour, attend births, provide postpartum care, educate families, and coordinate transfer or consultation when risk changes."),
    ("Dietitian", "Healthcare", "dietitian", "Use nutrition science to assess needs and create evidence-based nutrition plans in clinical, community, public health, or industry settings.", "Assess diet and health information, create nutrition interventions, educate clients, monitor progress, contribute to programs, and document care."),
    ("Medical Laboratory Technologist", "Healthcare", "med_lab", "Perform laboratory testing that supports diagnosis, treatment, and disease monitoring.", "Prepare specimens, run analyzers and tests, verify quality control, investigate unusual results, maintain equipment, and follow strict safety procedures."),
    ("Dental Hygienist", "Healthcare", "dental_hygiene", "Provide preventive oral care and patient education within a regulated dental hygiene scope.", "Assess oral health, perform preventive procedures, take records or imaging within scope, educate patients, and coordinate with dentists."),
    ("Healthcare Administrator", "Healthcare", "health_manager", "Lead healthcare services, teams, budgets, quality initiatives, or operations.", "Plan staffing and services, monitor budgets and performance, improve patient flow and quality, manage teams, respond to incidents, and work with clinicians and executives."),
    ("Health Policy Analyst", "Healthcare", "health_policy", "Research health-system issues and turn evidence into policy or program recommendations.", "Analyze data and research, consult stakeholders, prepare briefing notes, evaluate programs, compare policy options, and present recommendations."),

    # Business, finance, supply chain, and operations
    ("Actuary", "Business & Operations", "actuary", "Use mathematics, statistics, probability, and risk models to estimate uncertain future financial outcomes.", "Analyze insurance or pension data, build models, test assumptions, price risk, prepare reports, and explain technical results to business leaders and regulators.", {"tags":["Math", "Insurance", "Risk"]}),
    ("Statistician", "Science & Environment", "actuary_math", "Design studies and use statistical methods to understand data, uncertainty, and evidence.", "Plan analyses, clean data, build statistical models, test assumptions, interpret results, document methods, and explain findings to researchers or decision makers.", {"tags":["Math", "Data"]}),
    ("Accountant", "Business & Operations", "accountant", "Prepare, interpret, and improve financial information used by organizations and stakeholders.", "Prepare statements, reconcile accounts, analyze costs, support budgets, improve controls, answer audit questions, and explain financial results."),
    ("External Auditor", "Business & Operations", "accountant", "Independently examine financial reporting and controls to assess whether information is fairly presented.", "Test transactions and controls, review evidence, document audit work, discuss findings with clients, and prepare conclusions under professional standards."),
    ("Financial Analyst", "Business & Operations", "finance_analyst", "Analyze financial performance, investments, budgets, forecasts, or business decisions.", "Build models, review financial statements, compare scenarios, prepare forecasts, research companies or markets, and present recommendations."),
    ("Investment Analyst", "Business & Operations", "finance_analyst", "Research companies, securities, markets, or investment opportunities and support portfolio decisions.", "Read filings, build valuation models, track industry news, speak with management or experts, write investment notes, and monitor portfolio risks."),
    ("Risk Analyst", "Business & Operations", "financial_officer", "Identify and measure financial, operational, credit, market, or enterprise risks.", "Analyze exposures, build risk reports, test scenarios, review controls, monitor limits, and communicate risks to managers and governance teams."),
    ("Financial Advisor", "Business & Operations", "advisor", "Help clients plan savings, investing, retirement, insurance, and other financial goals within licensing rules.", "Meet clients, gather financial information, explain options and risks, recommend plans, document advice, and maintain ongoing relationships."),
    ("Securities Trader / Broker", "Business & Operations", "securities", "Execute or support securities transactions and help clients or institutions access financial markets.", "Monitor markets, execute orders, communicate with clients or portfolio teams, manage risk limits, maintain records, and follow regulatory requirements."),
    ("Management Consultant", "Business & Operations", "consulting", "Help organizations solve strategy, operations, technology, organization, or performance problems.", "Interview stakeholders, analyze data, structure problems, build presentations, develop recommendations, and support implementation with client teams."),
    ("Strategy Analyst", "Business & Operations", "consulting", "Support major business decisions such as growth, market entry, pricing, investment, and organizational priorities.", "Research markets, model scenarios, analyze competitors, prepare executive materials, and coordinate strategic planning projects."),
    ("Business Analyst", "Business & Operations", "business_systems", "Analyze business processes and requirements so teams can improve systems, operations, or customer experiences.", "Map processes, gather requirements, analyze data, document needs, test solutions, and coordinate between business and technical teams."),
    ("Operations Analyst", "Business & Operations", "consulting", "Use data and process analysis to improve how an organization delivers products or services.", "Measure performance, identify bottlenecks, build dashboards, evaluate process changes, coordinate improvements, and track results."),
    ("Supply Chain Analyst", "Business & Operations", "procurement", "Analyze inventory, suppliers, logistics, demand, and costs so products and materials move efficiently.", "Track demand and inventory, analyze supplier performance, build forecasts, investigate delays, improve planning, and coordinate with procurement, logistics, and operations.", {"tags":["Supply Chain", "Logistics"]}),
    ("Supply Chain Manager", "Business & Operations", "business_manager", "Lead planning, sourcing, inventory, logistics, and supplier performance across a supply network.", "Set supply plans, manage teams and vendors, review service and cost metrics, respond to disruptions, and improve processes across purchasing, warehousing, and transportation.", {"tags":["Supply Chain", "Logistics", "Leadership"]}),
    ("Procurement Specialist", "Business & Operations", "procurement", "Source goods and services, evaluate suppliers, and negotiate purchases for an organization.", "Develop requirements, request bids, compare proposals, negotiate terms, manage supplier relationships, track contracts, and support compliance."),
    ("Logistics Analyst", "Business & Operations", "supply_chain", "Improve how goods move through transportation, warehousing, and distribution networks.", "Analyze routes and service levels, track shipments, investigate delays, model costs, improve schedules, and coordinate carriers and operations teams.", {"tags":["Supply Chain", "Logistics"]}),
    ("Human Resources Specialist", "Business & Operations", "hr", "Support hiring, employee programs, performance, compensation, labour relations, or organizational development.", "Advise managers, analyze workforce data, support policies, coordinate employee programs, investigate issues, and document decisions."),
    ("Talent Acquisition Specialist", "Business & Operations", "hr", "Find, assess, and recruit candidates for an organization's open roles.", "Plan searches, review applicants, interview candidates, coordinate hiring teams, track recruiting data, and improve candidate experience."),
    ("Market Research Analyst", "Business & Operations", "market_research", "Study customers, competitors, and markets to support product, pricing, and growth decisions.", "Design research, analyze surveys and market data, interview customers, size markets, track competitors, and present findings."),
    ("Marketing Strategist", "Business & Operations", "marketing", "Plan how a brand or organization reaches, persuades, and retains customers.", "Research audiences, plan campaigns, coordinate content and channels, analyze performance, manage budgets, and refine messaging."),
    ("Brand Manager", "Business & Operations", "marketing", "Manage the positioning, growth, and commercial performance of a brand or product line.", "Review sales and customer data, plan campaigns, coordinate agencies, manage budgets, guide launches, and align product, sales, and marketing teams."),
    ("Corporate Communications Specialist", "Business & Operations", "marketing", "Manage clear communication with employees, media, customers, investors, or the public.", "Write announcements and briefs, prepare leaders, coordinate media responses, manage communication plans, and monitor reputation issues."),
    ("Sales Manager", "Business & Operations", "sales_manager", "Lead a team responsible for winning and growing business with customers.", "Set targets, coach sellers, review pipeline, support major deals, forecast revenue, improve sales processes, and coordinate with marketing and product teams."),
    ("Operations Manager", "Business & Operations", "business_manager", "Lead the people and processes that deliver a product or service day to day.", "Set operating targets, manage staffing and budgets, monitor quality and productivity, solve bottlenecks, and coordinate improvement projects."),

    # Science & Environment
    ("Biologist", "Science & Environment", "biologist", "Study living organisms, ecosystems, or biological processes in research, government, healthcare, conservation, or industry.", "Plan studies, collect samples or data, run analyses, interpret findings, write reports, and collaborate with field, lab, policy, or technical teams."),
    ("Microbiologist", "Science & Environment", "biologist", "Study microorganisms and their effects in health, food, environment, biotechnology, or research.", "Culture or analyze microbes, run experiments, maintain quality controls, interpret results, document methods, and support research or product development."),
    ("Biochemist", "Science & Environment", "biologist", "Study chemical processes in living systems and apply that knowledge in biotechnology, health, research, or industry.", "Design experiments, work with proteins or cells, analyze data, maintain lab records, review literature, and communicate findings."),
    ("Chemist", "Science & Environment", "chemist", "Analyze and develop substances and chemical processes for research, manufacturing, environment, energy, or consumer products.", "Run experiments and analytical tests, interpret spectra or measurements, develop methods, troubleshoot quality issues, and document results."),
    ("Physicist", "Science & Environment", "physicist", "Use mathematics and experiments to study physical systems in research, technology, energy, medicine, or industry.", "Build models, design experiments, analyze measurements, write software, review theory, and communicate technical results."),
    ("Geoscientist", "Science & Environment", "physical_science", "Study the Earth to understand resources, hazards, groundwater, environment, or geological history.", "Interpret maps and samples, analyze field and geophysical data, build geological models, visit sites, and prepare technical reports."),
    ("Environmental Scientist", "Science & Environment", "physical_science", "Study environmental conditions and help organizations understand pollution, ecosystems, compliance, and remediation.", "Plan sampling, analyze environmental data, prepare reports, assess risks, visit sites, and work with engineers, regulators, and clients."),
    ("Climate Analyst", "Science & Environment", "physical_science", "Analyze climate and environmental data to support planning, risk, research, or policy decisions.", "Work with large datasets, compare climate scenarios, map risk, review scientific literature, build reports, and explain uncertainty to decision makers."),
    ("Bioinformatics Analyst", "Science & Environment", "data_science", "Use programming and statistics to analyze biological, genomic, or biomedical data.", "Clean biological datasets, run pipelines, write code, perform statistical analyses, visualize results, and collaborate with scientists or clinicians."),
    ("Epidemiologist", "Science & Environment", "health_policy", "Study patterns and causes of health outcomes in populations and evaluate public-health interventions.", "Design studies, analyze health data, investigate trends, evaluate programs, write reports, and communicate findings to health leaders or the public."),

    # Law, policy, and government
    ("Lawyer", "Law & Public Policy", "lawyer", "Advise clients on legal rights, obligations, disputes, transactions, or regulatory matters.", "Research law, draft documents, negotiate, advise clients, prepare arguments, manage files, and appear in proceedings when the role requires it."),
    ("Corporate Lawyer", "Law & Public Policy", "lawyer", "Advise companies on transactions, contracts, governance, financing, and regulatory obligations.", "Draft and review agreements, perform due diligence, negotiate terms, advise executives, coordinate closings, and work with finance and business teams."),
    ("Litigation Lawyer", "Law & Public Policy", "lawyer", "Represent clients in disputes that may involve negotiation, hearings, arbitration, or court.", "Research issues, interview clients, review evidence, draft pleadings and motions, negotiate settlements, prepare witnesses, and argue cases."),
    ("Economist", "Law & Public Policy", "economist", "Use economic theory and data to study markets, policy, competition, labour, trade, or public programs.", "Build models, analyze data, review policy options, forecast trends, write reports, and brief decision makers."),
    ("Policy Analyst", "Law & Public Policy", "social_policy", "Research public problems and develop practical policy or program options for governments and organizations.", "Review evidence, analyze data, consult stakeholders, write briefing notes, compare options, and monitor policy implementation."),
    ("Science Policy Analyst", "Law & Public Policy", "science_policy", "Connect scientific evidence with public policy decisions in areas such as research, environment, technology, or innovation.", "Review scientific evidence, consult experts, analyze policy impacts, write briefs, and help design programs or regulations."),
    ("Government Program Officer", "Law & Public Policy", "government_program", "Design, administer, or evaluate public programs and services.", "Review applications or program data, interpret rules, coordinate stakeholders, prepare briefings, monitor outcomes, and recommend improvements."),
    ("Urban Planner", "Law & Public Policy", "urban_planner", "Plan how land, housing, transportation, services, and communities develop over time.", "Review development proposals, analyze land use and demographic data, consult communities, write planning reports, and present recommendations to decision makers."),
    ("Regulatory Compliance Analyst", "Law & Public Policy", "financial_officer", "Help organizations understand and meet laws, regulations, standards, and internal policies.", "Review rules, test controls, investigate exceptions, document findings, advise teams, and prepare reports for management or regulators."),
    ("Labour Relations Specialist", "Law & Public Policy", "hr", "Support workplace relations, collective agreements, investigations, and employment policy.", "Interpret agreements and policies, advise managers, prepare for grievances or negotiations, investigate issues, and document recommendations."),

    # Education & research
    ("University Professor", "Education & Research", "professor", "Teach university courses and, in many fields, lead original research and supervise students.", "Prepare lectures, teach, assess work, supervise students, conduct research, write papers and grants, and contribute to academic service."),
    ("College Instructor", "Education & Research", "college_instructor", "Teach applied, technical, vocational, or academic subjects in a college setting.", "Plan lessons, teach classes and labs, assess students, update course materials, support learners, and coordinate with programs or industry partners."),
    ("Secondary School Teacher", "Education & Research", "secondary_teacher", "Teach subject-area courses and support adolescent learning and development.", "Plan lessons, teach, assess work, give feedback, communicate with families and colleagues, supervise activities, and support student needs."),
    ("Elementary School Teacher", "Education & Research", "elementary_teacher", "Teach foundational academic and social skills across elementary grades.", "Plan lessons across subjects, assess learning, adapt instruction, communicate with families, manage classroom routines, and collaborate with support staff."),
    ("Education Policy Analyst", "Education & Research", "education_policy", "Research education systems and programs and recommend changes based on evidence.", "Analyze student or program data, review research, consult educators, write briefing notes, evaluate initiatives, and present recommendations."),
    ("Academic Researcher", "Education & Research", "professor", "Conduct original research in a university, institute, hospital, government, or specialized research organization.", "Design studies, collect and analyze data, publish findings, present work, supervise assistants, and apply for funding."),
    ("Librarian", "Education & Research", "librarian", "Help people find, evaluate, organize, and access information and library resources.", "Support research, manage collections and databases, teach information literacy, plan services, and organize digital or physical resources."),
    ("Archivist", "Education & Research", "archivist", "Preserve and organize records with long-term historical, legal, or institutional value.", "Appraise records, describe collections, manage digital preservation, support researchers, develop policies, and protect sensitive or fragile materials."),

    # Design & media
    ("UX Designer", "Design & Media", "web_dev", "Design digital products around user needs, usability, accessibility, and clear interaction.", "Interview users, map flows, create wireframes and prototypes, test designs, collaborate with product and engineering, and refine experiences from feedback.", {"tags":["User Research", "Product"]}),
    ("Product Designer", "Design & Media", "web_dev", "Shape the end-to-end experience and interface of digital products.", "Research problems, design flows and interfaces, prototype ideas, test with users, maintain design systems, and collaborate closely with product managers and engineers."),
    ("Technical Writer", "Design & Media", "technical_writer", "Turn complex technical information into clear documentation for users, developers, or employees.", "Interview subject-matter experts, test products, write guides and API documentation, organize content, edit for clarity, and maintain documentation as products change."),
    ("Content Strategist", "Design & Media", "marketing", "Plan how an organization creates, organizes, and measures useful content across channels.", "Research audiences, define content standards, plan editorial calendars, coordinate writers and designers, review analytics, and improve how people find and use content."),
    ("Public Relations Specialist", "Design & Media", "marketing", "Manage relationships and communication between organizations and the public or media.", "Write releases and talking points, pitch stories, monitor coverage, prepare spokespeople, coordinate events, and respond to reputation issues."),
    ("Film / Video Producer", "Design & Media", "producer", "Coordinate the creative, financial, and logistical work needed to produce film, video, or digital content.", "Develop concepts, manage budgets and schedules, hire crews, coordinate shoots, solve production problems, and oversee post-production delivery."),
    ("Broadcast Technician", "Design & Media", "broadcast", "Operate and maintain technical systems used in television, radio, streaming, or live production.", "Set up signal paths, operate broadcast equipment, monitor quality, troubleshoot failures, support live events, and maintain technical systems."),
    ("Professional Writer", "Design & Media", "writer", "Create long-form, editorial, commercial, educational, or creative written work for organizations or audiences.", "Research topics, develop drafts, interview sources, revise structure and language, work with editors, and adapt writing for different formats."),

    # Architecture & construction
    ("Architect", "Architecture & Construction", "architect", "Design buildings and spaces while balancing function, safety, code, sustainability, cost, and client needs.", "Develop concepts and drawings, coordinate consultants, review codes, meet clients, prepare permit or construction documents, and support projects during construction."),
    ("Landscape Architect", "Architecture & Construction", "landscape_arch", "Design outdoor spaces such as parks, campuses, streetscapes, waterfronts, and public landscapes.", "Analyze sites, create plans and details, select materials and planting, coordinate with engineers and planners, present designs, and review construction."),
    ("Construction Project Manager", "Architecture & Construction", "business_manager", "Lead construction projects from planning through completion, balancing cost, schedule, quality, contracts, and safety.", "Coordinate contractors and consultants, review schedules and budgets, resolve site issues, manage changes, report progress, and communicate with clients."),
    ("Construction Estimator", "Architecture & Construction", "construction_supervisor", "Estimate labour, materials, equipment, and risk so projects can be priced and planned accurately.", "Read drawings, measure quantities, request supplier pricing, build estimates, compare bids, assess risk, and support project handoff."),
    ("Building Inspector", "Architecture & Construction", "construction_supervisor", "Inspect construction and buildings for compliance with codes, permits, and safety requirements.", "Review plans, visit sites, document deficiencies, interpret codes, communicate with contractors, and verify corrections."),
    ("Land Surveyor", "Architecture & Construction", "urban_planner", "Measure and define land boundaries, elevations, and spatial information used in property and construction work.", "Plan surveys, use precision instruments and GNSS, interpret records, process field data, prepare plans, and certify results where licensed."),
    ("Real Estate Development Analyst", "Architecture & Construction", "market_research", "Evaluate potential development projects by combining market research, planning, finance, and real-estate analysis.", "Research sites and markets, build development models, review zoning, compare project scenarios, support due diligence, and prepare investment materials."),

    # Aviation & skilled technical — valuable alternatives even when a degree is not required.
    ("Airline Pilot", "Aviation & Skilled Technical", "pilot", "Operate aircraft safely and professionally for passenger, cargo, charter, or other aviation services.", "Plan flights, review weather and aircraft status, complete checklists, coordinate with crew and air traffic control, operate flights, and complete required records.", {"route":"Flight training / licensing"}),
    ("Power Engineer / Power Systems Operator", "Aviation & Skilled Technical", "power_engineer", "Operate and monitor boilers, turbines, generators, industrial utilities, or power systems.", "Monitor equipment, respond to alarms, adjust operating conditions, perform inspections, document readings, coordinate maintenance, and follow strict safety procedures.", {"route":"College / certification"}),
    ("Electrician", "Aviation & Skilled Technical", "electrician", "Install, maintain, and repair electrical systems in buildings or other settings.", "Read plans, install wiring and equipment, test circuits, troubleshoot faults, follow electrical codes, and document completed work.", {"route":"Apprenticeship"}),
    ("Power Line Technician", "Aviation & Skilled Technical", "powerline", "Build and maintain overhead and underground electrical distribution and transmission systems.", "Install and repair lines and equipment, climb or use lift equipment, respond to outages, test systems, and work under strict safety procedures.", {"route":"Apprenticeship"}),
    ("Boilermaker", "Aviation & Skilled Technical", "boilermaker", "Build, install, repair, and maintain boilers, pressure vessels, tanks, and heavy industrial equipment.", "Read drawings, fit and weld components, rig heavy parts, inspect equipment, perform repairs, and follow confined-space and industrial safety procedures.", {"route":"Apprenticeship"}),
    ("Ironworker", "Aviation & Skilled Technical", "ironworker", "Install structural steel, reinforcing steel, and metal systems on major construction projects.", "Read plans, rig and position steel, bolt or weld connections, install reinforcing systems, work at heights, and follow strict site safety procedures.", {"route":"Apprenticeship"}),
    ("Plumber", "Aviation & Skilled Technical", "plumber", "Install and repair piping systems for water, drainage, gas, heating, and industrial services.", "Read drawings, lay out piping, install fixtures and equipment, test systems, troubleshoot leaks, and follow plumbing codes.", {"route":"Apprenticeship"}),
    ("Construction Trade Supervisor", "Aviation & Skilled Technical", "construction_supervisor", "Coordinate skilled-trade crews, schedules, quality, and safety on construction projects.", "Plan daily work, assign tasks, coordinate materials and equipment, inspect quality, solve site issues, document progress, and enforce safety requirements.", {"route":"Trade experience / supervision"}),
    ("Heavy Equipment Crew Supervisor", "Aviation & Skilled Technical", "heavy_equipment_supervisor", "Lead crews operating heavy equipment on construction, mining, road, or civil projects.", "Coordinate operators, plan work sequences, check site conditions, monitor productivity, manage safety, and communicate with project managers and other trades.", {"route":"Trade experience / supervision"}),
]


def build_expanded_careers() -> list[dict]:
    careers = []
    for entry in ROLES:
        title, industry, wage, focus, tasks, *rest = entry
        kwargs = rest[0] if rest and isinstance(rest[0], dict) else {}
        careers.append(role(title, industry, wage, focus, tasks, **kwargs))
    return careers
