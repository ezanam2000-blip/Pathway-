# V32: clearer careers and steadier interactions

API version: 6.3.0. Asset version: 32.

Career browsing and quiz results now use compact cards: title, field, labelled
occupation pay benchmark, Save, Compare and View career. Descriptions, education,
skills and recommendation explanations appear after opening the career. Detail
sections start closed. The first detail view explains what the job does and shows
the pay benchmark. Full pay ranges, limitations and sources remain available.

Twenty-four common career explanations have been rewritten in plain language.
Additional task examples distinguish investment analysis from business financial
analysis. These are editorial explanations of occupational duties, not new salary
research or a claim that every job profile has been professionally reviewed.
Generic work settings are no longer presented as job challenges. Generic reward
and misconception paragraphs are removed from the career view. Day in the Life
describes tasks rather than pretending to know an employee's exact schedule.

Spacing styles now apply to desktop and mobile accordion headings. Titles and
subtitles are separate blocks with explicit spacing. Heading tracking is normal.
Selecting a quiz answer updates the controls in place. It no longer replaces the
whole application. Search waits briefly until typing pauses before rebuilding
results. Card entrance animations are disabled to prevent replay on every save.
Saving or comparing within career details preserves the scroll position and open
sections. Career card action buttons stop the parent card click.

## Validation

Run the API tests and full journey test:

```sh
python -m pytest tests/test_v31_discovery.py tests/test_api.py tests/test_v30_discovery.py tests/test_v32_clarity.py -q
node tests/frontend_discovery.cjs
```

The journey test uses an actual disposable API and the production frontend
renderers. It checks all 220 career detail renderers, navigation, quiz, skips,
branch edits, guest persistence, saved careers, comparisons, account sync and
errors. A new regression check ensures quiz selection does not redraw the app.
This is not real-browser or physical iPhone validation. The generated local
layout preview was blocked by the cloud browser's file URL policy. No workaround
was attempted. Visual and physical-device checks remain necessary after upload.

## Deploy this existing service

Replace the root ZIP in ezanam2000-blip/Pathway- on main. Its name must be exactly
`Pathway-V8 (1).zip`, matching Render's existing build command. Preserve all current
environment variables and database settings. If automatic deployment does not
start, manually deploy the latest commit in the existing pathway-v8 service.

After deployment, require Render status live and `/api/health` version 6.3.0.
Then test the careers grid, a finance detail, Day in the Life, keyboard close,
rapid quiz selections, Back, Skip, resume after refresh, saving and comparison.
Test at phone, tablet and desktop widths. Do not label the build perfect or
App Store approved based on the automated checks.

## Apple submission status

This export contains an existing Capacitor iOS wrapper which loads the Render
app. It does not contain a generated Xcode iOS project, signed archive, App Store
Connect submission, final app icons or device screenshots. This Linux environment
cannot sign and archive the iOS app. Developer membership, bundle availability,
signing access, privacy declarations and production database durability have not
been verified. No Apple account or signing credentials have been requested.

Next: generate the native iOS project on a Mac, sign with the owner's developer
team, test on an iPhone, prepare screenshots and App Store Connect metadata,
complete privacy/age-rating information, then archive and upload. Review a real
account's signup/login/deletion before submission. Apple guideline 4.2 requires
utility and UI beyond a repackaged website; a wrapper alone does not establish
approval. A next-day store release cannot be guaranteed.

Official references checked October 22, 2026:
- https://developer.apple.com/help/app-review/after-submitting-for-review/review-status/
- https://developer.apple.com/app-store/review/guidelines/
