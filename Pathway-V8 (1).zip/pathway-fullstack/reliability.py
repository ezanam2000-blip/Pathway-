"""Small shared reliability helpers. No user data or credentials live here."""
from contextvars import ContextVar
from contextlib import contextmanager
from datetime import date, datetime
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo
import logging


logger = logging.getLogger(__name__)


request_connections = ContextVar('pathway_request_connections', default=None)


@contextmanager
def connection_scope():
    opened = []
    token = request_connections.set(opened)
    try:
        yield
    finally:
        try:
            for connection in reversed(opened):
                connection.close()
        finally:
            request_connections.reset(token)


class ConnectionCleanupMiddleware:
    """Close every connection opened by a request, including exception paths."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        with connection_scope():
            await self.app(scope, receive, send)


class RequestSizeMiddleware:
    def __init__(self, app, maximum=65536):
        self.app, self.maximum = app, maximum

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http' or scope['method'] not in {'POST', 'PUT', 'PATCH', 'DELETE'}:
            return await self.app(scope, receive, send)
        events, size = [], 0
        while True:
            event = await receive()
            if event['type'] == 'http.disconnect':
                return
            size += len(event.get('body', b''))
            if size > self.maximum:
                from starlette.responses import JSONResponse
                response = JSONResponse({'detail':'This request is too large. Shorten it and try again.'}, status_code=413)
                return await response(scope, receive, send)
            events.append(event)
            if not event.get('more_body'):
                break
        iterator = iter(events)
        async def replay():
            try:
                return next(iterator)
            except StopIteration:
                return await receive()
        await self.app(scope, replay, send)


class ManagedConnection:
    def __init__(self, raw, release=None):
        self.raw, self.release, self.closed = raw, release, False
        opened = request_connections.get()
        if opened is not None:
            opened.append(self)

    def _call(self, method, *args):
        try:
            return getattr(self.raw, method)(*args)
        except Exception:
            self.close()
            raise

    def execute(self, query, params=()):
        return self._call('execute', query, params)

    def executescript(self, script):
        return self._call('executescript', script)

    def commit(self):
        return self._call('commit')

    def rollback(self):
        return self._call('rollback')

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            self.raw.rollback()
        except Exception:
            logger.exception('Failed to roll back a connection during cleanup')
        finally:
            try:
                if self.release:
                    self.release(self.raw)
                else:
                    self.raw.close()
            except Exception:
                logger.exception('Failed to release a connection during cleanup')
                try:
                    self.raw.close()
                except Exception:
                    logger.exception('Failed to close an unavailable connection')

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def postgres_placeholders(query):
    """Translate qmarks outside SQL strings/comments; escape psycopg percents."""
    result, i, quote = [], 0, None
    while i < len(query):
        char = query[i]
        if quote:
            result.append(char)
            if char == quote:
                if i + 1 < len(query) and query[i + 1] == quote:
                    result.append(query[i + 1])
                    i += 1
                else:
                    quote = None
        elif query.startswith('--', i):
            end = query.find('\n', i)
            if end < 0:
                end = len(query)
            result.append(query[i:end])
            i = end
            continue
        elif query.startswith('/*', i):
            end = query.find('*/', i + 2)
            end = len(query) if end < 0 else end + 2
            result.append(query[i:end])
            i = end
            continue
        elif char in "'\"":
            quote = char
            result.append(char)
        elif char == '?':
            result.append('%s')
        else:
            result.append(char)
        i += 1
    # Placeholders we inserted must remain %s; every original % is literal.
    # Re-escape original percents before scanning instead (see wrapper below).
    return ''.join(result).replace(' COLLATE NOCASE', '')


def postgres_sql(query):
    return postgres_placeholders(query.replace('%', '%%'))


def https_url(value):
    if not isinstance(value, str) or any(ord(c) < 32 for c in value):
        return False
    try:
        url = urlsplit(value)
        return url.scheme == 'https' and bool(url.hostname) and not url.username and not url.password
    except ValueError:
        return False


def application_deadline_status(value, today=None):
    if not value:
        return 'check_source'
    deadline = date.fromisoformat(value)
    today = today or datetime.now(ZoneInfo('America/Toronto')).date()
    return 'closed' if deadline < today else 'due_today' if deadline == today else 'open'


def escape_like(value):
    return value.replace('!', '!!').replace('%', '!%').replace('_', '!_')
