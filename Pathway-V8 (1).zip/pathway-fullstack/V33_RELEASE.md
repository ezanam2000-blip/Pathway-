# V33: plain job explanations and usability fixes

API version: 6.4.0. Updated browser assets: 33.2.

Homepage copy update: restored “Your future has more options.” above
“See what different jobs involve and how to get started.”

## What changed

- All 220 careers have a short explanation of the job's purpose and actual work.
  These are editorial summaries of the existing occupations, not claims that all
  salary, education and licensing information has been newly verified.
- Plain task summaries are also used in comparisons and the general Day in the
  Life view. Role-specific task examples and challenges remain where available.
- The homepage, results, dashboard, funding page and guidance use more direct
  language. Longer qualifications and sources stay inside the relevant details.
- Browsing has one search field and one field filter. Students can search for
  terms such as nursing or coding. Multiword searches can match words separately,
  with job-title matches appearing first. Empty results offer a clear reset.
- Choosing an optional hobby clears an unrelated field filter.
- Comparison starts with the job, pay, education and hours. More details are
  available on request. Back restores the previous query, field and result count.
- Below 760px, comparison becomes a vertical list grouped by topic. Each value
  names its career. Remove, save, source links and expanded details use the same
  data and actions as the desktop table. Phone users no longer need to scroll
  across a wide table or read squeezed columns.
- Study abroad now has one form for destination, subject, study level and study
  type. Show study options applies the choices together. Changing a native
  select does not redraw the form. A clear message identifies unapplied changes.
- Course and scholarship actions name the official website and explain when a
  link opens a guide instead of a course search. US master's and doctoral choices
  open graduate guidance. External sites do not receive the form selections.
- Scholarship cards are filtered directly by the submitted destination and study
  level. Exchange guidance uses the home university's exchange office rather
  than presenting the recorded degree awards as exchange grants. Empty results
  explain that other funding may exist.
- Budget and home-country controls are inside Costs & next steps. A budget is
  clearly a planning note, not a filter backed by tuition records. Australia and
  Canada open official course finders. Netherlands and Japan open broader funding
  guides. The Canada note reflects EduCanada's current data-update limitation.
- Career-to-study routing recognises creative and environmental fields. A field
  without a recorded mapping uses Any subject instead of defaulting to business.
- Both guests and account holders see saved careers directly on their dashboard.
- Repeated account Save taps send one request. A successful save updates the
  local list without a second request that could fail after the save succeeded.
- Responses belonging to another account or an abandoned quiz cannot replace
  the current user's work. Quiz summary labels reflect adaptive answer choices.
- Finance branch matching uses finance job titles. A creative portfolio no longer
  creates a markets/investing match. Repeated matching labels are counted once.
- V32's compact cards, spacing rules, in-place quiz selection, search delay,
  reduced card animations and preserved detail scroll/sections remain included.

## Sources

Existing pay sources and dates are unchanged. No new salary, tuition, scholarship
deadline or admission figures have been invented. Three occupational overviews
were checked against the following official sources on October 22, 2026. Those
profiles now carry a separate overview source and review date, so salary dates
are not confused with description research:

- Medical Dosimetrist: https://www.bls.gov/ooh/healthcare/medical-dosimetrists.htm
- Human Factors Specialist: https://www.onetonline.org/link/summary/17-2112.01
- Industrial Ecologist: https://www.onetonline.org/link/summary/19-2041.03

## Verification

```sh
python -m pytest -q
node tests/frontend_discovery.cjs
```

The Python suite covers existing API behaviour, auth, saved items, roadmaps,
course tools, discovery state, matching and all 220 explanation records. The
frontend journey runs actual production renderers and event handlers against a
disposable real API. It checks searches, filters, comparisons, quiz selection,
resume, saves, account isolation, error states and all 220 career detail views.
New regressions cover stale quiz responses and repeated account Save taps.
The mobile comparison's job labels, pay values and removal actions are checked.
Study-guide tests cover submission, unapplied choices, reset, level-aware US
links, empty scholarship results and 128 destination/level/study-type/tab
combinations. All 32 Python tests and the frontend journey passed for 33.2.
Older tests that hard-coded the V31 release number or asset suffix were updated;
V33 has a separate exact version/asset check.

No full browser layout or physical iPhone test has passed for this package yet.
The previous cloud browser rejected the local file preview under its URL policy;
that access restriction has not been bypassed. Test the deployed build in Safari
and on a real iPhone before treating it as an App Store release candidate.

## Upload and deploy

The existing source repository is ezanam2000-blip/Pathway-, branch main. The
existing Render service extracts a root file named exactly `Pathway-V8 (1).zip`.
Replace that file with this release ZIP. Do not extract the source files into the
repository unless also deliberately changing the existing build configuration.
Preserve database settings and all other environment variables.

After the deployment is live, `/api/health` must report 6.4.0. Confirm the career
cards are compact, a job opens its full explanation, the accordion titles are
spaced, quiz choices remain stable, search keeps focus and Back from comparison
keeps filters. Verify saves and resume after refreshing. A green deployment
alone is not proof that these visible changes are present.

## Still outstanding

- Live deployment and visual checks of this package.
- Physical iPhone/Safari testing, including keyboard and smaller screen layouts.
- Verification of durable production account storage and email delivery.
- Further source review of education, occupational pay proxies and global study
  information; current gaps remain labelled inside the relevant details.
- A signed iOS archive, icons, screenshots and App Store Connect submission.
  The included Capacitor configuration is not a signed build or Apple approval.

These limits do not mean the known bugs were left untouched; they identify the
checks that automated API and renderer tests cannot complete.
