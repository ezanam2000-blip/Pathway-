# Pathway V35 — career discovery and planning

API **6.6.0**, browser assets **35**, prepared October 23, 2026.

Pathway helps students understand jobs, compare options and plan a next step.
The slogan remains **Your future has more options.** This release repairs the
existing application. It preserves the compact career cards, adaptive quiz,
progressive details, mobile comparison, accounts, saves,
roadmaps, course checker, application tracker and visual theme.

Study Abroad has been removed from the app, including international funding
links and career-page study destinations. Existing Ontario education and funding
pages remain available.

Read `V35_RELEASE.md` for the change, evidence and exact deployment steps.
Read `V34_RELEASE.md` for the previous reliability fixes and outstanding
production checks. Historical release notes describe earlier builds.

## Run and check

```bash
python -m pip install -r requirements-dev.txt
uvicorn app:app --reload
```

Open http://127.0.0.1:8000 . Environment variables must be set in the process or
hosting dashboard; copying `.env.example` alone does not load it into Python.
Never commit credentials, a database or development email logs.

```bash
python -m pytest -q
node tests/frontend_discovery.cjs
```

The frontend journey starts a disposable API on port 8765. It exercises actual
renderers and handlers in a small DOM stub. It does not test browser layout,
VoiceOver, iPhone swipe gestures, the keyboard or native plugins. Those need a
deployed preview and real-device testing.

For PostgreSQL integration, set `PATHWAY_TEST_DATABASE_URL` to a **disposable**
PostgreSQL database before running pytest. That check creates and removes a
unique test schema; it must never point at a production database. With no test
database, the check skips explicitly.

`requirements-lock.txt` constrains dependency versions to the tested Linux /
Python 3.12 environment. Other Python versions and native iOS dependencies still
need their own build checks.

## Production configuration

- `PATHWAY_BASE_URL`: public HTTPS URL. Render can supply `RENDER_EXTERNAL_URL`
  as a fallback. Production rejects a localhost URL or insecure session cookies.
- `PATHWAY_COOKIE_SECURE=1` and `PATHWAY_ENV=production` outside Render.
- `DATABASE_URL`: managed PostgreSQL; otherwise `PATHWAY_DB_PATH` must use
  durable SQLite storage. The included Blueprint does not prove the existing
  service has a persistent disk. Do not switch production databases without a
  tested migration and backup.
- SMTP settings: real verification/reset email. Production does not silently
  write mail to a local development log when SMTP is absent.
- `PATHWAY_SUPPORT_EMAIL`: an address the operator wants published on `/support`.
  No private account address is automatically used. Configure and test this
  before a public launch.
- `PATHWAY_ALLOWED_ORIGINS`: optional comma-separated additional exact origins
  for intentional domains; this is not a wildcard CORS policy.
- Optional `OPENAI_API_KEY`: stays on the server. AI answers require explicit
  per-question consent and a verified account email. Normal record summaries do
  not send questions to OpenAI.

The Dockerfile no longer trusts every forwarded IP. Configure
`FORWARDED_ALLOW_IPS` only for known proxy addresses supplied by the host. Verify
the production proxy chain; never use `*` to work around missing configuration.
Request counters are now stored in the database, with per-account limits for
login, password reset and AI requests as well as the existing client limits.

## Admin access

Bootstrap creates a new account only if the configured admin email is absent.
A matching public signup is never silently promoted. Changing the bootstrap
password does not silently change an existing account's password.

Using trusted server access and the same database environment as the app:

```bash
python manage_admin.py --email operator@example.com
```

This prompts for a replacement password and revokes previous sessions and
authentication links. If recovering a non-admin account, independently verify
the owner, then explicitly add `--grant-admin`. This command is not a web route.
It was tested against a disposable account, not run against a live account.

Admin content edits and archives are protected from seed updates on restart.
Previously overwritten data cannot be recovered by this change.

## Data scope and accuracy

There are **219 published careers**, seven recorded programs and two scholarship
records. The unsourced Entrepreneurship record is kept out of the public app.
The explanation library still contains 220 editorial descriptions. Other career
pay, education and licensing facts have not all been newly reviewed.

The recorded Loran deadline is closed. No next-cycle deadline is invented.
Admission and scholarship source dates remain visible; old verified records
move back to review after `PATHWAY_STALE_DAYS` (default 180). An operator must
review sources to republish them, rather than advancing verification dates
automatically. `DATA_SOURCES.md` records the existing source scope.

Education information covers the recorded Ontario programs. Unknown costs and
local requirements remain labelled. Awards still require checking the official
provider's current eligibility and deadline.

## Deployment and iOS

The current Render service extracts the repository-root archive named exactly
`Pathway-V8 (1).zip`. Its ZIP root must contain `pathway-fullstack/`. Keep that
arrangement until the host's build/start commands are deliberately migrated.
The optional disk Blueprint describes a different setup; applying it can require
paid resources and does not repair the existing service by itself.

`ios-app/` contains Capacitor source configuration. No generated Xcode project,
signed archive, final icons, screenshots or App Store submission is included.
See `ios-app/README-IOS.md`. Catalog caching helps a running web app recover from
a failed refresh; it does not make the remote native shell fully available on a
cold offline launch. App Store readiness has not been established.

For SQLite backups use `python backup.py` and separately test recovery from a
copy stored outside the application host. This release does not change a live
hosting plan, secrets, database or user account.
