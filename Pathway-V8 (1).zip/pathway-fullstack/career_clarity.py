"""Plain-language editorial explanations. No pay or admission claims are added.

These explain existing occupational tasks; provenance remains on each record.
"""
from job_explanations import JOB_EXPLANATIONS

EXPLANATIONS = {
    'Investment Analyst': 'An investment analyst studies companies and investments to help a fund or client decide where to put money. They read financial reports, estimate what an investment is worth and explain the risks.',
    'Financial Analyst': 'A financial analyst studies money coming into and going out of a business. They build budgets, predict future results and help managers decide how to spend or invest.',
    'Investment Banking': 'Investment bankers help companies raise money, buy other companies or sell a business. Junior bankers check financial figures, estimate company values and prepare presentations for clients.',
    'Financial Advisor': 'A financial advisor helps clients plan how to save, invest and reach money goals. They review the client’s finances, explain options and update the plan as the client’s situation changes.',
    'Accountant': 'An accountant keeps and checks financial records. They prepare reports, work out taxes and help a business understand what it earns, spends and owes.',
    'Forensic Accountant': 'A forensic accountant investigates financial records when money is missing or a transaction is disputed. They trace payments, identify inconsistencies and explain their findings for investigations or court cases.',
    'Actuary': 'An actuary uses mathematics to estimate the cost of future risks. Insurance companies and pension plans use their calculations to set prices and decide how much money to keep aside.',
    'Software Engineering': 'Software engineers build and maintain apps and computer systems. They write code, test features, fix bugs and work with teammates to keep the software reliable.',
    'Backend Software Engineer': 'A backend software engineer builds the parts of an app that work behind the screen. They write the code that stores data, handles requests and connects the app to other services.',
    'Frontend Software Engineer': 'A frontend software engineer builds the screens and controls people use on a website or app. They turn designs into working pages and fix problems with layout, accessibility and speed.',
    'Data Scientist': 'A data scientist uses data to answer questions and make predictions. They clean records, look for patterns and build models that help an organization make decisions.',
    'Cybersecurity Analyst': 'A cybersecurity analyst protects an organization’s computer systems and information. They investigate security alerts, check for weaknesses and help respond to attacks.',
    'UX Designer': 'A UX designer makes apps and websites easier to use. They study what people need, sketch screens and test whether users can complete tasks without getting stuck.',
    'UX / Product Designer': 'A product designer plans how a digital product looks and works. They design screens, test ideas with users and work with developers to build the finished experience.',
    'User Experience Researcher': 'A user experience researcher studies how people use a product. They interview users, observe people trying tasks and explain what the team should improve.',
    'Registered Nurse': 'A registered nurse cares for patients and monitors their health. They give treatments within their professional role, notice changes in a patient’s condition and coordinate care with the healthcare team.',
    'Mechanical Engineer': 'A mechanical engineer designs and improves machines and physical products. They calculate how parts should work, test designs and solve problems with safety or performance.',
    'Electrician': 'An electrician installs and repairs electrical wiring and equipment. They read plans, find faults and test that circuits work safely.',
    'Lawyer': 'A lawyer helps people and organizations understand and use the law. They research legal problems, prepare documents, negotiate agreements and represent clients in disputes.',
    'Secondary School Teacher': 'A secondary school teacher teaches a subject to high school students. They plan lessons, explain ideas, assess work and help students who need extra support.',
    'Management Consultant': 'A management consultant helps organizations solve business problems. They interview staff, study how the business works and recommend changes to costs, processes or strategy.',
    'Supply Chain Analyst': 'A supply chain analyst studies how products move from suppliers to customers. They track stock, deliveries and costs to help prevent shortages and delays.',
    'Sports Data Analyst': 'A sports data analyst studies player and team performance using numbers. They check match data, identify patterns and explain findings to coaches or team staff.',
    'Music Metadata Specialist': 'A music metadata specialist keeps the information attached to music releases accurate. They check artist names, song credits and release details so digital services can identify and organize the right recordings.',
}

TASKS = {
    'Investment Analyst': (['Read a company’s financial reports and recent news.', 'Use a spreadsheet to estimate its value and compare investment risks.', 'Write a recommendation explaining the evidence.'], 'Deadlines and changing markets put pressure on the analysis. A sound recommendation can still lose money.'),
    'Financial Analyst': (['Compare actual income and spending with the budget.', 'Update a spreadsheet showing expected future results.', 'Explain changes and spending choices to managers.'], 'Small errors can affect business decisions. Reports often need revisions before a deadline.'),
    'Accountant': (['Check invoices and reconcile account balances.', 'Prepare financial reports or tax records.', 'Investigate errors and explain the figures to a client or manager.'], 'Tax deadlines and reporting periods can create busy weeks. Accuracy matters even when tasks are repetitive.'),
    'Data Scientist': (['Clean missing or incorrect values in a dataset.', 'Test a statistical model against real observations.', 'Explain the findings and limits to a team.'], 'Much of the work is preparing data. A pattern in the data does not prove what caused it.'),
    'Backend Software Engineer': (['Write or update code that handles app requests.', 'Test how data is stored and retrieved.', 'Investigate bugs and review a teammate’s code.'], 'Failures can affect many users. Debugging and maintenance take substantial time.'),
    'Frontend Software Engineer': (['Build a screen from a product design.', 'Test its controls on different screen sizes.', 'Fix visual bugs and review code with the team.'], 'A screen must work across browsers, devices and accessibility needs.'),
    'Music Metadata Specialist': (['Check artist names and song credits against release records.', 'Resolve duplicate or conflicting entries.', 'Correct information supplied to music services.'], 'The work is detailed record keeping. It involves much more checking than making music.'),
}

ALL_EXPLANATIONS = {**JOB_EXPLANATIONS, **EXPLANATIONS}
OVERVIEW_SOURCES = {
    'Medical Dosimetrist': 'https://www.bls.gov/ooh/healthcare/medical-dosimetrists.htm',
    'Human Factors Specialist': 'https://www.onetonline.org/link/summary/17-2112.01',
    'Industrial Ecologist': 'https://www.onetonline.org/link/summary/19-2041.03',
}

def clarify_career(item):
    description = ALL_EXPLANATIONS.get(item['title'])
    if description:
        item['description'] = description
        item['plain_tasks'] = description.split('. ', 1)[-1]
    if item['title'] in OVERVIEW_SOURCES:
        item['overview_source_url'] = OVERVIEW_SOURCES[item['title']]
        item['overview_reviewed'] = '2026-10-22'
    return item
