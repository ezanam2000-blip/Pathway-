# V26 — brighter descriptions

Visual-only refinement on top of V25. No changes to endpoints, quiz matching,
roadmaps, or navigation.

- Description colour: vivid, soft aqua-silver `#C6F3FF` (was flatter blue-grey).
- Featured intro and next-action description: brighter `#E1FBFF`.
- Repeated explanatory text: fresh cyan-silver `#C3F0FF`.
- Metadata/eyebrows: contrasting periwinkle `#D1D8FF`.
- Links: clear cyan `#8CF2FF`.
- White headings, navy surfaces, existing mobile layout and motion settings remain.
- `styles.css` cache key bumped to `v=26` to push this change to phones.
