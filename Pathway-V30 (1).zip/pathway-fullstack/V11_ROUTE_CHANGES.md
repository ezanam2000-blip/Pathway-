# Pathway V11 — broader routes

- Expanded Career Match to 12 questions.
- Added a route-preference question and an interest-based final follow-up question.
- Added 18 career options that include college, apprenticeship, employer-training, portfolio, licensing, and work-first routes.
- Added structured `route_options` to career records and a “Ways to get there” section on career pages.
- Added a Career Explorer filter for college, trades, and other non-university routes.
- Made annual pay more prominent on career cards and detail pages.
- Kept Job Bank sources and yearly estimates visible.
- Preserved the iOS/App Store-only Capacitor shell from V10.

Validation: `pytest -q` = 6 passed; `node --check static/app.js` = passed.
