# Pathway V24 — Roadmaps → Dashboard → Compare → Ontario Checker → Advisor

Built on the V20 grade-aware roadmap release. App version 6.0.0.

## V21 — Student dashboard
- Logged-in home shows one open checklist action and marks it complete using the existing authenticated /api/plan/tasks/{id} endpoint.
- Progress bar shows completed / total tasks, saved career count, and next step.
- Shortcuts to Discover, Compare, Ontario course check, and Ask Pathway.
- V20 grade-based roadmaps, save, and progress remain intact.

## V22 — Three-career comparison
- Add careers from the explorer, results, or details; max 3, remove/clear, compare on a horizontally swipeable iPhone layout.
- Side by side: Job Bank-linked wage range, region/check date, education routes, hours, day-to-day work, outlook, possible advantages/challenges, sources and an action to build a roadmap.
- For missing education costs / lengths, the UI explicitly says no verified general estimate. No invented wage predictions, employment guarantees, or costs.
- Comparison selection is in page memory (not saved between visits).

## V23 — Ontario course/admission checker
- Public stateless POST /api/admissions/check accepts up to 28 `{code,grade?}` course entries. Input grades are not persisted.
- Conservative mapping from existing Pathway source-linked program records. Reports missing codes, accepted-alternative checks, known below-minimum grades, and manual-review cases.
- Explicitly distinguishes course presence from admission eligibility/competitiveness. Source and last-checked date displayed for every returned program. Supplemental applications still need checking.
- Only programs with mapped reliable prerequisites receive automated code checks. Unmapped ones are marked for manual review.
- The first release does NOT automatically resolve full Top 6 admission averages, school-specific course equivalencies, program tuition, living costs, or offer odds.

## V24 — Quiz + source-backed research mentor
- Students can revisit / edit quiz answers rather than starting over; changing an earlier answer clears dependent later choices. Quiz remains 10 adaptive questions with Top 5 matches.
- POST /api/advisor/ask requires a signed-in user, is rate-limited, and limits question length.
- References a small amount of existing Pathway career and program data; source URLs displayed to the student.
- **Actual AI only when `OPENAI_API_KEY` is set on the server**. `PATHWAY_AI_MODEL` selects the deployed model (defaults to `gpt-4.1-mini`). Requests use the Responses API with `store=false` and career-advice guardrails. API key never goes to browser.
- With no key or an API failure, clearly labelled **source-backed (non-AI) summary** is returned. This keeps Ask Pathway usable without making false AI claims.
- Do not enter sensitive personal details into the advisor. AI request text is sent to the configured provider.

## Verification
- Test: `pip install -r requirements.txt -r requirements-dev.txt && pytest -q` (9 tests including V24).
- JS syntax: `node --check static/app.js`.
- iPhone layouts measured at 320,375,390,430,768,1024 pixels in Chromium; no body horizontal overflow for home, career explorer, comparison, tools, checker, advisor, or My Plan.
- Front-end interactions tested offline with mocked API: compare selection, course checker submission, advisor reply rendering, quiz answer adjustments.

## Production deployment
- Current Render build command (unchanged): `python -m zipfile -e "Pathway-V8 (1).zip" . && pip install -r pathway-fullstack/requirements.txt`
- Current Render start command (unchanged): `cd pathway-fullstack && uvicorn app:app --host 0.0.0.0 --port $PORT`
- Upload the accompanying exact-name ZIP `Pathway-V8 (1).zip` to GitHub, replacing the existing file, then deploy the new commit in Render. The V24 source is not deployed merely by creating this ZIP.
- `DATABASE_URL` remains the production DB connection. Ensure it's a persistent, currently active Postgres instance before inviting users. SQLite is for local use only.
- On production, set `PATHWAY_COOKIE_SECURE=1`, `PATHWAY_BASE_URL`, and SMTP settings as applicable. Set `OPENAI_API_KEY` server-side only if AI mode is desired. Never publish API credentials.
