"""V20 exploratory career roadmaps. These are guidance, not admissions determinations."""
from __future__ import annotations

GRADE_OPTIONS = ('Grade 9', 'Grade 10', 'Grade 11', 'Grade 12', 'Post-secondary')


def grade_index(grade: str) -> int:
    label = str(grade or '').lower()
    for n in ('9', '10', '11', '12'):
        if n in label:
            return int(n)-9
    return 4 if any(x in label for x in ('college', 'university', 'post-', 'early career')) else 3


def route_choices(career: dict) -> list[dict]:
    raw = career.get('route_options') or []
    found = []
    seen = set()
    for i, route in enumerate(raw[:6]):
        key = str(route.get('type') or f'option{i}').lower().strip()
        if key in seen:
            continue
        seen.add(key)
        found.append({'key':key, 'name':route.get('name') or 'Explore this route',
                      'summary':route.get('summary') or '', 'requirement':route.get('requirement') or '',
                      'source_url':route.get('source_url') or None})
    if not found:
        found = [{'key':'open','name':'Explore possible routes',
                  'summary':career.get('education') or 'Research training and entry requirements.',
                  'requirement':'', 'source_url':None}]
    return found



def _practical_steps(career: dict, route: dict) -> dict[str, list[str]]:
    """Small suggested actions that a student can understand and try.

    These are ideas, not official admission prerequisites or job guarantees.
    """
    title = str(career.get('title') or '').lower()
    industry = str(career.get('industry') or '').lower()
    route_type = route['key']
    job = career['title']

    # Finance jobs can lead to very different courses and training. Keep examples relevant.
    if 'investment banking' in title:
        return {
            'grade9': [
                'Choose a company you like. Find out what it sells.',
                'Make a simple spending plan for a pretend $100 budget.',
                'Ask your teacher which math courses you can choose next year.'
            ],
            'grade10': [
                'Find a business club at your school and try one meeting if it sounds interesting.',
                'Use a spreadsheet to track the costs of a pretend small business.',
                'Ask your guidance counsellor which Grade 11 courses keep business programs open.'
            ],
            'grade11': [
                'Open Pathway’s Universities section. Compare the Grade 12 courses listed for Rotman Commerce and Smith Commerce.',
                'Choose a company you use. Write three sentences about what it sells and how it makes money.',
                'Ask your guidance counsellor if your Grade 12 courses meet your preferred business programs’ requirements.'
            ],
            'grade12': [
                'Check the official deadlines for two business programs you want to apply to.',
                'If a program has extra application questions or videos, add that deadline to your phone calendar.',
                'Make a one-page résumé with your school clubs, projects, volunteer work and jobs.'
            ],
            'training': [
                'Find a university finance club and attend an introductory meeting if you can.',
                'Check your university career centre’s page for student finance internships.',
                'Build a spreadsheet comparing the sales and costs of two companies.'
            ],
            'early': [
                'Look for junior finance roles that match your skills and experience.',
                'Practise explaining a company you researched in one minute.',
                'Ask a colleague which Excel or finance skill you should improve next.'
            ]
        }
    if 'actuary' in title:
        return {
            'grade9': [
                'Try a probability puzzle or calculate the chance of drawing a card.',
                'Ask your math teacher which courses lead to senior math.',
                'Read what an actuary does for insurance or pensions.'
            ],
            'grade10': [
                'Try a spreadsheet that calculates the average of a set of numbers.',
                'Ask your counsellor how to keep Grade 12 math options open.',
                'Look at one Ontario university program in mathematics.'
            ],
            'grade11': [
                'Compare two actuarial science or math programs. Note their Grade 12 math requirements.',
                'Use a spreadsheet to calculate the average cost of ten pretend insurance claims.',
                'Ask your guidance counsellor if your Grade 12 math choices meet those requirements.'
            ],
            'grade12': [
                'Check official math-program deadlines and required Grade 12 courses.',
                'Ask your school about calculus and data management courses you can take.',
                'Put your application deadlines in your phone calendar.'
            ],
            'training': [
                'Ask your department about actuarial internships or co-op options.',
                'Check the current professional examination pathways on the relevant actuarial body’s website.',
                'Build a spreadsheet model using probability data from a class project.'
            ],
            'early': [
                'Look for junior actuarial analyst positions that match your training.',
                'Ask your employer how actuarial exams fit with your role.',
                'Practise explaining your calculations in plain language.'
            ]
        }
    if 'accountant' in title or title == 'accounting':
        return {
            'grade9': [
                'Make a spending plan using a spreadsheet.',
                'Calculate the cost and profit from a pretend snack sale.',
                'Ask your teacher which math courses you can take next year.'
            ],
            'grade10': [
                'Try a business or accounting class if your school offers one.',
                'Track income and expenses for a pretend small business.',
                'Ask your counsellor which Grade 11 courses keep accounting programs open.'
            ],
            'grade11': [
                'Find two Ontario college or university accounting programs. Check their Grade 12 entry courses.',
                'Make a spreadsheet that shows monthly income, expenses and profit for a pretend business.',
                'Ask your guidance counsellor whether your planned courses meet those programs’ entry rules.'
            ],
            'grade12': [
                'Check the required courses and deadlines for two accounting programs.',
                'Put the application dates in your phone calendar.',
                'Ask whether the programs offer co-op, which means studying and getting paid work experience.'
            ],
            'training': [
                'Check your college or university career page for accounting placements.',
                'Practise making a basic income-and-expenses spreadsheet.',
                'Check CPA Ontario’s current requirements if you want to pursue the CPA designation.'
            ],
            'early': [
                'Look for entry-level accounting roles that match your training.',
                'Practise explaining a budget or financial report in simple terms.',
                'Ask which training or qualifications your employer supports.'
            ]
        }
    if any(word in title for word in ('investment banking', 'investment analyst', 'financial advisor', 'accountant', 'actuary', 'economist')) or 'finance' in industry:
        return {
            'grade9': [
                'Make a simple budget using a spreadsheet.',
                'Pick a business you know and write down how it makes money.',
                'Ask your teacher which math courses you can take next year.'
            ],
            'grade10': [
                'Try a finance or business club at school if one is available.',
                'Use a spreadsheet to track the costs of a pretend small business.',
                'Ask a counsellor which Grade 11 courses keep business programs open.'
            ],
            'grade11': [
                'Open the admission pages for two Ontario business programs. Write down the Grade 12 courses they require.',
                'Choose a company you use. Write three sentences about what it sells and how it makes money.',
                'Ask your guidance counsellor if your Grade 12 courses meet those programs’ English and math requirements.'
            ],
            'grade12': [
                'Check the required Grade 12 courses and deadlines for two Ontario business programs you might apply to.',
                'Make a one-page résumé with your volunteer work, school clubs and jobs.',
                'Write down your application deadlines in your phone calendar.'
            ],
            'training': [
                'Look for a finance or investment club at your school. Attend one meeting if you can.',
                'Open your school’s career centre website. Check when students can apply for finance internships.',
                'Make a spreadsheet comparing two companies and add it to your project folder.'
            ],
            'early': [
                'Look for entry-level finance roles that match the skills you have built.',
                'Practice explaining a company or finance project in an interview.',
                'Ask a supervisor for feedback and work on one skill at a time.'
            ]
        }
    if route_type == 'apprenticeship' or any(word in title for word in ('electrician', 'plumber', 'hvac', 'carpenter', 'mechanic', 'welder', 'boilermaker')):
        return {
            'grade9': [
                'Try a technology or hands-on design class at school.',
                'Ask your guidance counsellor what skilled trades courses your school offers.',
                f'Read a short career profile about what a {job.lower()} does at work.'
            ],
            'grade10': [
                'Ask your guidance counsellor whether your school offers skilled trades courses.',
                'Find the trade on the Skilled Trades Ontario website and read how training works.',
                'Try a supervised school workshop project and record what you learned.'
            ],
            'grade11': [
                'Ask your counsellor if your school offers the Ontario Youth Apprenticeship Program (OYAP).',
                f'Find the {job.lower()} trade on Skilled Trades Ontario. Write down how to start an apprenticeship.',
                'Ask a technology teacher for a supervised project you could try this term.'
            ],
            'grade12': [
                'Ask your guidance counsellor how students at your school apply for OYAP or an apprenticeship.',
                'Check the official trade requirements and the next application dates.',
                'Make a one-page résumé with your school projects and work experience.'
            ],
            'training': [
                'Find out how to register for your trade and connect with an eligible apprenticeship sponsor.',
                'Keep track of your supervised training and required classroom sessions.',
                'Ask your trainer what skill you should practise next.'
            ],
            'early': [
                'Check the certification steps that apply to your trade in Ontario.',
                'Keep a record of the training and work experience you have completed.',
                'Ask experienced coworkers what to learn next.'
            ]
        }
    if any(word in title for word in ('software', 'web developer', 'programmer', 'data scientist', 'cybersecurity')) or industry == 'technology':
        return {
            'grade9': [
                'Try one beginner coding lesson and write a small program.',
                'Change a simple website or app project to make it your own.',
                'Ask your teacher which math and computer courses are offered next year.'
            ],
            'grade10': [
                'Build a basic website or a small game using beginner coding lessons.',
                'Show your project to a friend and fix one thing they find confusing.',
                'Check which Grade 11 math and computer courses are available.'
            ],
            'grade11': [
                'Build a one-page website about a hobby or school club. Show it to a friend.',
                'Open two Ontario computer science program pages. Check which Grade 12 math courses they require.',
                'Save your project. Write two sentences explaining what it does.'
            ],
            'grade12': [
                'Choose two computing programs. Check the official course requirements and deadlines.',
                'Finish one coding project and put it in a portfolio or code repository.',
                'Write a short résumé that includes your project and school activities.'
            ],
            'training': [
                'Finish a small project that solves a problem you care about.',
                'Ask about co-op opportunities in your program and check when applications open.',
                'Keep a portfolio showing what you built and what you improved.'
            ],
            'early': [
                'Apply to roles that match your coding projects and experience.',
                'Practise describing how you solved a problem in your code.',
                'Ask teammates for feedback and improve your next project.'
            ]
        }
    if 'engineer' in title or industry == 'engineering':
        return {
            'grade9': [
                'Build a small bridge or tower from recycled materials. See what makes it strong.',
                'Ask which math and science courses your school offers next year.',
                'Show your design to a teacher and ask what could work better.'
            ],
            'grade10': [
                'Try a simple design project in Tinkercad or a school technology class.',
                'Ask your guidance counsellor which Grade 11 math and science courses to take.',
                'Find one Ontario engineering program and read what students study.'
            ],
            'grade11': [
                'Compare two Ontario engineering programs. Check their Grade 12 math and science requirements.',
                'Design a phone stand or other small object in Tinkercad. Save a picture of it.',
                'Ask your guidance counsellor if your Grade 12 courses match those programs.'
            ],
            'grade12': [
                'Check the required Grade 12 courses and deadlines for two engineering programs.',
                'Save photos of a design project you can describe in an application.',
                'Put university application deadlines in your phone calendar.'
            ],
            'training': [
                'Ask your program’s co-op office when you can apply for placements.',
                'Try a student design team or engineering club if one is available.',
                'Save a short note and photo for each project you finish.'
            ],
            'early': [
                'Check the engineering licensing rules for the province where you want to work.',
                'Apply to jobs that match the projects and experience you have.',
                'Ask an experienced engineer what skills you should build next.'
            ]
        }
    if any(word in title for word in ('nurse', 'physician', 'doctor', 'paramedic', 'pharmacist', 'dentist', 'therapist', 'medical', 'hygienist')) or industry == 'healthcare':
        return {
            'grade9': [
                'Ask your science teacher what healthcare workers learn about the human body.',
                'Look up one healthcare job and write down what a typical shift involves.',
                'Check which science courses your school offers next year.'
            ],
            'grade10': [
                'Choose a healthcare career to research and learn what training it needs.',
                'Ask your guidance counsellor which Grade 11 science courses you can take.',
                'Look for a school or community volunteer activity that involves helping others.'
            ],
            'grade11': [
                'Open two Ontario healthcare program pages. Check which Grade 12 science courses they require.',
                'Ask a local community group whether they have volunteer roles open to students your age.',
                'Ask your guidance counsellor if you should take Grade 12 Biology and Chemistry for those programs.'
            ],
            'grade12': [
                'Check the required Grade 12 courses and deadlines for two relevant programs.',
                'Write down your volunteering and school activities for future applications.',
                'Find out whether your chosen profession has additional licensing or training steps.'
            ],
            'training': [
                'Ask your school when students can apply for required placements.',
                'Keep a record of the skills you practise in classes and supervised placements.',
                'Check the official registration or licensing rules for your profession.'
            ],
            'early': [
                'Check the current registration requirements before applying to practice.',
                'Apply to entry-level roles appropriate to your training and qualifications.',
                'Ask your supervisor which skills you should improve next.'
            ]
        }
    if any(word in title for word in ('police', 'firefighter', 'dispatcher', 'fire prevention')) or industry == 'public safety':
        return {
            'grade9': [
                'Read what a typical workday looks like for this public safety career.',
                'Help with a school or community activity that interests you.',
                'Ask your guidance counsellor what courses could help you explore this field.'
            ],
            'grade10': [
                'Look up how people apply for this job in Ontario.',
                'Volunteer at a community event if there is a suitable role for your age.',
                'Ask a guidance counsellor which school courses may be useful.'
            ],
            'grade11': [
                'Find the official hiring page for this job in Ontario. Note the age and licence requirements.',
                'Volunteer to help organize a school or community event.',
                'Write two questions to ask someone working in this field.'
            ],
            'grade12': [
                'Check the official entry requirements for the service or training program you want.',
                'Keep a record of your school and community involvement.',
                'Ask a guidance counsellor about suitable courses or training after graduation.'
            ],
            'training': [
                'Follow the training and screening rules of the service or program you chose.',
                'Keep a record of completed certifications and supervised experience.',
                'Watch official recruiting pages for new application periods.'
            ],
            'early': [
                'Apply only when you meet the service’s official entry requirements.',
                'Prepare examples of teamwork and responsibility from your experience.',
                'Ask mentors about the training expected in your first year.'
            ]
        }
    if any(word in title for word in ('designer', 'photographer', 'writer', 'artist', 'film', 'producer')) or 'design' in industry or 'media' in industry:
        return {
            'grade9': [
                'Make one small design or writing project on a topic you enjoy.',
                'Ask a teacher or friend what they understood from your work.',
                'Save your finished project in a folder.'
            ],
            'grade10': [
                'Make two projects that show different creative ideas.',
                'Ask for feedback and improve one project.',
                'Save the before and after versions to show your progress.'
            ],
            'grade11': [
                'Save two pieces of your work in a folder. You could use a poster, photo or short story.',
                'Find two Ontario programs in this field. Check whether they ask for a portfolio.',
                'Show your best piece of work to a teacher and ask what to improve.'
            ],
            'grade12': [
                'Check whether your chosen program asks for a portfolio or specific courses.',
                'Choose your best projects and write one sentence about each.',
                'Check the deadlines on the official program website.'
            ],
            'training': [
                'Finish a project that you can show in a portfolio.',
                'Look for student projects or supervised placements in your program.',
                'Ask an instructor for feedback and improve your work.'
            ],
            'early': [
                'Apply to beginner roles and projects that fit your portfolio.',
                'Ask for feedback on one sample of your work.',
                'Replace older portfolio pieces as your skills improve.'
            ]
        }

    if route_type == 'university':
        route_hint = 'university programs'
    elif route_type == 'college':
        route_hint = 'college programs'
    elif route_type == 'apprenticeship':
        route_hint = 'apprenticeship routes'
    else:
        route_hint = 'training routes'
    return {
        'grade9': [
            f'Read what a {job.lower()} does during a normal workday.',
            'Try one school club or beginner project that sounds interesting.',
            'Ask your guidance counsellor what courses are offered next year.'
        ],
        'grade10': [
            f'Find one school project that lets you try a skill used in {job.lower()}.',
            'Show what you made to a teacher and ask for feedback.',
            'Ask which Grade 11 courses will keep your options open.'
        ],
        'grade11': [
            f'Find two Ontario {route_hint} related to {job.lower()}. Write down their Grade 12 or entry requirements.',
            f'Ask a teacher about a class project where you could try one skill used by a {job.lower()}.',
            'Ask your guidance counsellor if your Grade 12 course plan meets those entry requirements.'
        ],
        'grade12': [
            f'Open the official pages for two {route_hint}. Write their application deadlines in your calendar.',
            'Write a one-page résumé that includes your strongest school experiences.',
            'Choose a backup route so you have another option.'
        ],
        'training': [
            'Complete one practical project linked to the work you want.',
            'Look for a student placement or beginner role you can apply for.',
            'Save proof of the skills and projects you complete.'
        ],
        'early': [
            'Look for beginner roles that match the training you completed.',
            'Practise explaining what you have learned from a project or job.',
            'Ask someone in the field what skill matters most at this stage.'
        ]
    }


def build_career_roadmap(career: dict, grade: str, route_key: str, programs: list[dict] | None = None) -> dict:
    """Plan anchored to existing career data, not fabricated program prerequisites."""
    routes = route_choices(career)
    chosen = next((r for r in routes if r['key'] == route_key), None)
    if not chosen:
        raise ValueError('Invalid education route for this career')
    subjects = [str(s).strip() for s in (career.get('school_subjects') or []) if str(s).strip()][:4]
    skills = [str(s).strip() for s in (career.get('skills') or []) if str(s).strip()][:3]
    name = career['title']
    steps = _practical_steps(career, chosen)
    stages = [
        ('grade9', 'Grade 9', 'Try something new.'),
        ('grade10', 'Grade 10', 'Build your skills.'),
        ('grade11', 'Grade 11', 'Check real options.'),
        ('grade12', 'Grade 12', 'Get ready to apply.'),
        ('training', 'After high school', 'Learn through real experience.'),
        ('early', 'Early career', 'Start working and keep learning.'),
    ]
    phases = [
        {'id': key, 'label': label, 'subtitle': subtitle, 'steps': steps[key]}
        for key, label, subtitle in stages
    ]
    focus = min(grade_index(grade), 4)
    for idx, phase in enumerate(phases):
        phase['state'] = 'now' if idx == focus else ('past' if idx < focus else 'future')

    related = []
    for program in programs or []:
        # These are options to explore. A matching program is not automatically required for the job.
        if program.get('status') != 'verified':
            continue
        related.append({'id':program['id'], 'title':program['title'], 'university':program.get('university') or '',
                        'requirements':(program.get('requirements') or [])[:4],
                        'source_url':program.get('requirements_source_url') or program.get('source_url'),
                        'verified_date':program.get('requirements_last_verified_date') or program.get('last_verified_date'),
                        'status':program.get('status')})
        if len(related) >= 5:
            break
    return {'career':{'id':career['id'],'title':name,'industry':career.get('industry') or '',
                      'education':career.get('education') or '', 'source_url':career.get('source_url'),
                      'last_verified_date':career.get('last_verified_date')},
            'grade':grade,'focus_index':focus,'route':chosen,'routes':routes,
            'phases':phases,'suggested_subjects':subjects,'suggested_skills':skills,
            'related_programs':related, 'region':'Ontario, Canada',
            'disclaimer':'This plan is a guide. Admission and employment are not guaranteed. Check courses, costs and deadlines with official sources.'}


def starting_tasks(roadmap: dict) -> list[tuple[str,str,int]]:
    """Five manageable, actionable tasks from the student's current stage."""
    index = roadmap['focus_index']
    stages = roadmap['phases']
    tasks = [(title, stages[index]['label'], 1) for title in stages[index]['steps']]
    if index < len(stages)-1:
        tasks.extend((title, stages[index+1]['label'], 2) for title in stages[index+1]['steps'][:2])
    return tasks[:5]
