# Pathway V27 — Discovery and launch polish

This build continues the V26 backend and core planning tools.

## Changes
- A simpler home screen with one main Career Match quiz. Extra tools are optional.
- Shorter quiz prompts and clearer selected choices. Ten adaptive questions.
- Show only three career matches first. Students can reveal the remaining two, expand job information, or open a career profile.
- Compare two or three careers side by side. Comparison is accessible from match cards and career profiles.
- Added 24 lesser-known careers (189 careers total). An optional "different idea" result encourages discovery beyond the top five.
- Added "Day in the Life" to career details. These are illustrative everyday tasks based on recorded descriptions; not verified reports from individual employees.
- Added study-abroad research for the U.S., U.K., Germany and Australia with direct official program search and funding resources. These links are starting points. Overseas admission requirements, individual scholarship eligibility and full degree offerings are not verified by Pathway.
- Updated cards, micro-animations, and mobile layout. Reduced-motion preference is respected.

## Important labels
- Ontario salary benchmarks are Canadian regional estimates. New niche roles can use a related occupation-group benchmark, which is disclosed on each record.
- The match quiz is a heuristic exploration tool, not a guarantee or objective probability.
- Ontario admission/prerequisite data must be separately checked on the linked institution website before applying.

## Validation
- 10 backend/feature test cases passed (Python pytest).
- JavaScript syntax: `node --check static/app.js` passed.
- Mobile Chromium smoke tests with real catalog responses: home, landing, quiz, results, compare, international research, and career details at 320px and 390px. No JavaScript errors or horizontal overflow in these checks.

## Before public launch
- Test signup, email verification, login/reset, saves and account deletion on the real production environment.
- Confirm persistent database/backup, mail provider, privacy/legal copy and access restrictions.
- Reverify volatile university, career wage and scholarship information. Get teen usability feedback on actual iPhones.
- Do not claim the product is available on the App Store until Apple has reviewed and approved the iOS version.
