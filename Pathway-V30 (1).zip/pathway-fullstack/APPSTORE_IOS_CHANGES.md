# iOS App Store build changes

- Added `ios-app/` with an iOS-only Capacitor 8 setup. No Android project/dependency is included.
- Added iPhone safe-area CSS and `viewport-fit=cover`.
- Added native-aware haptics for important taps.
- Added an iOS-only Share Career action that uses the native share sheet when available.
- Added status-bar setup for the iOS shell.
- Kept the production web/backend code and annual-pay changes intact.

The actual `.ipa`/App Store archive must be generated on macOS with Xcode because Apple requires Xcode signing and App Store credentials.
