# Pathway V17 — Unified Dark Navy Theme

- Replaced the near-black UI with a dark navy base.
- Unified quiz, cards, route boxes, result cards, modals, program cards, college cards, and plan surfaces into one navy colour family.
- Kept brighter navy selected states so choices remain obvious.
- Preserved electric indigo and cyan accents for buttons, progress, and interaction feedback.
- Removed leftover white surfaces from older UI versions.
- Kept mobile styling and accessibility/reduced-motion behavior intact.
