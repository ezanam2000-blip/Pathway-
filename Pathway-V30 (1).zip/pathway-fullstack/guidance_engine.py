"""Conservative Canada/Ontario guidance: no invented prerequisites or admission predictions.

The course mapping is a structured transcription of explicitly listed course codes
from Pathway's official-source-linked program records; the app shows the source/date
and instructs users to verify the current program page before acting.
"""
from __future__ import annotations
from typing import Any
import re

COURSE_NAMES = {
    'ENG4U': 'Grade 12 University English',
    'MHF4U': 'Advanced Functions',
    'MCV4U': 'Calculus and Vectors',
    'MDM4U': 'Mathematics of Data Management',
    'SBI4U': 'Biology',
    'SCH4U': 'Chemistry',
    'SPH4U': 'Physics',
    'ICS4U': 'Computer Science',
    'HHS4U': 'Families in Canada',
}

# Only mapped where official-source-linked records in the catalog explicitly
# name the specific course. Missing any other requirement must be reviewed manually.
COURSE_RULES = {
    'prog-ivey': {'all': [], 'one_of': [], 'note': 'Ivey AEO has a separate supplemental and requires university-bound mathematics. The exact course options and Western admission requirements require manual review.'},
    'prog-rotman': {'all': ['ENG4U', 'MCV4U'], 'one_of': [], 'note': 'Six 4U/M courses and the supplemental are also required. Grades here do not predict selection.'},
    'prog-smith': {'all': ['ENG4U', 'MCV4U'], 'one_of': [['MHF4U', 'MDM4U']], 'minimums': {'ENG4U': 80, 'MCV4U': 80}, 'note': 'The third prerequisite must be an accepted additional 4U mathematics course, each prerequisite needs at least 80%, and a supplemental is required. Check the official list of accepted math courses.'},
    'prog-utoronto-healthbio': {'all':['ENG4U','MHF4U','SBI4U','SCH4U'],'one_of':[], 'note':'Six Grade 12 U/M courses are required and MCV4U is recommended, not listed as required. Confirm the current requirements.'},
    'prog-utoronto-cs': {'all': ['ENG4U', 'MCV4U'], 'one_of': [], 'note': 'Six 4U/M credits and a separate supplemental are also required.'},
    'prog-utoronto-compeng': {'all': ['ENG4U', 'MHF4U', 'MCV4U', 'SPH4U', 'SCH4U'], 'one_of': [], 'note': 'Engineering also requires its applicant profile and other published admission conditions.'},
    'prog-waterloo-mech': {'all': ['ENG4U', 'MHF4U', 'MCV4U', 'SPH4U', 'SCH4U'], 'one_of': [], 'minimums': {'ENG4U':70, 'MHF4U':70, 'MCV4U':70, 'SPH4U':70, 'SCH4U':70}, 'note': 'Waterloo Engineering also uses supplemental materials and competitive selection.'},
}

def check_program(program: dict[str, Any], courses: list[dict[str, Any]]) -> dict[str, Any]:
    recorded = {str(c['code']).upper(): c.get('grade') for c in courses}
    rules = COURSE_RULES.get(program['id'])
    requirements = program.get('requirements') or []
    result = {
        'id': program['id'], 'title': program['title'], 'university': program['university'],
        'official_requirements': requirements, 'source_url': program.get('requirements_source_url') or program.get('source_url'),
        'last_verified_date': program.get('requirements_last_verified_date'),
        'tuition': program.get('tuition') or None, 'deadline': program.get('deadline') or None,
        'missing': [], 'present': [], 'below_minimum': [], 'alternatives': [],
        'status': 'manual_review', 'note': 'The listed requirements must be checked with the official program before applying.'
    }
    if rules is None:
        result['note'] = 'This program does not yet have a structured prerequisite mapping. Review its linked admission requirements manually.'
        return result
    result['note'] = rules.get('note', result['note'])
    minimums = rules.get('minimums', {})
    for code in rules.get('all', []):
        if code not in recorded:
            result['missing'].append(code)
        else:
            result['present'].append(code)
            minimum = minimums.get(code)
            if minimum is not None and recorded[code] is not None and recorded[code] < minimum:
                result['below_minimum'].append({'code': code, 'minimum': minimum, 'grade': recorded[code]})
    for group in rules.get('one_of', []):
        matched = [code for code in group if code in recorded and code not in rules.get('all', [])]
        if matched:
            result['present'].extend(matched[:1])
            minimum = 80 if program['id'] == 'prog-smith' else None
            for code in matched[:1]:
                if minimum is not None and recorded[code] is not None and recorded[code] < minimum:
                    result['below_minimum'].append({'code':code,'minimum':minimum,'grade':recorded[code]})
        else:
            result['alternatives'].append(group)
    # Status deliberately says only 'recorded prerequisite courses present'. This is
    # never an admission decision, and all non-course conditions remain unverified.
    if result['below_minimum']:
        result['status'] = 'below_listed_minimum'
    elif result['missing'] or result['alternatives']:
        result['status'] = 'courses_to_review'
    elif rules['all'] or rules.get('one_of'):
        result['status'] = 'listed_courses_present'
    return result


def supporting_career_facts(career: dict[str, Any]) -> dict[str, Any]:
    return {k:career.get(k) for k in ('id','title','industry','education','day_to_day','hours',
      'pay_range','salary_region','salary_source_url','salary_last_verified_date',
      'outlook','outlook_region','outlook_source_url','outlook_last_verified_date',
      'work_environment','route_options','source_url','skills','school_subjects','competitiveness')}


def advisor_evidence(question: str, careers: list[dict[str, Any]], programs: list[dict[str, Any]], career_id: str | None, program_id: str | None) -> dict[str, Any]:
    words = [w.lower() for w in re.findall(r'[\w]+', question) if len(w)>3]
    def relevance(record):
        title = (record.get('title') or '').lower()
        haystack = ' '.join([record.get('title',''),record.get('industry',''),record.get('field',''),record.get('university',''), ' '.join(record.get('tags') or [])]).lower()
        return (25 if (career_id or program_id) == record.get('id') else 0) + sum(5 if w in title else 1 if w in haystack else 0 for w in words)
    cs = sorted(careers, key=relevance, reverse=True)
    ps = sorted(programs, key=relevance, reverse=True)
    cs = [x for x in cs if relevance(x)>0][:2]
    ps = [x for x in ps if relevance(x)>0][:3]
    return {'careers':[supporting_career_facts(x) for x in cs], 'programs':[{k:p.get(k) for k in ('id','title','university','description','requirements','deadline','tuition','requirements_source_url','requirements_last_verified_date','source_url','supplemental')} for p in ps]}


def fallback_advice(evidence: dict[str, Any]) -> str:
    careers=evidence['careers'];programs=evidence['programs']
    if not careers and not programs:
        return 'I could not find reliable matching information in Pathway yet. Try naming a specific career or Ontario program, then confirm the details with its official source.'
    parts=['Here is what Pathway can confirm from its current records:']
    for c in careers:
        parts.append(f"{c['title']}: {c.get('education') or 'Training depends on the route.'} The daily work: {c.get('day_to_day') or 'Check the career profile.'}")
    for p in programs:
        req='; '.join((p.get('requirements') or [])[:3])
        parts.append(f"{p['title']} ({p['university']}): {req or 'See the official admission page.'}")
    parts.append('What to do next: compare the exact course prerequisites, read the official admissions or training source, and choose one relevant experience to try. This is guidance, not an admissions or earnings guarantee.')
    return '\n\n'.join(parts)
