# Pathway V30 — Career discovery and international research

This package builds on the current V27 discovery interface and keeps the specific student roadmaps from V29.

## What changed

- 28 additional careers. The API now returns 217 unique career titles.
- A project-choice question connects interests such as sports, games and climate with less obvious careers. Match explanations show the choices that contributed to each result.
- Shorter quiz prompts, visual choice cards, selected states, keyboard focus and small tap animations. There is still one ten-question Career Match quiz.
- Three matches appear first. Users can reveal two more, compare careers or open a profile. A different idea appears when another relevant niche career is available.
- A Day in the Life section uses complete activities and a short reality check. New profiles include role-specific examples. Other profiles use the existing task and workplace descriptions.
- Two or three careers can be compared in aligned table rows. The comparison scrolls sideways on a phone. Unexpected suggestions also work in guest comparison and detail views.
- Study research covers the U.S., U.K., Germany, Australia, the Netherlands, Japan, South Korea and Canada. Users choose a subject, a destination and either a full degree or an exchange.
- International funding includes official research portals and five named scholarship routes. Award details stay collapsed. The listed 2026 UCL deadline is clearly marked as passed. Award listings do not claim that applications are open or that a user qualifies.
- The Scholarships page links directly to international funding research.
- Career search keeps the cursor after a render. Quiz loading guards prevent repeated submissions and changes during submission.

## Content boundaries

Job examples are illustrative editorial copy, not worker interviews. Niche pay references use related Ontario occupation groups. They are not measured salaries for each niche title. Pay is shown in Canadian dollars.

Career discovery can be used broadly. Verified international salary data, country-specific professional licensing and overseas admission checking are not added in this release. The existing course checker and specific school roadmaps still focus on Ontario. Country research points users to official sources. No nationality or scholarship eligibility is inferred from where someone lives.

## Validation

- 13 backend and roadmap tests passed, including account flows, existing finance/trades/public-safety matching, new curiosity matching and duplicate-answer handling.
- JavaScript syntax checks passed for both scripts.
- Frontend behavior checks passed for adaptive quiz navigation, compact results, optional deeper results, guest details, three-career comparison limits, country/award navigation and loading guards.
- Visual browser and real-device QA were not completed in this environment. Test layout, touch controls, screen reader use and long titles on actual phones before launch.
- Production database migration, production email, Render deployment and App Store submission were not performed.

## Apply this package

Use all files in `pathway-fullstack/`, including the new `discovery_profiles.py` and `static/international.js`. The existing Dockerfile copies both. The page loads both scripts with version 30 cache keys.

Run `python -m pytest -q` and `node tests/frontend_discovery.cjs` from the project directory to repeat the checks. Keep production secrets and stored data outside the source archive.
