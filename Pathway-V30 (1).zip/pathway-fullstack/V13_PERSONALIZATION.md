# V13 personalization update

- Career Match reduced to 10 concise questions.
- The next question changes based on earlier choices.
- Added deeper branches for finance, college, skilled trades, and public safety.
- Career Match now returns the top 5 matches instead of 5–8 mixed results.
- Added Police Officer, Firefighter, Paramedic, Emergency Services Dispatcher, and Fire Prevention Inspector.
- Expanded trade routes for Electrician, Plumber, and HVAC / Refrigeration Mechanic with Ontario entry/training context.
- Added concise career snapshot: education/training, grades/entry, what the work looks like, and where the path can lead.
- Route cards can show requirements and an official requirements source.
- Career pages show only 5 closest alternative careers.
- Homepage and quiz wording shortened to reduce information overload.
- App version 5.2.0.
