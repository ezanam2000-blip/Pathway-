# V19 iPhone layout fix

- Fixed an animated career strip forcing the homepage grid to be wider than an iPhone viewport.
- Unified white feature cards, quiz panels, navigation controls and other legacy light surfaces with the dark navy colour system.
- Set browser theme metadata to dark navy (where mobile Safari supports it).
- Kept all backend features and existing project files unchanged.

Validated in a headless mobile browser at 320, 360, 375, 390, 430, 600, 768, 820, 1024 px: no page horizontal overflow. Career Quiz screen, answer selection and advancing to question 2 were tested. Python tests: 7 passed. JavaScript syntax check: passed.
