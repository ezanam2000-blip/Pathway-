"""The first step shown on a student's screen must name a doable action."""
from roadmap_engine import build_career_roadmap


def _roadmap(title, industry, route='university', grade='Grade 11'):
    career = {'id':title.lower().replace(' ', '-'),'title':title,'industry':industry,
              'school_subjects':['Math'],'skills':['Communication'],
              'route_options':[{'type':route, 'name':route.title()}]}
    r = build_career_roadmap(career, grade, route)
    return r['phases'][r['focus_index']]['steps']


def test_grade_11_students_get_concrete_first_steps():
    cases = [
        ('Investment Banking','Finance','university','Rotman Commerce'),
        ('Electrician','Trades','apprenticeship','OYAP'),
        ('Software Engineering','Technology','university','website'),
        ('Civil Engineer','Engineering','university','engineering programs'),
        ('Registered Nurse','Healthcare','university','science courses'),
        ('Police Officer','Public Safety','work_first','hiring page'),
        ('Graphic Designer','Creative','portfolio','two pieces'),
    ]
    for title, industry, route, phrase in cases:
        steps = _roadmap(title,industry,route)
        assert len(steps) == 3
        assert phrase.lower() in steps[0].lower() or any(phrase.lower() in t.lower() for t in steps)
        assert all(t.endswith('.') and len(t) < 170 for t in steps)


def test_steps_change_by_grade_in_familiar_language():
    for title,industry,route in [('Investment Banking','Finance','university'),('Civil Engineer','Engineering','university'),('Electrician','Trades','apprenticeship')]:
        earlier = _roadmap(title,industry,route,'Grade 9')
        later = _roadmap(title,industry,route,'Grade 12')
        assert earlier[0] != later[0]
