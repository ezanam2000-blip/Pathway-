// Behaviour checks for the renderer and event handlers. Run from the project root.
// These do not replace visual testing on a real phone.
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const element = {innerHTML:''};
const ctx = vm.createContext({console, setTimeout:()=>0, window:{scrollTo(){}},
 document:{addEventListener(){},activeElement:null,getElementById:()=>element,querySelector:()=>null,querySelectorAll:()=>[],body:{insertAdjacentHTML(){}}}});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../static/international.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../static/app.js'),'utf8').replace('configureIOSApp().finally(()=>bootstrap());',''),ctx);
ctx.assert=assert;
vm.runInContext(`
const fixture=Array.from({length:6},(_,i)=>({type:'career',id:'c'+i,title:'Career '+i,industry:'Technology',description:'Build useful tools.',quiz_reason:'Matches your selected interests.',quiz_score:10-i,day_in_life:{activities:['Test a tool.'],reality:'Expect revisions.'},pay_range:'$40,000–$80,000/year; median $60,000/year'}));
state.content=fixture;state.user=null;startCareerQuiz();
toggleQuiz('interest:technology');nextQuiz();toggleQuiz('route:university');nextQuiz();
assert.equal(currentQuizQuestion().title,'Which problem sounds fun?');
toggleQuiz('focus:code');nextQuiz();toggleQuiz('style:data');nextQuiz();
toggleQuiz('income:balanced');nextQuiz();toggleQuiz('balance:some');nextQuiz();
toggleQuiz('value:challenge');nextQuiz();
assert.equal(currentQuizQuestion().id,'curiosity');assert.ok(careerQuiz().includes('Investigate a mystery'));
toggleQuiz('curiosity:games');nextQuiz();toggleQuiz('future:specialist');nextQuiz();toggleQuiz('style:data');
state.quizResults=fixture.slice(0,5);state.quizDiscoveryPick=fixture[5];state.quizStep=QUIZ_QUESTIONS.length;
assert.equal((careerQuiz().match(/class="v27-match-card"/g)||[]).length,3);
state.showAllMatches=true;assert.equal((careerQuiz().match(/class="v27-match-card"/g)||[]).length,5);
state.content=[];toggleCompare('c0');toggleCompare('c1');toggleCompare('c5');
assert.equal(allCompareCareers().length,3);assert.ok(comparisonPage().includes('scope="row"'));
openDetail('career','c5');assert.equal(state.detail.id,'c5');
toggleCompare('c2');assert.equal(state.compareIds.length,3);assert.ok(state.toast.includes('three'));
state.abroadCountry='Netherlands';state.abroadTab='funding';assert.ok(studyAbroad().includes('NL Scholarship'));
state.abroadCountry='United Kingdom';assert.ok(studyAbroad().includes('2026 deadline has passed'));
state.abroadTab='study';state.abroadMode='exchange';assert.ok(studyAbroad().includes('credits count'));
state.abroadMode='degree';state.abroadField='Business';assert.ok(studyAbroad().includes('Accounting and Finance'));
state.content=fixture;state.category='Unexpected Path';assert.equal(filteredCareers().length,0);
state.content[0].tags=['Unexpected Path'];assert.equal(filteredCareers().length,1);
state.quizStep=0;state.quizAnswersByStep={0:['interest:technology'],1:['route:university'],2:['focus:code']};
toggleQuiz('interest:science');assert.equal(state.quizAnswersByStep[2],undefined);
state.quizLoading=true;const before=JSON.stringify(state.quizAnswersByStep);toggleQuiz('interest:finance');nextQuiz();
assert.equal(JSON.stringify(state.quizAnswersByStep),before);
`, ctx);
console.log('Frontend discovery behaviour checks passed.');
