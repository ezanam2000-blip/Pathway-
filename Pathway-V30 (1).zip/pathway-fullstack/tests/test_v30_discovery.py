import importlib
import os


def test_curiosity_changes_discovery_and_profiles_are_compact(tmp_path):
    os.environ.pop('DATABASE_URL', None)
    os.environ['PATHWAY_DB_PATH'] = str(tmp_path/'app.db')
    os.environ['PATHWAY_OUTBOX_PATH'] = str(tmp_path/'outbox')
    from fastapi.testclient import TestClient
    import app
    importlib.reload(app)
    with TestClient(app.app) as client:
        careers = client.get('/api/content?type=career').json()['items']
        assert len(careers) >= 210
        assert len({c['title'].lower() for c in careers}) == len(careers)
        by_title = {c['title']: c for c in careers}
        for title in ('Game Economy Designer', 'Human Factors Specialist', 'Carbon Accounting Analyst', 'Music Metadata Specialist'):
            career = by_title[title]
            assert len(career['day_in_life']['activities']) == 3
            assert career['day_in_life']['reality']
            assert 'occupation group' in career['pay_note']
        answers = ['interest:open','route:open','output:technical','style:data','income:balanced','balance:some','value:challenge','future:specialist']
        sports = client.post('/api/career-quiz', json={'answers':answers+['curiosity:sports']}).json()
        climate = client.post('/api/career-quiz', json={'answers':answers+['curiosity:climate']}).json()
        assert {c['id'] for c in sports['items']} != {c['id'] for c in climate['items']}
        for response in (sports, climate):
            assert len(response['items']) == 5
            if response['discovery_pick']:
                assert response['discovery_pick']['id'] not in {c['id'] for c in response['items']}
                assert 'Unexpected Path' in response['discovery_pick']['tags']
        assert any('sports' in c['quiz_matches'] for c in sports['items'])
        assert any('environmental problems' in c['quiz_matches'] for c in climate['items'])
        # Repeated tokens cannot inflate the score or alter ordering.
        repeat = client.post('/api/career-quiz', json={'answers':answers+['curiosity:sports']*3}).json()
        assert [(c['id'],c['quiz_score']) for c in repeat['items']] == [(c['id'],c['quiz_score']) for c in sports['items']]
        profile = client.get('/api/content?type=career').json()['items'][0]
        assert profile['day_in_life']['basis'].startswith('Illustrative')
