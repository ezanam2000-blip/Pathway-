"""V20: real selectable, grade-aware, persisted roadmaps."""
import importlib
import os
import tempfile
from pathlib import Path


def test_roadmaps_preview_save_and_progress():
    tmp=tempfile.NamedTemporaryFile(suffix='.db', delete=False);tmp.close()
    os.environ.pop('DATABASE_URL',None)
    os.environ['PATHWAY_DB_PATH']=tmp.name
    os.environ['PATHWAY_OUTBOX_PATH']=tmp.name+'.outbox'
    os.environ['PATHWAY_BASE_URL']='http://testserver'
    try:
        from fastapi.testclient import TestClient
        import app as a
        importlib.reload(a)
        with TestClient(a.app) as client:
            careers=client.get('/api/content?type=career').json()['items']
            ib=next(c for c in careers if c['title']=='Investment Banking')
            electrician=next(c for c in careers if c['title']=='Electrician')
            for item, route in ((ib,'university'),(electrician,'apprenticeship')):
                preview=client.get('/api/roadmaps/preview',params={'career_id':item['id'],'grade':'Grade 11','route_key':route})
                assert preview.status_code==200, preview.text
                plan=preview.json()
                assert plan['focus_index']==2
                assert [p['label'] for p in plan['phases']]==['Grade 9','Grade 10','Grade 11','Grade 12','After high school','Early career']
                assert plan['phases'][2]['state']=='now'
                assert plan['region']=='Ontario, Canada'
                assert plan['route']['key']==route
                assert plan['suggested_subjects']
                assert all(p['source_url'] for p in plan['related_programs'])
            assert client.get('/api/roadmaps/preview',params={'career_id':ib['id'],'grade':'Grade 11','route_key':'apprenticeship'}).status_code==422
            assert client.get('/api/roadmaps/preview',params={'career_id':'invalid','grade':'Grade 11','route_key':'university'}).status_code==404
            assert client.get('/api/roadmaps/mine').status_code==401
            assert client.post('/api/roadmaps/save',json={'career_id':ib['id'],'grade':'Grade 11','route_key':'university'}).status_code==401

            signed=client.post('/api/auth/signup',json={'name':'Test Student','email':'roadmap@example.com','password':'securePassword123'})
            assert signed.status_code==201, signed.text
            result=client.post('/api/roadmaps/save',json={'career_id':ib['id'],'grade':'Grade 11','route_key':'university'})
            assert result.status_code==201,result.text
            assert result.json()['tasks']==5
            assert client.get('/api/roadmaps/mine').json()['roadmap']['career']['id']==ib['id']
            tasks=[x for x in client.get('/api/plan/tasks').json()['items'] if x['item_id']==ib['id']]
            assert len(tasks)==5
            first=tasks[0]
            assert client.patch(f'/api/plan/tasks/{first["id"]}',json={'completed':True}).status_code==200
            assert client.post('/api/roadmaps/save',json={'career_id':ib['id'],'grade':'Grade 11','route_key':'university'}).status_code==201
            tasks=client.get('/api/plan/tasks').json()['items']
            assert sum(t['completed'] for t in tasks if t['item_id']==ib['id'])==1
            assert client.post('/api/roadmaps/save',json={'career_id':ib['id'],'grade':'Grade 12','route_key':'university'}).status_code==201
            tasks=client.get('/api/plan/tasks').json()['items']
            assert len([t for t in tasks if t['item_id']==ib['id']])==5
            assert not any(t['completed'] for t in tasks if t['item_id']==ib['id'])
            result=client.post('/api/roadmaps/save',json={'career_id':electrician['id'],'grade':'Grade 10','route_key':'apprenticeship'})
            assert result.status_code==201,result.text
            assert client.get('/api/roadmaps/mine').json()['roadmap']['career']['id']==electrician['id']
            assert len([t for t in client.get('/api/saved').json()['items'] if t['item_id']==electrician['id']])==1
        js=(Path(a.ROOT)/'static'/'app.js').read_text()
        assert 'openRoadmap' in js and 'roadmapHomeBlock()' in js and 'myRoadmapBlock()' in js
        assert '/api/roadmaps/save' in js
    finally:
        Path(tmp.name).unlink(missing_ok=True)
        Path(tmp.name+'.outbox').unlink(missing_ok=True)
