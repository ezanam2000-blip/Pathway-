import importlib
import os
import tempfile


def test_v11_broader_routes_and_annual_pay():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False); tmp.close()
    os.environ["PATHWAY_DB_PATH"] = tmp.name
    os.environ["PATHWAY_OUTBOX_PATH"] = tmp.name + ".outbox"
    os.environ["PATHWAY_BASE_URL"] = "http://testserver"
    os.environ.pop("DATABASE_URL", None)
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)
        with TestClient(app_module.app) as client:
            careers = client.get("/api/content?type=career").json()["items"]
            assert len(careers) >= 160
            by_title = {c["title"]: c for c in careers}
            for title in [
                "Web Developer", "Graphic Designer", "Automotive Service Technician",
                "HVAC / Refrigeration Mechanic", "Welder", "Carpenter", "Chef",
                "Hairstylist / Barber", "Flight Attendant", "Paralegal",
                "Dental Assistant", "Respiratory Therapist",
                "Diagnostic Medical Sonographer", "Early Childhood Educator",
                "Insurance Agent / Broker",
            ]:
                assert title in by_title
                assert by_title[title]["route_options"]
                assert "/year" in by_title[title]["pay_range"]
                assert "/hour" not in by_title[title]["pay_range"]

            results = client.post("/api/career-quiz", json={"answers":[
                "interest:skilled_trades", "environment:hands_on", "income:balanced",
                "education:college", "route:apprenticeship", "balance:some",
                "entrepreneurship:maybe", "value:stability", "style:hands_on",
                "pace:variety", "output:practical", "focus:repair",
            ]}).json()["items"]
            assert 5 <= len(results) <= 8
            top_titles = {x["title"] for x in results[:4]}
            assert top_titles.intersection({"Electrician", "Automotive Service Technician", "Welder", "Carpenter", "HVAC / Refrigeration Mechanic"})
    finally:
        for path in [tmp.name, tmp.name + ".outbox"]:
            try: os.unlink(path)
            except FileNotFoundError: pass
