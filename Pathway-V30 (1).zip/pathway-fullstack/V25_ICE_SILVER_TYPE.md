# V25: brighter silver-blue typography

Visual-only update: no changes to route, data or API logic.

- Base navy/indigo palette remains unchanged.
- Headings stay near-white; supporting copy uses luminous ice-silver (#D9E5FF),
  small labels use soft silver-lilac (#C1D3F7), and interactive source links
  use cool cyan-silver (#B9EDFF).
- Applied across homepage, quiz, career detail, roadmap, compare, admissions,
  dashboard, advisor, mobile nav, form hints, and profile surfaces.
- Improved placeholder visibility on iPhone.
- The stylesheet version is bumped to 25 so previously cached grey text styling
  does not persist after deployment.
