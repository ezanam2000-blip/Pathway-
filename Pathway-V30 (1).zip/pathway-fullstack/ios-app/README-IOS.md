# Pathway iOS — App Store only

This folder is intentionally iOS-only. There is no Android/Google Play project.

## Already wired in
- Capacitor iOS shell for the existing Pathway production app
- iPhone safe-area support
- native haptic feedback on important taps
- native iOS Share Sheet on career pages
- native status-bar handling
- existing Pathway login stays on the same HTTPS origin

## Build on a Mac
Requirements: macOS, Xcode 26+, Node.js 22+.

```bash
cd pathway-fullstack/ios-app
npm install
npm run ios:add
npm run ios:sync
npm run ios:open
```

In Xcode:
1. Select the App target.
2. Signing & Capabilities -> choose the Apple Developer team that legally owns the app.
3. Keep Bundle Identifier `com.pathwaycareers.app` if Apple accepts it, otherwise choose a unique identifier and update `capacitor.config.ts` too.
4. Set Deployment Target to iOS 15.0 or later (Capacitor 8 requirement).
5. Set Version to 1.0 and Build to 1.
6. Add the final AppIcon assets.
7. Run on a real iPhone and test sign-up, login, Career Match, Save Career, My Path, and Share Career.
8. Product -> Archive -> Distribute App -> App Store Connect.

Before App Review, complete App Store Connect privacy details, age rating, screenshots, support URL, privacy-policy URL, and review notes. Do not submit until the production database and email verification are ready.
