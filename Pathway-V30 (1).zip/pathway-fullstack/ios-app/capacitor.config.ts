import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.pathwaycareers.app',
  appName: 'Pathway',
  webDir: 'www',
  server: {
    url: 'https://pathway-v8.onrender.com',
    cleartext: false
  },
  ios: {
    contentInset: 'automatic',
    preferredContentMode: 'mobile'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 900,
      launchAutoHide: true,
      backgroundColor: '#F7F7FB',
      showSpinner: false
    }
  }
};

export default config;
