# V20 — Grade-aware career roadmaps

## What works

- Anonymous previews of a career roadmap for Grade 9, 10, 11, 12, and post-secondary.
- Route selector only presents routes that exist in the career's data; trade and university requirements are not invented.
- Roadmaps show **your current grade first**, with earlier grades collapsible, then remaining grades, education/training, and early career.
- Tasks are saved for signed-in users in the existing My Plan checklist. Task completion remains when the same roadmap is reopened. Changing the selected grade or route replaces roadmap-generated tasks for that career (and only those tasks).
- Active saved roadmap, milestone timeline, and current task appear on Home/My Plan. Other saved careers, applications, and checklists remain intact.
- Related university programs are included only when Pathway already explicitly maps a career to that program and the program has verified status, with a verification date and official link where available.
- iPhone modal design tested for 320, 375, 390, 430, and 768px widths with no horizontal scrolling.
- Render-compatible ZIP remains `Pathway-V8 (1).zip`, unpacked by the existing build command.

## Limitations and trust

Roadmaps are **guidance, not predictions or admission determinations**. Career `school_subjects` are recommendations rather than program prerequisites. Exact academic prerequisites, competitive averages, tuition, training and registration conditions, and deadlines must be verified on the official institution or Skilled Trades Ontario source. Career catalog coverage varies; a linked program is related, not necessarily a requirement or sufficient credential for that career. There is no live applications/requirements checker yet.

## API

- `GET /api/roadmaps/preview?career_id=...&grade=Grade+11&route_key=university` — public preview.
- `GET /api/roadmaps/mine` — signed-in active roadmap.
- `POST /api/roadmaps/save` — signed-in selection and five starter tasks.

Tests: `python -m pytest -q`; JS syntax: `node --check static/app.js`.
