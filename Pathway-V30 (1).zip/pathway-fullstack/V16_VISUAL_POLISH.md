# Pathway V16 visual polish

- Black-first teen-focused visual system retained.
- Added animated gradient headline and subtle ambient motion.
- Added career path marquee to the cover screen.
- Added stronger CTA treatment and hover/focus feedback.
- Added icons to quiz choices and animated question transitions.
- Added staggered result-card motion.
- Added reduced-motion support for accessibility.
- Copy remains concise.
