# Pathway V14

- Fixed the home Programs route that referenced missing university helper functions.
- Added working University and College & Practical Routes entry points on Home.
- Added a combined Universities & College Routes explorer with tabs.
- College tab uses real career route data instead of inventing school-specific programs.
- Updated concise navigation copy and app version to 5.3.0.
