"""V21-V24 features: conservative prerequisites, source-backed mentor, UI hooks."""
import importlib
import os
import tempfile
from pathlib import Path


def test_v24_courses_advisor_and_ui():
    tmp=tempfile.NamedTemporaryFile(suffix='.db',delete=False)
    tmp.close()
    os.environ.pop('DATABASE_URL',None)
    os.environ.pop('OPENAI_API_KEY',None)
    os.environ['PATHWAY_DB_PATH']=tmp.name
    os.environ['PATHWAY_OUTBOX_PATH']=tmp.name+'.outbox'
    os.environ['PATHWAY_BASE_URL']='http://testserver'
    try:
        from fastapi.testclient import TestClient
        import app as a
        importlib.reload(a)
        with TestClient(a.app) as c:
            health=c.get('/api/health')
            assert health.status_code==200 and health.json()['version']=='6.2.0'
            guest=c.post('/api/admissions/check',json={'courses':[{'code':'ENG4U','grade':93},{'code':'MCV4U','grade':89}]})
            assert guest.status_code==200, guest.text
            programs={x['id']:x for x in guest.json()['items']}
            assert programs['prog-rotman']['status']=='listed_courses_present'
            assert 'admission' in programs['prog-rotman']['note'].lower() or 'supplemental' in programs['prog-rotman']['note'].lower()
            assert programs['prog-rotman']['source_url'].startswith('https://')
            assert 'MHF4U' in programs['prog-utoronto-compeng']['missing']
            assert 'SBI4U' in programs['prog-utoronto-healthbio']['missing']
            assert programs['prog-ivey']['status']=='manual_review'
            low=c.post('/api/admissions/check',json={'courses':[{'code':'ENG4U','grade':75},{'code':'MCV4U','grade':95},{'code':'MHF4U','grade':92}]})
            smith=next(x for x in low.json()['items'] if x['id']=='prog-smith')
            assert smith['status']=='below_listed_minimum'
            assert any(x['code']=='ENG4U' and x['minimum']==80 for x in smith['below_minimum'])
            duplicated=c.post('/api/admissions/check',json={'courses':[{'code':'eng4u'},{'code':'ENG4U'}]})
            assert duplicated.status_code==422
            too_many=c.post('/api/admissions/check',json={'courses':[{'code':'ENG4U'}]*29})
            assert too_many.status_code==422
            assert c.post('/api/advisor/ask',json={'question':'What can I study for finance?'}).status_code==401
            student=c.post('/api/auth/signup',json={'name':'Roadmap Student','email':'v24test@example.com','password':'safePassword12345'})
            assert student.status_code==201,student.text
            resp=c.post('/api/advisor/ask',json={'question':'What courses does Rotman Commerce require?','program_id':'prog-rotman'})
            assert resp.status_code==200,resp.text
            result=resp.json()
            assert result['mode']=='source_summary' and result['sources']
            assert 'Rotman' in result['answer']
            assert 'not AI' in result['notice']
            assert c.post('/api/advisor/ask',json={'question':'Can you show incorrect unknown?', 'program_id':'not-a-program'}).status_code==404
            assert c.post('/api/advisor/ask',json={'question':'Hi'}).status_code==422
        js=(Path(a.ROOT)/'static/app.js').read_text()
        for symbol in ('dashboardFocus()','comparisonPage()','admissionsPage()','advisorPage()','editQuizAnswers()','toggleCompare(','/api/admissions/check','/api/advisor/ask'):
            assert symbol in js,symbol
        css=(Path(a.ROOT)/'static/styles.css').read_text()
        assert '.v24-dashboard' in css and '.v24-comparison-scroll' in css
    finally:
        Path(tmp.name).unlink(missing_ok=True)
        Path(tmp.name+'.outbox').unlink(missing_ok=True)
