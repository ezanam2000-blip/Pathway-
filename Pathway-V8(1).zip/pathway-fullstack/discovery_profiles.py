"""Exploration copy, not employee diaries or verified local entry requirements.

Role-specific examples are editorial summaries. Salary references remain separate
Ontario occupation-group benchmarks. Do not present these as global salaries.
"""
import re
from sourced_careers import SOURCED_ROLES

# title, industry, related wage group, short purpose, three activities, reality,
# curiosity tokens. Niche titles are intentionally marked as related benchmarks.
EXTRA_ROLES = [
    ('Human Factors Specialist', 'Engineering', 'industrial_eng', 'Make tools and workplaces easier for people to use.', ['Watch someone use a tool.', 'Test a safer layout.', 'Explain changes to the design team.'], 'A useful design still needs testing with real people.', ['people', 'making']),
    ('Game Accessibility Specialist', 'Design & Media', 'web_dev', 'Help more people play games.', ['Test a game with different controls.', 'Review captions and menus.', 'Share fixes with developers.'], 'Small interface details can stop someone from playing.', ['games', 'people']),
    ('Game Economy Designer', 'Design & Media', 'web_dev', 'Balance rewards and virtual spending in games.', ['Check how players earn rewards.', 'Adjust a progression model.', 'Test whether the game still feels fair.'], 'Much of the work is spreadsheets and testing.', ['games', 'numbers']),
    ('Esports Event Coordinator', 'Business & Operations', 'business_manager', 'Help competitive gaming events run smoothly.', ['Confirm the match schedule.', 'Coordinate crews and players.', 'Solve a last-minute event problem.'], 'Event days can involve evenings and weekend work.', ['games', 'sports']),
    ('Sports Sponsorship Coordinator', 'Business & Operations', 'marketing', 'Connect sports organizations with brand partners.', ['Prepare a sponsor pitch.', 'Track promised event benefits.', 'Report results to a partner.'], 'The job includes sales follow-ups and admin work.', ['sports', 'people']),
    ('Sports Equipment Developer', 'Engineering', 'mechanical', 'Design and test equipment athletes use.', ['Sketch a product idea.', 'Measure a prototype in testing.', 'Review a change with manufacturers.'], 'A good idea may need many prototypes.', ['sports', 'making']),
    ('Performance Video Analyst', 'Technology', 'data_science', 'Use game footage to help teams improve.', ['Tag clips from a match.', 'Compare patterns across games.', 'Prepare a short video for a coach.'], 'Reviewing footage can take much longer than the match.', ['sports', 'numbers']),
    ('Fraud Intelligence Analyst', 'Business & Operations', 'financial_officer', 'Find patterns that could point to fraud.', ['Check an unusual transaction pattern.', 'Review supporting records.', 'Document findings for an investigator.'], 'An unusual pattern is a lead. It is not proof of wrongdoing.', ['investigations', 'numbers']),
    ('Financial Crime Compliance Analyst', 'Business & Operations', 'financial_officer', 'Help organizations detect financial crime risks.', ['Review a customer file.', 'Check a flagged payment.', 'Record why a case needs further review.'], 'Careful documentation matters as much as finding a concern.', ['investigations', 'numbers']),
    ('Behavioural Research Assistant', 'Science & Environment', 'social_policy', 'Study how people make choices.', ['Help run a study.', 'Organize anonymous responses.', 'Discuss what the results can explain.'], 'Collecting good evidence involves repetitive work.', ['people', 'investigations']),
    ('Privacy Analyst', 'Technology', 'info_systems', 'Help organizations handle personal data responsibly.', ['Map where personal data is stored.', 'Review a new feature with a team.', 'Document a privacy concern.'], 'You spend time explaining risks and following up on changes.', ['investigations', 'people']),
    ('Digital Trust and Safety Analyst', 'Technology', 'info_systems', 'Help online services respond to abuse.', ['Review reported activity.', 'Check patterns against policy.', 'Recommend a safety improvement.'], 'Some roles involve upsetting content. Ask about support and exposure.', ['investigations', 'people']),
    ('Food Product Developer', 'Science & Environment', 'chemist', 'Create and improve food products.', ['Prepare a test recipe.', 'Compare taste and texture.', 'Record changes for the production team.'], 'A tasty prototype still needs safety and shelf-life checks.', ['making', 'science']),
    ('Packaging Designer', 'Design & Media', 'graphic_designer', 'Design packaging that protects a product and explains it.', ['Sketch a package layout.', 'Test a material sample.', 'Revise the design after feedback.'], 'Cost and manufacturing limits shape the final design.', ['making', 'climate']),
    ('Circular Economy Analyst', 'Science & Environment', 'science_policy', 'Find ways to reuse materials and reduce waste.', ['Map a product’s material use.', 'Compare reuse options.', 'Explain costs and practical limits.'], 'A greener option still needs to work for the business.', ['climate', 'numbers']),
    ('Carbon Accounting Analyst', 'Business & Operations', 'accountant', 'Help organizations measure greenhouse gas emissions.', ['Collect energy and supplier data.', 'Check an emissions calculation.', 'Explain gaps in the evidence.'], 'Missing data and changing methods can make estimates uncertain.', ['climate', 'numbers']),
    ('Ecological Restoration Technician', 'Science & Environment', 'biologist', 'Help restore damaged habitats.', ['Inspect a restoration site.', 'Record plant and soil observations.', 'Help a team maintain native planting.'], 'Fieldwork can be physical and weather-dependent.', ['climate', 'making']),
    ('Wildlife Acoustics Researcher', 'Science & Environment', 'biologist', 'Study wildlife through recorded sounds.', ['Set up a field recorder.', 'Review recordings for animal calls.', 'Compare patterns across locations.'], 'Many recordings contain noise rather than useful observations.', ['climate', 'science']),
    ('Geospatial Developer', 'Technology', 'software_dev', 'Build software that uses maps and location data.', ['Clean a location dataset.', 'Build a map feature.', 'Check whether coordinates are accurate.'], 'Data quality can matter as much as the code.', ['climate', 'numbers']),
    ('Disaster Resilience Planner', 'Law & Public Policy', 'science_policy', 'Help communities prepare for emergencies.', ['Review local hazard information.', 'Talk with community teams.', 'Update a preparedness plan.'], 'Plans must account for people with different needs and resources.', ['climate', 'people']),
    ('Prosthetics Product Developer', 'Engineering', 'mechanical', 'Help design devices that support movement.', ['Review a user need.', 'Build a test component.', 'Document a design change.'], 'Product design and fitting patients are different roles.', ['making', 'people']),
    ('Assistive Technology Specialist', 'Healthcare', 'ot', 'Help people use technology for everyday tasks.', ['Learn what a person needs to do.', 'Try an accessible device.', 'Show a user how to adjust it.'], 'The right solution depends on the individual and setting.', ['people', 'making']),
    ('Clinical Research Coordinator', 'Healthcare', 'health_policy', 'Help health studies run safely and consistently.', ['Schedule a study visit.', 'Check study records.', 'Coordinate with the clinical team.'], 'Following the study protocol and protecting participants come first.', ['science', 'people']),
    ('Patient Experience Researcher', 'Healthcare', 'market_research', 'Study how people experience healthcare services.', ['Interview a patient with consent.', 'Organize feedback themes.', 'Discuss a service change with staff.'], 'Feedback must be handled sensitively and confidentially.', ['people', 'investigations']),
    ('Science Communicator', 'Design & Media', 'technical_writer', 'Explain science in ways people can understand.', ['Check a scientific claim.', 'Draft an explanation.', 'Revise it with an expert.'], 'Clear writing must keep the uncertainty in the science.', ['science', 'people']),
    ('Immersive Experience Designer', 'Design & Media', 'web_dev', 'Create interactive spaces and digital experiences.', ['Sketch how visitors move through a space.', 'Build a small prototype.', 'Test it with the creative team.'], 'The work mixes creative ideas with technical limits.', ['games', 'making']),
    ('Learning Experience Designer', 'Education & Research', 'education_policy', 'Design activities that help people learn.', ['Break a topic into small lessons.', 'Build a practice activity.', 'Use learner feedback to revise it.'], 'An engaging lesson still needs to help someone learn.', ['people', 'making']),
    ('Music Metadata Specialist', 'Design & Media', 'archivist', 'Keep music information accurate across digital services.', ['Check song credits.', 'Resolve duplicate records.', 'Update release information.'], 'Most of the work involves accurate records rather than making music.', ['games', 'investigations']),
]

SPECIAL_DAYS = {
    'Investment Banking Analyst': (['Update a financial spreadsheet.', 'Help prepare slides for a client.', 'Check numbers after review comments.'], 'Junior work includes repeated revisions. Deadlines can mean long hours.'),
    'Forensic Accountant': (['Trace a payment through financial records.', 'Compare records for inconsistencies.', 'Write up evidence for the investigation team.'], 'You must support conclusions with records. A suspicion alone is not enough.'),
    'UX Designer': (['Watch someone try a product.', 'Sketch a clearer screen.', 'Test a prototype and revise it.'], 'Much of the day involves feedback and revisions rather than drawing.'),
    'Software Engineer': (['Read a bug report.', 'Write and test a change.', 'Review code with a teammate.'], 'Debugging and maintaining existing code are a large part of the job.'),
    'Electrician': (['Review the work plan and safety checks.', 'Install or troubleshoot a circuit.', 'Test the work and record results.'], 'Work can be physical. Safety rules and supervision matter.'),
    'Secondary School Teacher': (['Prepare a lesson.', 'Teach and support students.', 'Mark work and plan follow-up support.'], 'Planning and marking continue outside class time.'),
    'Registered Nurse': (['Review patient needs at handover.', 'Provide care and monitor changes.', 'Document care and coordinate with colleagues.'], 'Shifts can involve physical work and emotionally difficult situations.'),
    'Sports Data Analyst': (['Clean match data.', 'Compare a performance pattern.', 'Explain findings to the coaching team.'], 'Data supports decisions. It cannot guarantee a winning strategy.'),
    'Sound Designer': (['Record or find a sound.', 'Edit it to fit a scene.', 'Revise the mix after feedback.'], 'The work includes file management and repeated revisions.'),
    'User Experience Researcher': (['Prepare a research question.', 'Run a usability session.', 'Explain what the evidence supports.'], 'A small study cannot represent every user.'),
}

PROFILES = {r[0]: (r[4], r[5]) for r in EXTRA_ROLES}
PROFILES.update(SPECIAL_DAYS)
PROFILES.update({record['title']: (record['tasks'], record['reality']) for record in SOURCED_ROLES})
PROFILES['Investment Banking'] = SPECIAL_DAYS['Investment Banking Analyst']
PROFILES['Software Engineering'] = SPECIAL_DAYS['Software Engineer']
CURIOSITY = {r[0]: r[6] for r in EXTRA_ROLES}
CURIOSITY.update({'Sports Data Analyst':['sports','numbers'], 'Forensic Accountant':['investigations','numbers'], 'Climate Risk Analyst':['climate','numbers'], 'Sound Designer':['games','making'], 'Conservation Scientist':['climate','science'], 'Game Developer':['games','making'], 'Accessibility Designer':['people','making']})

def day_profile(item):
    title = item.get('title', '')
    if title in PROFILES:
        activities, reality = PROFILES[title]
    else:
        raw = item.get('day_to_day') or item.get('description') or ''
        activities = [s.strip() for s in re.split(r'(?<=[.!?])\s+', raw) if s.strip()]
        if len(activities) == 1:
            activities = [s.strip().rstrip('.') + '.' for s in re.split(r',\s*|;\s*', raw) if s.strip()][:3]
        activities = [(s[0].upper()+s[1:]) for s in activities[:3]]
        reality = (item.get('work_environment') or 'Tasks and schedules vary by employer.').split('. ')[0].rstrip('.') + '.'
    phases = ['Get oriented', 'Do the core work', 'Review and follow up']
    schedule = [{'phase': phases[i], 'task': task} for i, task in enumerate(activities[:3])]
    return {
        'activities': activities, 'reality': reality, 'schedule': schedule,
        'environment': item.get('work_environment') or 'Depends on the employer and role.',
        'reward': 'A possible reward is seeing careful work become useful to a client, team or community. Ask a worker what a good day looks like in this role.',
        'misconception': 'The job title is not the whole job. Preparation, documentation and revisions can take as much attention as the headline task.',
        'basis': 'Illustrative work examples, not a timed diary or a professional interview. Tasks, order and rewards vary by employer.',
    }
