from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import smtplib
import time
from collections import defaultdict, deque
from email.message import EmailMessage
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal, Optional

from fastapi import Cookie, Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("PATHWAY_DB_PATH", ROOT / "pathway.db"))
SESSION_COOKIE = "pathway_session"
SESSION_DAYS = 30
PBKDF2_ITERATIONS = 310_000
COOKIE_SECURE = os.getenv("PATHWAY_COOKIE_SECURE", "0") == "1"
APP_BASE_URL = os.getenv("PATHWAY_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
SMTP_HOST = os.getenv("PATHWAY_SMTP_HOST", "").strip()
SMTP_PORT = int(os.getenv("PATHWAY_SMTP_PORT", "587"))
SMTP_USERNAME = os.getenv("PATHWAY_SMTP_USERNAME", "").strip()
SMTP_PASSWORD = os.getenv("PATHWAY_SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("PATHWAY_SMTP_FROM", SMTP_USERNAME or "Pathway <no-reply@pathway.local>")
SMTP_USE_TLS = os.getenv("PATHWAY_SMTP_USE_TLS", "1") == "1"
EMAIL_TOKEN_HOURS = int(os.getenv("PATHWAY_EMAIL_TOKEN_HOURS", "24"))
RESET_TOKEN_HOURS = int(os.getenv("PATHWAY_RESET_TOKEN_HOURS", "1"))
STALE_DAYS = int(os.getenv("PATHWAY_STALE_DAYS", "180"))
APP_VERSION = "2.0.0"
OUTBOX_PATH = Path(os.getenv("PATHWAY_OUTBOX_PATH", ROOT / "dev-email-outbox.log"))

app = FastAPI(title="Pathway API", version=APP_VERSION, docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def dumps(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def loads(value: Optional[str], default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return default


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        PBKDF2_ITERATIONS,
        base64.urlsafe_b64encode(salt).decode().rstrip("="),
        base64.urlsafe_b64encode(digest).decode().rstrip("="),
    )


def _b64decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        salt = _b64decode(salt_b64)
        expected = _b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def serialize_user(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "email": row["email"],
        "grade": row["grade"],
        "interests": loads(row["interests_json"], []),
        "goals": loads(row["goals_json"], [row["goal"]] if row["goal"] else []),
        "skills": loads(row["skills_json"], []),
        "goal": row["goal"],
        "onboarding_completed": bool(row["onboarding_completed"]),
        "is_admin": bool(row["is_admin"]),
        "email_verified": bool(row["email_verified"]) if "email_verified" in row.keys() else False,
        "created_at": row["created_at"],
    }


def content_row_to_dict(row: sqlite3.Row, content_type: str) -> dict[str, Any]:
    base = {
        "id": row["id"],
        "type": content_type,
        "title": row["title"],
        "subtitle": row["subtitle"],
        "description": row["description"],
        "tags": loads(row["tags_json"], []),
        "source_url": row["source_url"],
        "status": row["status"],
        "last_verified_date": row["last_verified_date"],
        "featured": bool(row["featured"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }
    if content_type == "career":
        base.update({
            "industry": row["industry"] if "industry" in row.keys() else row["subtitle"],
            "education": row["education"],
            "day_to_day": row["day_to_day"],
            "pay_range": row["pay_range"] if "pay_range" in row.keys() else "",
            "pay_note": row["pay_note"] if "pay_note" in row.keys() else "",
            "levels": loads(row["levels_json"] if "levels_json" in row.keys() else None, []),
            "skills": loads(row["skills_json"] if "skills_json" in row.keys() else None, []),
            "school_subjects": loads(row["school_subjects_json"] if "school_subjects_json" in row.keys() else None, []),
            "success_tips": loads(row["success_tips_json"] if "success_tips_json" in row.keys() else None, []),
            "pathway_steps": loads(row["pathway_steps_json"] if "pathway_steps_json" in row.keys() else None, []),
            "work_environment": row["work_environment"] if "work_environment" in row.keys() else "",
            "outlook": row["outlook"] if "outlook" in row.keys() else "",
        })
    elif content_type == "program":
        base.update({
            "university": row["university"],
            "field": row["field"],
            "province": row["province"],
            "requirements": loads(row["requirements_json"], []),
            "deadline": row["deadline"],
            "supplemental": row["supplemental"],
            "when_to_apply": row["when_to_apply"] if "when_to_apply" in row.keys() else "",
            "recommended_profile": loads(row["recommended_profile_json"] if "recommended_profile_json" in row.keys() else None, []),
            "admission_tips": loads(row["admission_tips_json"] if "admission_tips_json" in row.keys() else None, []),
            "timeline": loads(row["timeline_json"] if "timeline_json" in row.keys() else None, []),
            "related_careers": loads(row["related_careers_json"] if "related_careers_json" in row.keys() else None, []),
            "application_steps": loads(row["application_steps_json"] if "application_steps_json" in row.keys() else None, []),
            "application_method": row["application_method"] if "application_method" in row.keys() else "",
        })
    elif content_type == "scholarship":
        base.update({
            "organization": row["organization"],
            "amount": row["amount"],
            "eligibility": row["eligibility"],
            "deadline": row["deadline"],
        })
    return base



def apply_staleness(con: sqlite3.Connection) -> None:
    cutoff = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).date().isoformat()
    for table in ("programs", "scholarships"):
        con.execute(
            f"UPDATE {table} SET status='needs_review',updated_at=? WHERE status='verified' AND last_verified_date IS NOT NULL AND last_verified_date < ?",
            (now_iso(), cutoff),
        )

def init_db() -> None:
    con = connect()
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            grade TEXT DEFAULT '12',
            interests_json TEXT NOT NULL DEFAULT '[]',
            goals_json TEXT NOT NULL DEFAULT '[]',
            skills_json TEXT NOT NULL DEFAULT '[]',
            goal TEXT DEFAULT 'Explore careers',
            onboarding_completed INTEGER NOT NULL DEFAULT 0,
            is_admin INTEGER NOT NULL DEFAULT 0,
            email_verified INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS auth_tokens (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            purpose TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            used_at TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS careers (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            description TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            industry TEXT NOT NULL DEFAULT '',
            education TEXT NOT NULL DEFAULT '',
            day_to_day TEXT NOT NULL DEFAULT '',
            pay_range TEXT NOT NULL DEFAULT '',
            pay_note TEXT NOT NULL DEFAULT '',
            levels_json TEXT NOT NULL DEFAULT '[]',
            skills_json TEXT NOT NULL DEFAULT '[]',
            school_subjects_json TEXT NOT NULL DEFAULT '[]',
            success_tips_json TEXT NOT NULL DEFAULT '[]',
            pathway_steps_json TEXT NOT NULL DEFAULT '[]',
            work_environment TEXT NOT NULL DEFAULT '',
            outlook TEXT NOT NULL DEFAULT '',
            source_url TEXT,
            status TEXT NOT NULL DEFAULT 'needs_review',
            last_verified_date TEXT,
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS programs (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            university TEXT NOT NULL,
            field TEXT NOT NULL,
            province TEXT NOT NULL DEFAULT 'Ontario',
            description TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            requirements_json TEXT NOT NULL DEFAULT '[]',
            deadline TEXT,
            supplemental TEXT,
            when_to_apply TEXT NOT NULL DEFAULT '',
            recommended_profile_json TEXT NOT NULL DEFAULT '[]',
            admission_tips_json TEXT NOT NULL DEFAULT '[]',
            timeline_json TEXT NOT NULL DEFAULT '[]',
            related_careers_json TEXT NOT NULL DEFAULT '[]',
            application_steps_json TEXT NOT NULL DEFAULT '[]',
            application_method TEXT NOT NULL DEFAULT '',
            source_url TEXT,
            status TEXT NOT NULL DEFAULT 'needs_review',
            last_verified_date TEXT,
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS scholarships (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            organization TEXT NOT NULL DEFAULT '',
            amount TEXT,
            description TEXT NOT NULL,
            tags_json TEXT NOT NULL DEFAULT '[]',
            eligibility TEXT NOT NULL DEFAULT '',
            deadline TEXT,
            source_url TEXT,
            status TEXT NOT NULL DEFAULT 'needs_review',
            last_verified_date TEXT,
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS saved_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            item_type TEXT NOT NULL,
            item_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, item_type, item_id)
        );
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            program_id TEXT,
            institution TEXT NOT NULL,
            program_name TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Researching',
            deadline TEXT,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS application_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            completed INTEGER NOT NULL DEFAULT 0,
            due_date TEXT,
            sort_order INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS plan_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            item_type TEXT NOT NULL,
            item_id TEXT NOT NULL,
            title TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'Next step',
            completed INTEGER NOT NULL DEFAULT 0,
            priority INTEGER NOT NULL DEFAULT 2,
            sort_order INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, item_type, item_id, title)
        );
        CREATE TABLE IF NOT EXISTS content_change_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            item_type TEXT NOT NULL,
            item_id TEXT NOT NULL,
            action TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    # Lightweight migration for databases created by earlier Pathway versions.
    columns = {r["name"] for r in con.execute("PRAGMA table_info(users)").fetchall()}
    if "email_verified" not in columns:
        con.execute("ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0")
    if "goals_json" not in columns:
        con.execute("ALTER TABLE users ADD COLUMN goals_json TEXT NOT NULL DEFAULT '[]'")
    if "skills_json" not in columns:
        con.execute("ALTER TABLE users ADD COLUMN skills_json TEXT NOT NULL DEFAULT '[]'")

    career_cols = {r["name"] for r in con.execute("PRAGMA table_info(careers)").fetchall()}
    for name, ddl in {
        "industry":"TEXT NOT NULL DEFAULT ''",
        "pay_range":"TEXT NOT NULL DEFAULT ''",
        "pay_note":"TEXT NOT NULL DEFAULT ''",
        "levels_json":"TEXT NOT NULL DEFAULT '[]'",
        "skills_json":"TEXT NOT NULL DEFAULT '[]'",
        "school_subjects_json":"TEXT NOT NULL DEFAULT '[]'",
        "success_tips_json":"TEXT NOT NULL DEFAULT '[]'",
        "pathway_steps_json":"TEXT NOT NULL DEFAULT '[]'",
        "work_environment":"TEXT NOT NULL DEFAULT ''",
        "outlook":"TEXT NOT NULL DEFAULT ''",
    }.items():
        if name not in career_cols:
            con.execute(f"ALTER TABLE careers ADD COLUMN {name} {ddl}")

    program_cols = {r["name"] for r in con.execute("PRAGMA table_info(programs)").fetchall()}
    for name, ddl in {
        "when_to_apply":"TEXT NOT NULL DEFAULT ''",
        "recommended_profile_json":"TEXT NOT NULL DEFAULT '[]'",
        "admission_tips_json":"TEXT NOT NULL DEFAULT '[]'",
        "timeline_json":"TEXT NOT NULL DEFAULT '[]'",
        "related_careers_json":"TEXT NOT NULL DEFAULT '[]'",
        "application_steps_json":"TEXT NOT NULL DEFAULT '[]'",
        "application_method":"TEXT NOT NULL DEFAULT ''",
    }.items():
        if name not in program_cols:
            con.execute(f"ALTER TABLE programs ADD COLUMN {name} {ddl}")
    con.commit()
    seed_content(con)
    apply_staleness(con)
    con.commit()
    seed_admin(con)
    con.close()


def seed_content(con: sqlite3.Connection) -> None:
    """Seed a broader, human-readable launch dataset.

    Program deadlines and prerequisites marked verified were checked against their
    official institutional pages on 2026-09-18. Career wage references use the
    Government of Canada Job Bank pages listed on each record. Wage figures are
    labour-market references, not promises of individual compensation.
    """
    ts = now_iso()
    verified_date = "2026-09-18"

    careers = [
        {
            "id":"career-finance", "title":"Investment Banking", "subtitle":"Finance", "industry":"Finance",
            "description":"Help companies raise capital, evaluate major transactions, and execute mergers, acquisitions, and financings. The work combines financial analysis, business judgement, communication, and long hours around live deals.",
            "tags":["Business & Finance","Math","Leadership","Communication","Problem Solving"],
            "education":"Common routes include commerce, finance, economics, accounting, mathematics, or another rigorous undergraduate program. There is no single required degree, but strong grades, finance knowledge, and relevant internships matter.",
            "day_to_day":"Build and review financial models, research companies and industries, prepare pitch books and presentations, support due diligence, compare valuation methods, and coordinate with clients, lawyers, accountants, and senior bankers.",
            "pay_range":"Toronto labour-market reference: about $28–$74/hour; median $41.60/hour",
            "pay_note":"Government Job Bank data is for investment analysts (NOC 11101), not a pure investment-banking compensation survey. Investment-banking bonuses can make total compensation materially different by firm and level.",
            "levels":["Analyst — financial modelling, research, presentations, execution support","Associate — reviews analyst work, manages workstreams and client materials","Vice President — leads execution, coordinates teams and client communication","Director / Executive Director — senior deal leadership and business development","Managing Director — originates business, manages senior client relationships, and leads major transactions"],
            "skills":["Math","Financial analysis","Excel","Accounting","Communication","Writing","Attention to detail","Teamwork","Time management"],
            "school_subjects":["Mathematics","Economics","Accounting or business if available","English / writing","Computer or data courses can help"],
            "success_tips":["Build a strong foundation in math, accounting, and financial statements","Aim for strong university grades, especially early in your degree","Join finance, investment, or case-competition activities where you can build practical skills","Learn Excel, valuation, and financial modelling before recruiting","Pursue internships in finance, accounting, consulting, search funds, private equity, corporate finance, or related roles","Practice networking and professional communication; recruiting often starts early"],
            "pathway_steps":["High school: strengthen math, communication, and leadership","University: choose a strong academic program and maintain competitive grades","Year 1–2: join finance clubs, learn technical basics, and seek early experience","Year 2–3: recruit for relevant internships and build deal/valuation knowledge","Penultimate year: recruit for investment-banking summer analyst roles","After graduation: enter as an analyst or use a related finance role as a stepping stone"],
            "work_environment":"Fast-paced office and client environment. Hours can be long and unpredictable during active transactions. Work is highly team-based and deadline-driven.",
            "outlook":"Competitive entry path with strong demand for analytical, communication, and execution skills. Hiring varies with capital-market and deal activity.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/12418/geo9219", "status":"verified"
        },
        {
            "id":"career-software", "title":"Software Engineering", "subtitle":"Technology", "industry":"Technology",
            "description":"Design, build, test, and maintain software products and systems. Software engineers work on everything from mobile apps and websites to cloud infrastructure, AI systems, financial technology, healthcare software, and embedded devices.",
            "tags":["Technology","Math","Problem Solving","Creativity","Teamwork"],
            "education":"Common routes include computer science, software engineering, computer engineering, mathematics, or related programs. Some employers also hire strong self-taught developers with excellent projects and experience.",
            "day_to_day":"Write and review code, design systems, debug problems, plan features, test software, discuss trade-offs with product and design teams, and monitor systems after launch.",
            "pay_range":"Toronto labour-market reference: about $36–$89/hour; median $56.49/hour",
            "pay_note":"Job Bank wage data is for computer software engineers. Actual pay varies by company, specialty, experience, equity, and location.",
            "levels":["Junior / New graduate — implements scoped features with guidance","Intermediate — owns larger features and makes design decisions","Senior — leads complex technical work and mentors others","Staff / Principal — sets technical direction across teams or systems","Engineering Manager / Director — leads people, delivery, and technical strategy"],
            "skills":["Programming","Math","Problem Solving","Algorithms","Debugging","Communication","Teamwork","System design","Continuous learning"],
            "school_subjects":["Computer science","Advanced mathematics","Physics can help","English / communication"],
            "success_tips":["Learn one programming language well before trying to learn many","Build real projects that solve a problem, not only tutorial exercises","Practice data structures, algorithms, debugging, and version control","Use GitHub or another portfolio to show your work","Pursue co-op, internships, hackathons, research, or open-source work","Learn to explain technical decisions clearly"],
            "pathway_steps":["Explore coding through small projects","Take strong math and computer-science courses where available","Build a portfolio with 2–4 meaningful projects","Choose a university/college path with strong computing fundamentals or co-op","Pursue internships and improve interview skills","Specialize over time in areas such as backend, frontend, mobile, cloud, security, data, or AI"],
            "work_environment":"Usually team-based and computer-focused. Many roles are hybrid or remote. Work mixes deep individual focus with planning, reviews, and collaboration.",
            "outlook":"Software skills remain broadly useful across industries, though hiring can be cyclical and competition is strongest for entry-level roles.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/5485/geo9219", "status":"verified"
        },
        {
            "id":"career-nursing", "title":"Registered Nurse", "subtitle":"Healthcare", "industry":"Healthcare",
            "description":"Provide and coordinate patient care, assess health needs, administer treatments, educate patients and families, and work with physicians and other healthcare professionals.",
            "tags":["Medicine & Health","Science","Working with People","Communication","Teamwork"],
            "education":"In Ontario, registered nurses generally complete an approved nursing degree and meet registration requirements set by the provincial regulator. Requirements vary by province and country.",
            "day_to_day":"Assess patients, monitor symptoms and vital signs, give medications and treatments, document care, educate patients, coordinate with the healthcare team, and respond to changing clinical needs.",
            "pay_range":"Toronto labour-market reference: about $28–$55/hour; median $40.59/hour",
            "pay_note":"Job Bank wage data is for registered nurses in the Toronto region. Shift premiums, overtime, specialty, union agreements, and experience can affect compensation.",
            "levels":["New graduate / Staff RN — develops clinical judgement and core bedside skills","Experienced RN — handles more complex assignments and may specialize","Charge nurse / Clinical leader — coordinates a unit or shift","Advanced practice / Nurse practitioner — requires additional graduate-level education and licensing","Manager / Educator / Specialist — leadership, education, quality, research, or administration"],
            "skills":["Biology","Communication","Working with People","Teamwork","Attention to detail","Decision making","Stress management","Organization"],
            "school_subjects":["Biology","Chemistry","Mathematics","English"],
            "success_tips":["Build strong biology and chemistry foundations","Develop communication and teamwork through volunteering, employment, or community activities","Research nursing prerequisites early because required courses vary by program","Look for healthcare exposure that helps you understand patient care without overstating your responsibilities","During nursing school, take clinical placements seriously and ask for feedback","Prepare for provincial registration requirements before graduation"],
            "pathway_steps":["High school: complete nursing prerequisites and strengthen science","Apply to an approved nursing program","Complete classroom, lab, and clinical requirements","Meet provincial registration and examination requirements","Start in a clinical area and build experience","Specialize, pursue leadership, or complete graduate education if desired"],
            "work_environment":"Hospitals, clinics, long-term care, community care, public health, schools, and other settings. Shift work, nights, weekends, and physically demanding situations are common in many roles.",
            "outlook":"Healthcare needs support continued demand, but opportunities and working conditions vary by region and specialty.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/993/geo9219", "status":"verified"
        },
        {
            "id":"career-mech", "title":"Mechanical Engineer", "subtitle":"Engineering", "industry":"Engineering",
            "description":"Design, analyze, test, and improve machines, products, manufacturing systems, energy systems, robotics, vehicles, and other physical technologies.",
            "tags":["Engineering","Math","Science","Problem Solving","Technology"],
            "education":"A bachelor's degree in mechanical engineering or a closely related accredited engineering program is the common route. Professional engineering licensure requirements vary by jurisdiction.",
            "day_to_day":"Use CAD and engineering analysis, run calculations and simulations, review designs, test prototypes, solve manufacturing or reliability issues, document decisions, and collaborate with multidisciplinary teams.",
            "pay_range":"Toronto labour-market reference: about $31–$73/hour; median $46.15/hour",
            "pay_note":"Job Bank wage data is for mechanical engineers in the Toronto region. Industry, licensure, specialty, and experience can materially change pay.",
            "levels":["Engineering intern / EIT — supervised design and analysis","Engineer — owns components and projects","Senior Engineer — leads complex technical work and mentoring","Lead / Principal Engineer — technical authority across larger systems","Engineering Manager / Director — leads teams, budgets, and technical strategy"],
            "skills":["Math","Physics","CAD","Problem Solving","Technical writing","Teamwork","Design","Data analysis"],
            "school_subjects":["Advanced Functions","Calculus","Physics","Chemistry","Computer science can help"],
            "success_tips":["Take math and physics seriously; they are foundational","Join robotics, design teams, maker clubs, or hands-on technical projects","Learn CAD and basic programming or data analysis","Prefer programs with strong design projects, labs, and co-op if possible","Build a portfolio of projects that shows how you solve engineering problems","Pursue internships in manufacturing, energy, aerospace, automotive, robotics, or product development"],
            "pathway_steps":["High school: complete engineering prerequisites and build technical projects","Study mechanical engineering or a related discipline","Use co-op/internships to test different industries","Graduate and begin supervised engineering work","Work toward professional designation where useful/required","Develop a specialty such as robotics, energy, aerospace, manufacturing, or product design"],
            "work_environment":"Mix of office/computer work, laboratories, manufacturing facilities, project sites, and testing environments depending on industry.",
            "outlook":"Broad career field across manufacturing, transportation, energy, automation, building systems, and product development.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/2757/geo9219", "status":"verified"
        },
        {
            "id":"career-law", "title":"Lawyer", "subtitle":"Law", "industry":"Law",
            "description":"Advise clients, interpret laws and regulations, negotiate agreements, research legal issues, prepare documents, and represent individuals or organizations in legal matters.",
            "tags":["Law","Writing","Communication","Research","Problem Solving"],
            "education":"In Canada, the usual route is an undergraduate degree followed by a law degree and the licensing process required by the provincial or territorial law society.",
            "day_to_day":"Research law, draft contracts or legal arguments, speak with clients, negotiate, review evidence, prepare for hearings or transactions, and manage deadlines and files.",
            "pay_range":"Ontario labour-market reference: about $32–$113/hour; median $65.21/hour",
            "pay_note":"Job Bank wages cover lawyers broadly. Compensation varies significantly across public service, small firms, large firms, in-house roles, legal aid, and partnership structures.",
            "levels":["Law student / summer student — research and supervised legal work","Articling / licensing stage — practical training before full practice","Associate — manages files and develops legal expertise","Senior Associate / Counsel — leads complex matters and clients","Partner / Senior in-house counsel / Leadership — major client, management, or strategic responsibility"],
            "skills":["Writing","Communication","Reading","Research","Critical thinking","Negotiation","Attention to detail","Organization"],
            "school_subjects":["English","History","Law or politics if available","Social sciences","Any rigorous course that builds reading and writing"],
            "success_tips":["Become an excellent reader and writer","Practice structured arguments using evidence","Choose an undergraduate program where you can perform strongly and build genuine interests","Seek debate, mock trial, student government, research, journalism, or community experiences if they interest you","Learn what different legal practice areas actually involve before committing","Build professional relationships and seek internships or legal exposure during university"],
            "pathway_steps":["High school: strengthen reading, writing, research, and communication","Complete an undergraduate degree","Prepare for and apply to law school","Complete a JD or equivalent law degree","Complete licensing requirements in your jurisdiction","Build experience in a practice area and progress toward senior responsibility"],
            "work_environment":"Law firms, government, courts, corporations, non-profits, clinics, and independent practice. Work can involve tight deadlines and high responsibility.",
            "outlook":"A broad profession with very different lifestyles and opportunities across practice areas. Entry can be competitive, especially for highly sought-after firms and specialties.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/15815/ON", "status":"verified"
        },
        {
            "id":"career-design", "title":"UX / Product Designer", "subtitle":"Design & Technology", "industry":"Design & Technology",
            "description":"Design digital products and experiences by understanding users, defining problems, prototyping interfaces, testing ideas, and working with product and engineering teams.",
            "tags":["Arts & Design","Technology","Creativity","Communication","Problem Solving"],
            "education":"Common routes include interaction design, UX, graphic design, HCI, digital media, computer science, psychology, or related programs. A strong portfolio is usually more important than a specific degree title.",
            "day_to_day":"Interview users, map workflows, create wireframes and prototypes, test designs, analyze feedback, refine interfaces, write product documentation, and collaborate with engineers and product managers.",
            "pay_range":"Toronto UI-design labour-market reference: about $30–$77/hour; median $48.08/hour",
            "pay_note":"Job Bank classification and titles vary across UX, UI, and product design. Use this as a broad labour-market reference, not a guaranteed salary range.",
            "levels":["Junior Designer — supports research, flows, and interface work","Product / UX Designer — owns features from discovery through delivery","Senior Designer — leads complex projects and influences product direction","Lead / Staff Designer — sets design standards across teams","Design Manager / Director — leads designers, strategy, and organizational design quality"],
            "skills":["Creativity","Communication","Research","Prototyping","Visual design","Problem Solving","Empathy","Collaboration"],
            "school_subjects":["Visual arts or design","Computer science","English","Psychology or social science can help"],
            "success_tips":["Learn a modern design/prototyping tool","Build case studies that explain the problem, process, decisions, and result","Practice user research and testing instead of focusing only on appearance","Work with developers so you understand technical constraints","Seek internships, freelance projects, clubs, or student products where you can ship real work","Keep improving your portfolio as your skills grow"],
            "pathway_steps":["Explore design through small app/web redesigns and research exercises","Build a portfolio with clear case studies","Study design, HCI, digital media, computing, psychology, or another relevant path","Join multidisciplinary projects","Pursue internships or junior product/design roles","Develop a specialty such as UX research, product design, UI systems, or design leadership"],
            "work_environment":"Technology companies, agencies, banks, retailers, healthcare organizations, startups, and many other organizations. Often hybrid, team-based, and project-driven.",
            "outlook":"Digital product skills are useful across industries, but portfolios and practical experience strongly affect entry-level competitiveness.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/296977/geo9219", "status":"verified"
        },
        {
            "id":"career-electrician", "title":"Electrician", "subtitle":"Skilled Trades", "industry":"Skilled Trades",
            "description":"Install, maintain, troubleshoot, and repair electrical systems in homes, commercial buildings, industrial facilities, construction projects, and specialized environments.",
            "tags":["Skilled Trades","Hands-on Work","Problem Solving","Math","Technology"],
            "education":"The common route is an apprenticeship combining paid on-the-job training and technical classroom instruction, followed by certification requirements that vary by province and trade classification.",
            "day_to_day":"Read plans, install wiring and equipment, test circuits, troubleshoot faults, follow electrical and safety codes, document work, and coordinate with other trades.",
            "pay_range":"Ontario labour-market reference: about $20–$50.50/hour; median $34/hour",
            "pay_note":"Actual wages vary by apprenticeship stage, union/non-union setting, industry, overtime, certification, and region.",
            "levels":["Apprentice — learns on the job while completing technical training","Journeyperson — works independently within certification scope","Foreperson / Lead — coordinates crews and job-site work","Estimator / Supervisor — plans labour, materials, and project execution","Contractor / Business owner — manages clients, crews, compliance, and business operations"],
            "skills":["Math","Hands-on Work","Problem Solving","Safety awareness","Attention to detail","Mechanical reasoning","Communication"],
            "school_subjects":["Mathematics","Physics","Construction or technology courses","Co-op / skilled-trades courses where available"],
            "success_tips":["Build strong practical math and measurement skills","Take shop, construction, electrical, or technology courses if available","Learn safety habits early","Use co-op or pre-apprenticeship exposure to understand the work environment","Research apprenticeship registration and certification rules in your province","Be reliable: attendance, communication, and safety matter heavily in the trades"],
            "pathway_steps":["Explore the trade through school technical courses or co-op","Find an apprenticeship pathway and employer/sponsor","Complete required on-the-job and classroom training","Meet certification requirements","Build experience in residential, commercial, industrial, or specialized work","Progress into supervision, estimating, contracting, or business ownership if desired"],
            "work_environment":"Construction sites, buildings, industrial facilities, maintenance settings, and outdoor environments. Work is physical and requires careful safety practices.",
            "outlook":"Skilled electrical work is needed across construction, maintenance, industry, energy, and infrastructure, though local demand varies.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/20684/ON", "status":"verified"
        },
        {
            "id":"career-teacher", "title":"Secondary School Teacher", "subtitle":"Education", "industry":"Education",
            "description":"Teach subject-area knowledge, plan lessons and assessments, support student development, communicate with families and colleagues, and contribute to school life.",
            "tags":["Education","Communication","Working with People","Leadership","Writing"],
            "education":"In Ontario, the common route is an undergraduate degree plus an accredited teacher-education program and certification through the provincial regulator. Other jurisdictions differ.",
            "day_to_day":"Plan lessons, teach classes, assess work, give feedback, support students, meet with colleagues and families, supervise activities, and continue professional learning.",
            "pay_range":"Ontario labour-market reference: about $29–$62/hour; median $48.08/hour",
            "pay_note":"Teacher compensation often follows salary grids based on qualifications and experience. Job Bank hourly figures are broad labour-market estimates.",
            "levels":["Occasional / Supply Teacher — short-term classroom coverage","Long-term occasional / Early-career Teacher — longer assignments and classroom ownership","Experienced Teacher — deeper curriculum and student-support responsibility","Department Head / Instructional Leader — subject or school leadership","Vice-Principal / Principal — administrative leadership with additional qualifications and experience"],
            "skills":["Communication","Leadership","Writing","Organization","Working with People","Patience","Subject knowledge"],
            "school_subjects":["Strong subjects you may want to teach","English / communication","Psychology or social sciences can help"],
            "success_tips":["Develop deep knowledge in subjects you may want to teach","Practice explaining difficult ideas clearly","Tutor, coach, mentor, or volunteer with youth to test whether you enjoy teaching","Build classroom-management and communication skills","Research teachable-subject requirements before choosing university courses","Seek feedback and keep improving your teaching practice"],
            "pathway_steps":["High school: build subject strength and experience working with younger students","Complete an undergraduate degree with appropriate teachable subjects","Complete an accredited teacher-education program","Obtain certification","Build classroom experience","Pursue leadership, specialist qualifications, counselling, administration, or curriculum roles if desired"],
            "work_environment":"Schools and classrooms, with preparation and marking often extending beyond class time. Strong communication and emotional stamina are important.",
            "outlook":"Demand varies by region, subject area, language, and school board. Some specialties and geographic areas experience stronger shortages than others.",
            "source":"https://www.jobbank.gc.ca/marketreport/wages-occupation/15904/ON", "status":"verified"
        },
        {
            "id":"career-entre", "title":"Entrepreneurship", "subtitle":"Entrepreneurship", "industry":"Entrepreneurship",
            "description":"Create and grow a product, service, or organization around a real customer problem. Founders combine product decisions, sales, hiring, operations, finance, and constant learning.",
            "tags":["Entrepreneurship","Leadership","Business & Finance","Creativity","Communication"],
            "education":"There is no required degree. Founders come from business, engineering, computer science, healthcare, trades, design, and many other backgrounds. Industry knowledge and execution matter more than one academic route.",
            "day_to_day":"Talk to customers, test ideas, build or coordinate product development, sell, recruit, manage money, solve operational problems, and make decisions with incomplete information.",
            "pay_range":"Highly variable — there is no standard founder salary range",
            "pay_note":"Early-stage founders may earn little or no salary while building a business. Outcomes vary widely and ownership is not the same as cash income.",
            "levels":["Explorer — validates problems and learns an industry","Early-stage Founder — builds a first product/service and finds initial customers","Founder with product-market fit — grows a repeatable business model","Growth-stage Founder / CEO — builds teams, systems, and financing","Operator / Investor / Repeat Founder — may lead larger companies or start new ventures"],
            "skills":["Leadership","Communication","Sales","Problem Solving","Creativity","Finance","Execution","Resilience"],
            "school_subjects":["Business or economics","Mathematics","English / communication","Computer science or design depending on the idea"],
            "success_tips":["Start with a real problem rather than an app idea alone","Talk to potential users before building too much","Learn basic sales, finance, and customer research","Keep projects small enough to finish and measure","Work in an industry before starting a company if deeper domain knowledge would help","Track real outcomes such as users, revenue, retention, or time saved"],
            "pathway_steps":["Explore problems in industries you understand","Interview potential users","Build a small test or minimum viable product","Measure whether people actually use or pay for it","Improve the product and distribution","Scale only after you have evidence of demand"],
            "work_environment":"Highly variable. Early-stage work often combines independent work, customer conversations, product building, sales, and administration.",
            "outlook":"There is no predictable career ladder or guaranteed income. Entrepreneurship can build valuable skills even when a specific venture does not become a large company.",
            "source":None, "status":"needs_review"
        },
    ]

    for c in careers:
        con.execute(
            """INSERT INTO careers
            (id,title,subtitle,description,tags_json,industry,education,day_to_day,pay_range,pay_note,levels_json,skills_json,school_subjects_json,success_tips_json,pathway_steps_json,work_environment,outlook,source_url,status,last_verified_date,featured,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              title=excluded.title,subtitle=excluded.subtitle,description=excluded.description,tags_json=excluded.tags_json,
              industry=excluded.industry,education=excluded.education,day_to_day=excluded.day_to_day,pay_range=excluded.pay_range,
              pay_note=excluded.pay_note,levels_json=excluded.levels_json,skills_json=excluded.skills_json,
              school_subjects_json=excluded.school_subjects_json,success_tips_json=excluded.success_tips_json,
              pathway_steps_json=excluded.pathway_steps_json,work_environment=excluded.work_environment,outlook=excluded.outlook,
              source_url=excluded.source_url,status=excluded.status,last_verified_date=excluded.last_verified_date,
              featured=excluded.featured,updated_at=excluded.updated_at""",
            (c["id"],c["title"],c["subtitle"],c["description"],dumps(c["tags"]),c["industry"],c["education"],c["day_to_day"],
             c["pay_range"],c["pay_note"],dumps(c["levels"]),dumps(c["skills"]),dumps(c["school_subjects"]),dumps(c["success_tips"]),
             dumps(c["pathway_steps"]),c["work_environment"],c["outlook"],c["source"],c["status"],verified_date if c["status"]=="verified" else None,
             1 if c["id"] in {"career-finance","career-software","career-nursing","career-mech"} else 0,ts,ts),
        )

    programs = [
        {
            "id":"prog-ivey", "title":"Ivey AEO / HBA", "university":"Western University", "field":"Business",
            "description":"Conditional pre-admission status for students who plan to enter Ivey's HBA after their first two years at Western or an affiliated university college.",
            "tags":["Business & Finance","Leadership","Entrepreneurship"],
            "requirements":["Competitive applicants present a low-90s average in their best Grade 12 courses, including English","Complete a university-bound mathematics course","Leadership experience is assessed alongside academics","Complete the Ivey AEO supplemental, references, and mandatory Kira video interview"],
            "deadline":"January 15, 2027 at 11:59 p.m. EST",
            "supplemental":"Separate AEO supplemental application required in addition to the Western/affiliate application through OUAC.",
            "when_to_apply":"Apply to Western through OUAC in the fall of Grade 12, indicate your interest in Ivey AEO, and complete the separate AEO application well before January 15.",
            "recommended_profile":["Aim comfortably above the published low-90s competitive academic level","Show sustained leadership and responsibility rather than collecting activity titles","Choose activities where your personal contribution and results are easy to explain","Prepare specific examples for written and video responses"],
            "admission_tips":["Start the activity essays early and focus on what you personally did","Use concrete outcomes, numbers, or changes where they are genuine","Choose references who directly saw your contribution","Practice timed video responses without memorizing scripts","Protect your Grade 12 English and math performance"],
            "timeline":["September–November: apply to Western through OUAC and gather activity examples","Fall: draft AEO activity essays and confirm references","December: refine written responses and practice timed video answers","January 15: AEO application deadline","After admission: maintain the conditions required for eventual HBA entry"],
            "related_careers":["Investment Banking","Consulting","Corporate Finance","Entrepreneurship","Product Management"],
            "application_steps":["Apply to Western/affiliate through OUAC","Indicate interest in Ivey AEO","Complete the separate AEO application","Submit activity essays and additional activities","Provide verifiable references","Complete the Kira video interview"],
            "application_method":"OUAC + separate Ivey AEO supplemental",
            "source":"https://www.ivey.uwo.ca/hba/admissions/secondary-school-students/"
        },
        {
            "id":"prog-rotman", "title":"Rotman Commerce", "university":"University of Toronto", "field":"Commerce",
            "description":"U of T's undergraduate commerce program, combining business study with the broader academic environment of the Faculty of Arts & Science.",
            "tags":["Business & Finance","Math","Leadership","Communication"],
            "requirements":["OSSD and six Grade 12 U/M courses including ENG4U and MCV4U","Rotman gives particular attention to Calculus and English","An overall mid-to-high-80s average or above is recommended; competitive English and Calculus grades are typically high 80s or above","Mandatory supplemental application"],
            "deadline":"January 15, 2027 (recommended early application: November 7, 2026)",
            "supplemental":"Mandatory Rotman Commerce supplemental. U of T lists February 1, 2027 as the supplemental deadline for 2027 admissions; early applicants are encouraged to submit available documents by December 1.",
            "when_to_apply":"U of T recommends applying by November 7 for early consideration. The final undergraduate application deadline is January 15, 2027.",
            "recommended_profile":["Strong overall Grade 12 performance, especially English and Calculus","Clear communication in the supplemental","Meaningful involvement outside class can give you stronger examples to discuss","Apply early enough to avoid rushing documents and supplemental work"],
            "admission_tips":["Treat the published academic guidance as a minimum planning reference, not a guaranteed cutoff","Prioritize ENG4U and MCV4U because Rotman specifically highlights them","Practice concise written and video communication","Use examples that show judgement, collaboration, initiative, or problem solving"],
            "timeline":["September–November: submit OUAC application; November 7 is recommended for early consideration","By December 1: early applicants should submit available supporting documents","January 15: final application deadline","February 1: Rotman supplemental/supporting-document deadline","February–May: admission decisions continue"],
            "related_careers":["Investment Banking","Accounting","Consulting","Marketing","Corporate Finance","Entrepreneurship"],
            "application_steps":["Apply through OUAC","Activate Join U of T","Complete the Rotman supplemental","Submit any requested documents","Monitor Join U of T for updates"],
            "application_method":"OUAC + Join U of T supplemental",
            "source":"https://rotmancommerce.utoronto.ca/future-students/ontario-applicants/"
        },
        {
            "id":"prog-smith", "title":"Smith Commerce", "university":"Queen's University", "field":"Commerce",
            "description":"Queen's Bachelor of Commerce program with prerequisite-course thresholds and a mandatory supplementary application.",
            "tags":["Business & Finance","Leadership","Communication"],
            "requirements":["OSSD and six Grade 12 4U/4M courses","ENG4U, MCV4U, and one additional 4U mathematics course","Minimum 80% in each of the three prerequisites","Mandatory supplementary application"],
            "deadline":"February 1, 2027",
            "supplemental":"Mandatory Commerce Supplementary Application due February 15, 2027.",
            "when_to_apply":"Apply through OUAC during Grade 12. Complete the main application before February 1 and leave enough time for the Commerce supplementary application due February 15.",
            "recommended_profile":["Meet every prerequisite threshold; falling below a required course minimum can end consideration","Keep your overall average comfortably above the published consideration level","Prepare thoughtful supplemental responses that are specific to your experiences"],
            "admission_tips":["Track all three prerequisite grades separately, not only your overall average","Give yourself time to reflect before the supplementary application","Use concise examples showing decisions, teamwork, contribution, or growth","Do not assume a very high average replaces the supplemental"],
            "timeline":["Fall: apply through OUAC and review Commerce prerequisites","January: verify prerequisite marks and prepare supplemental examples","February 1: application deadline","February 15: Commerce supplementary application deadline","Spring: monitor your applicant portal for decisions and conditions"],
            "related_careers":["Investment Banking","Consulting","Accounting","Marketing","Entrepreneurship"],
            "application_steps":["Apply through OUAC","Activate Queen's applicant portal","Complete the Commerce supplementary application","Submit any requested documents","Monitor your portal and maintain prerequisite grades"],
            "application_method":"OUAC + Queen's Commerce supplementary application",
            "source":"https://www.queensu.ca/admission/applying/admission-requirements/ontario"
        },
        {
            "id":"prog-utoronto-cs", "title":"Computer Science", "university":"University of Toronto — St. George", "field":"Technology",
            "description":"Computer Science admission category in U of T's Faculty of Arts & Science, with strong mathematics preparation and a required supplemental application.",
            "tags":["Technology","Math","Problem Solving"],
            "requirements":["OSSD with six Grade 12 U/M courses including ENG4U","MCV4U Calculus & Vectors","Computer Science supplemental application required","U of T's current viewbook lists an approximate low-90s grade requirement for the St. George Computer Science admission category"],
            "deadline":"January 15, 2027 (recommended early application: November 7, 2026)",
            "supplemental":"Computer Science Supplemental Application due February 1, 2027.",
            "when_to_apply":"Apply in the fall of Grade 12. U of T recommends November 7 for early consideration; the final application deadline is January 15.",
            "recommended_profile":["Strong Calculus performance and a high overall academic record","Evidence that you enjoy solving technical or analytical problems","Programming projects can help you confirm the field is a good fit, even when they are not formal admission prerequisites"],
            "admission_tips":["Do not neglect Calculus","Practice writing clearly about your experiences and decisions for the supplemental","Build programming experience before university so first-year courses are less unfamiliar","Apply early enough to leave time for the supplemental"],
            "timeline":["Grade 10–11: build math foundations and try programming","September–November of Grade 12: apply through OUAC","January 15: final application deadline","February 1: supplemental and supporting-document deadline","Spring: monitor decisions and maintain conditions"],
            "related_careers":["Software Engineering","Data Science","Cybersecurity","Product Management","AI / Machine Learning"],
            "application_steps":["Apply through OUAC","Activate Join U of T","Complete the Computer Science supplemental","Submit requested documents","Maintain prerequisite and conditional-offer grades"],
            "application_method":"OUAC + Join U of T supplemental",
            "source":"https://future.utoronto.ca/program/computer-science"
        },
        {
            "id":"prog-utoronto-compeng", "title":"Computer Engineering", "university":"University of Toronto — St. George", "field":"Engineering",
            "description":"Engineering program combining computing hardware, software, electronics, and systems design within U of T Engineering.",
            "tags":["Engineering","Technology","Math","Science","Problem Solving"],
            "requirements":["OSSD with six Grade 12 U/M courses including ENG4U","MHF4U Advanced Functions","MCV4U Calculus & Vectors","SCH4U Chemistry","SPH4U Physics","Engineering Online Student Profile required"],
            "deadline":"January 15, 2027 (recommended early application: November 7, 2026)",
            "supplemental":"Engineering Online Student Profile due January 15, 2027.",
            "when_to_apply":"Apply through OUAC during the fall. U of T recommends November 7 for early consideration; the Engineering application and Online Student Profile are due January 15.",
            "recommended_profile":["Strong performance across math, physics, chemistry, and English","Comfort with sustained problem solving","Technical projects, coding, robotics, electronics, or design work can help you understand the field and give you richer experiences"],
            "admission_tips":["Protect all five prerequisite courses because Engineering requires each of them","Build problem-solving habits rather than memorizing formulas","Use the Student Profile to communicate experiences clearly and honestly","Try a technical project before applying so you understand whether hardware/software systems interest you"],
            "timeline":["Grade 10–11: build strong math/science foundations","Fall of Grade 12: submit OUAC application","November 7: recommended early-application date","January 15: application and Online Student Profile deadline","Spring: maintain strong prerequisite results and monitor decisions"],
            "related_careers":["Software Engineering","Hardware Engineering","Embedded Systems","Cybersecurity","Product Engineering"],
            "application_steps":["Apply through OUAC","Activate Engineering Applicant Portal","Complete Online Student Profile","Submit any requested documents","Maintain prerequisite and conditional-offer grades"],
            "application_method":"OUAC + U of T Engineering Applicant Portal",
            "source":"https://future.utoronto.ca/program/computer-engineering"
        },
        {
            "id":"prog-waterloo-mech", "title":"Mechanical Engineering", "university":"University of Waterloo", "field":"Engineering",
            "description":"Co-op-only Bachelor of Applied Science program covering mechanics, thermodynamics, materials, design, manufacturing, control, and hands-on engineering practice.",
            "tags":["Engineering","Math","Physics","Problem Solving","Technology"],
            "requirements":["Six Grade 12 U/M courses","MHF4U Advanced Functions — minimum 70%","MCV4U Calculus & Vectors — minimum 70%","SCH4U Chemistry — minimum 70%","SPH4U Physics — minimum 70%","ENG4U English — minimum 70%","Admission Information Form and online interview required","Waterloo lists individual selection from the high 80s to low 90s"],
            "deadline":"January 15, 2027",
            "supplemental":"Engineering AIF, online interview, and required documents due February 1, 2027.",
            "when_to_apply":"Waterloo Engineering has one main application deadline for 2027: January 15. Do not wait until the deadline to begin the AIF and interview preparation.",
            "recommended_profile":["High-80s to low-90s academic performance is Waterloo's published competitive range for Mechanical Engineering","Strong math and physics preparation","Technical curiosity and evidence that you can work through open-ended problems","A thoughtful AIF with specific examples rather than generic activity lists"],
            "admission_tips":["Meet every 70% prerequisite minimum, but plan around the much higher competitive range","Start the AIF early and use concrete examples","Practice the online interview in a timed setting","Join design, robotics, maker, coding, engineering, or hands-on activities if they genuinely interest you","Use co-op as part of your career plan, not only as an admissions feature"],
            "timeline":["Fall: apply to Mechanical Engineering through OUAC","Before January: draft AIF examples and practice interview responses","January 15: Engineering application deadline","February 1: AIF, online interview, and document deadline","February–May: most admission decisions are released"],
            "related_careers":["Mechanical Engineer","Robotics Engineer","Manufacturing Engineer","Aerospace Engineer","Product Engineer"],
            "application_steps":["Apply directly to Mechanical Engineering through OUAC","Complete the AIF","Complete the required online interview","Submit required documents by February 1","Maintain prerequisite and conditional-offer grades"],
            "application_method":"OUAC + Waterloo AIF + online interview",
            "source":"https://uwaterloo.ca/future-students/programs/mechanical-engineering"
        },
        {
            "id":"prog-utoronto-healthbio", "title":"Biology for Health Sciences", "university":"University of Toronto Mississauga", "field":"Healthcare & Life Sciences",
            "description":"Health-focused biology major combining life-science study with preparation for research, healthcare-related graduate study, and other science pathways.",
            "tags":["Medicine & Health","Science","Biology","Research"],
            "requirements":["OSSD with six Grade 12 U/M courses including ENG4U","MHF4U Advanced Functions","SBI4U Biology","SCH4U Chemistry","MCV4U Calculus & Vectors is recommended"],
            "deadline":"January 15, 2027",
            "supplemental":"No program-specific supplemental is listed on U of T's program page; always confirm your applicant portal for requested documents.",
            "when_to_apply":"Apply through OUAC during Grade 12. U of T Mississauga lists January 15, 2027 as the application deadline.",
            "recommended_profile":["Strong Biology and Chemistry foundations","Solid mathematics preparation","Interest in laboratory, research, health, or biological systems","Understand that an undergraduate life-science degree is not the same as direct entry to a regulated health profession"],
            "admission_tips":["Prioritize prerequisite science grades","Build study habits for content-heavy university science courses","Explore healthcare and research careers before assuming medicine is the only outcome","Consider volunteering, research exposure, or science activities for career exploration—not as guaranteed admission advantages"],
            "timeline":["Grade 11: build biology, chemistry, and math foundations","Fall of Grade 12: apply through OUAC","January 15: U of T Mississauga application deadline","Winter/Spring: submit requested documents and maintain prerequisites","After admission: explore research, health, and professional-school pathways early"],
            "related_careers":["Registered Nurse","Physician","Research Scientist","Public Health","Biotechnology","Healthcare Administration"],
            "application_steps":["Apply through OUAC","Activate Join U of T","Submit any requested documents","Maintain required science and math courses","Use first year to explore specific health/science career pathways"],
            "application_method":"OUAC + Join U of T",
            "source":"https://future.utoronto.ca/program/biology-health-sciences"
        },
    ]

    for p in programs:
        con.execute(
            """INSERT INTO programs
            (id,title,subtitle,university,field,province,description,tags_json,requirements_json,deadline,supplemental,when_to_apply,recommended_profile_json,admission_tips_json,timeline_json,related_careers_json,application_steps_json,application_method,source_url,status,last_verified_date,featured,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              title=excluded.title,subtitle=excluded.subtitle,university=excluded.university,field=excluded.field,province=excluded.province,
              description=excluded.description,tags_json=excluded.tags_json,requirements_json=excluded.requirements_json,deadline=excluded.deadline,
              supplemental=excluded.supplemental,when_to_apply=excluded.when_to_apply,recommended_profile_json=excluded.recommended_profile_json,
              admission_tips_json=excluded.admission_tips_json,timeline_json=excluded.timeline_json,related_careers_json=excluded.related_careers_json,
              application_steps_json=excluded.application_steps_json,application_method=excluded.application_method,source_url=excluded.source_url,
              status=excluded.status,last_verified_date=excluded.last_verified_date,featured=excluded.featured,updated_at=excluded.updated_at""",
            (p["id"],p["title"],p["university"],p["university"],p["field"],"Ontario",p["description"],dumps(p["tags"]),
             dumps(p["requirements"]),p["deadline"],p["supplemental"],p["when_to_apply"],dumps(p["recommended_profile"]),
             dumps(p["admission_tips"]),dumps(p["timeline"]),dumps(p["related_careers"]),dumps(p["application_steps"]),p["application_method"],
             p["source"],"verified",verified_date,1 if p["id"] in {"prog-ivey","prog-rotman","prog-smith","prog-utoronto-cs","prog-waterloo-mech"} else 0,ts,ts),
        )

    # Keep the old placeholder health record out of the public feed now that a verified health-science record exists.
    con.execute("UPDATE programs SET status='archived',updated_at=? WHERE id='prog-mcmaster-health'", (ts,))
    con.execute("UPDATE programs SET status='archived',updated_at=? WHERE id='prog-waterloo-cs'", (ts,))

    scholarships = [
        {
            "id":"sch-loran-2027", "title":"2027 Loran Award", "subtitle":"National undergraduate award", "organization":"Loran Scholars Foundation",
            "amount":"Approximately $150,000 over four years",
            "description":"Four-year leadership-enrichment award combining financial support, mentorship, experiential learning, and a scholar community.",
            "tags":["Leadership","Community","Grade 12"],
            "eligibility":"High school applicants must be entering university for the first time in September 2027, have a minimum cumulative average of 88%, hold Canadian citizenship or permanent resident status, and meet the published age requirement.",
            "deadline":"October 15, 2026 at 12:00 p.m. ET",
            "source":"https://loranscholar.ca/the-program/how-to-apply/"
        },
        {
            "id":"sch-queens-maa-2027", "title":"Queen's Major Admission Awards", "subtitle":"Application-required entrance awards", "organization":"Queen's University",
            "amount":"Varies by award",
            "description":"A group of application-required admission awards for incoming Queen's students. Individual awards use their own academic, leadership, financial-need, nomination, and program criteria.",
            "tags":["Leadership","Academic","Grade 12"],
            "eligibility":"Eligibility varies by award. Applicants should review the official Major Admission Awards page and the criteria for each award before applying.",
            "deadline":"December 8, 2026",
            "source":"https://www.queensu.ca/registrar/financial-aid/application-required/future-students/major-awards"
        },
    ]
    con.execute("UPDATE scholarships SET status='archived',updated_at=? WHERE id LIKE 'sch-demo-%'", (ts,))
    for a in scholarships:
        con.execute(
            """INSERT INTO scholarships
            (id,title,subtitle,organization,amount,description,tags_json,eligibility,deadline,source_url,status,last_verified_date,featured,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,'verified',?,1,?,?)
            ON CONFLICT(id) DO UPDATE SET title=excluded.title,subtitle=excluded.subtitle,organization=excluded.organization,amount=excluded.amount,description=excluded.description,tags_json=excluded.tags_json,eligibility=excluded.eligibility,deadline=excluded.deadline,source_url=excluded.source_url,status='verified',last_verified_date=excluded.last_verified_date,featured=excluded.featured,updated_at=excluded.updated_at""",
            (a["id"],a["title"],a["subtitle"],a["organization"],a["amount"],a["description"],dumps(a["tags"]),a["eligibility"],a["deadline"],a["source"],verified_date,ts,ts),
        )
    con.commit()

def seed_admin(con: sqlite3.Connection) -> None:
    email = os.getenv("PATHWAY_ADMIN_EMAIL", "").strip().lower()
    password = os.getenv("PATHWAY_ADMIN_PASSWORD", "")
    if not email or not password:
        return
    existing = con.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
    if existing:
        con.execute("UPDATE users SET is_admin=1, updated_at=? WHERE id=?", (now_iso(), existing["id"]))
    else:
        ts = now_iso()
        con.execute(
            "INSERT INTO users(name,email,password_hash,onboarding_completed,is_admin,email_verified,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
            ("Pathway Admin", email, hash_password(password), 1, 1, 1, ts, ts),
        )
    con.commit()


@app.on_event("startup")
def startup() -> None:
    init_db()


class SignupIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: str
    password: str


class EmailIn(BaseModel):
    email: str = Field(min_length=5, max_length=254)


class PasswordResetConfirmIn(BaseModel):
    token: str = Field(min_length=20, max_length=500)
    password: str = Field(min_length=8, max_length=128)


class OnboardingIn(BaseModel):
    grade: str = Field(default="Grade 12", max_length=40)
    interests: list[str] = Field(default_factory=list, max_length=20)
    goals: list[str] = Field(default_factory=list, max_length=20)
    skills: list[str] = Field(default_factory=list, max_length=20)
    goal: str = Field(default="Explore careers", max_length=120)


class ProfileIn(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=80)
    grade: Optional[str] = Field(default=None, max_length=40)


class SaveIn(BaseModel):
    item_type: Literal["career", "program", "scholarship"]
    item_id: str


class ApplicationIn(BaseModel):
    program_id: Optional[str] = None
    institution: str = Field(min_length=1, max_length=160)
    program_name: str = Field(min_length=1, max_length=160)
    status: str = Field(default="Researching", max_length=40)
    deadline: Optional[str] = Field(default=None, max_length=40)
    notes: str = Field(default="", max_length=4000)


class ApplicationPatch(BaseModel):
    institution: Optional[str] = Field(default=None, max_length=160)
    program_name: Optional[str] = Field(default=None, max_length=160)
    status: Optional[str] = Field(default=None, max_length=40)
    deadline: Optional[str] = Field(default=None, max_length=40)
    notes: Optional[str] = Field(default=None, max_length=4000)


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=180)
    due_date: Optional[str] = Field(default=None, max_length=40)


class TaskPatch(BaseModel):
    title: Optional[str] = Field(default=None, max_length=180)
    due_date: Optional[str] = Field(default=None, max_length=40)
    completed: Optional[bool] = None


class PlanGenerateIn(BaseModel):
    item_type: Literal["career", "program"]
    item_id: str = Field(min_length=1, max_length=160)


class PlanTaskPatch(BaseModel):
    completed: bool


class CareerQuizIn(BaseModel):
    answers: list[str] = Field(default_factory=list, max_length=40)


class AdminContentIn(BaseModel):
    id: Optional[str] = Field(default=None, max_length=120)
    title: str = Field(min_length=1, max_length=180)
    subtitle: str = Field(default="", max_length=180)
    description: str = Field(default="", max_length=4000)
    tags: list[str] = Field(default_factory=list, max_length=30)
    source_url: Optional[str] = Field(default=None, max_length=1000)
    status: Literal["draft", "needs_review", "verified", "outdated", "archived"] = "needs_review"
    last_verified_date: Optional[str] = Field(default=None, max_length=40)
    featured: bool = False
    education: Optional[str] = Field(default=None, max_length=4000)
    day_to_day: Optional[str] = Field(default=None, max_length=4000)
    university: Optional[str] = Field(default=None, max_length=180)
    field: Optional[str] = Field(default=None, max_length=120)
    province: Optional[str] = Field(default="Ontario", max_length=120)
    requirements: list[str] = Field(default_factory=list, max_length=50)
    deadline: Optional[str] = Field(default=None, max_length=80)
    supplemental: Optional[str] = Field(default=None, max_length=2000)
    organization: Optional[str] = Field(default=None, max_length=180)
    amount: Optional[str] = Field(default=None, max_length=80)
    eligibility: Optional[str] = Field(default=None, max_length=4000)



_RATE_BUCKETS: dict[str, deque[float]] = defaultdict(deque)


def rate_limit(request: Request, bucket: str, limit: int, window_seconds: int) -> None:
    ip = request.client.host if request.client else "unknown"
    key = f"{bucket}:{ip}"
    now = time.time()
    q = _RATE_BUCKETS[key]
    while q and q[0] <= now - window_seconds:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="Too many requests. Please try again later.")
    q.append(now)


def create_auth_token(user_id: int, purpose: str, hours: int) -> str:
    raw = secrets.token_urlsafe(36)
    expires = datetime.now(timezone.utc) + timedelta(hours=hours)
    con = connect()
    con.execute("DELETE FROM auth_tokens WHERE user_id=? AND purpose=?", (user_id, purpose))
    con.execute(
        "INSERT INTO auth_tokens(token_hash,user_id,purpose,expires_at,created_at) VALUES(?,?,?,?,?)",
        (token_hash(raw), user_id, purpose, expires.replace(microsecond=0).isoformat(), now_iso()),
    )
    con.commit(); con.close()
    return raw


def consume_auth_token(raw: str, purpose: str) -> Optional[int]:
    con = connect()
    row = con.execute(
        "SELECT * FROM auth_tokens WHERE token_hash=? AND purpose=? AND used_at IS NULL AND expires_at>?",
        (token_hash(raw), purpose, now_iso()),
    ).fetchone()
    if not row:
        con.close(); return None
    con.execute("UPDATE auth_tokens SET used_at=? WHERE token_hash=?", (now_iso(), token_hash(raw)))
    con.commit(); con.close()
    return int(row["user_id"])


def send_email(to_email: str, subject: str, text_body: str) -> None:
    """Send through SMTP when configured; otherwise write the exact message to a local dev outbox."""
    if SMTP_HOST:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = SMTP_FROM
        msg["To"] = to_email
        msg.set_content(text_body)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
            if SMTP_USE_TLS:
                server.starttls()
            if SMTP_USERNAME:
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
        return
    OUTBOX_PATH.parent.mkdir(parents=True, exist_ok=True)
    with OUTBOX_PATH.open("a", encoding="utf-8") as f:
        f.write(f"\n--- {now_iso()} ---\nTO: {to_email}\nSUBJECT: {subject}\n{text_body}\n")


def issue_verification_email(user_id: int, email: str) -> None:
    raw = create_auth_token(user_id, "verify_email", EMAIL_TOKEN_HOURS)
    link = f"{APP_BASE_URL}/?verify={raw}"
    send_email(email, "Verify your Pathway email", f"Verify your Pathway email by opening this link:\n\n{link}\n\nThis link expires in {EMAIL_TOKEN_HOURS} hours.")


def issue_reset_email(user_id: int, email: str) -> None:
    raw = create_auth_token(user_id, "password_reset", RESET_TOKEN_HOURS)
    link = f"{APP_BASE_URL}/?reset={raw}"
    send_email(email, "Reset your Pathway password", f"Reset your Pathway password by opening this link:\n\n{link}\n\nThis link expires in {RESET_TOKEN_HOURS} hour(s). If you did not request this, ignore this email.")


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # Same-origin protection for cookie-authenticated state-changing requests.
    if request.method in {"POST", "PUT", "PATCH", "DELETE"} and request.url.path.startswith("/api/"):
        origin = request.headers.get("origin")
        if origin and origin.rstrip("/") != APP_BASE_URL:
            return HTMLResponse("Invalid request origin", status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if COOKIE_SECURE:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

def get_user_from_cookie(pathway_session: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE)) -> Optional[dict[str, Any]]:
    if not pathway_session:
        return None
    con = connect()
    row = con.execute(
        """SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
           WHERE s.token_hash=? AND s.expires_at>?""",
        (token_hash(pathway_session), now_iso()),
    ).fetchone()
    con.close()
    return serialize_user(row) if row else None


def require_user(user: Optional[dict[str, Any]] = Depends(get_user_from_cookie)) -> dict[str, Any]:
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


def require_admin(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    if not user["is_admin"]:
        raise HTTPException(status_code=403, detail="Administrator access required")
    return user


def create_session(response: Response, user_id: int) -> None:
    raw = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    con = connect()
    con.execute("DELETE FROM sessions WHERE user_id=? OR expires_at<=?", (user_id, now_iso()))
    con.execute(
        "INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
        (token_hash(raw), user_id, expires.replace(microsecond=0).isoformat(), now_iso()),
    )
    con.commit()
    con.close()
    response.set_cookie(
        SESSION_COOKIE,
        raw,
        max_age=SESSION_DAYS * 86400,
        httponly=True,
        samesite="lax",
        secure=COOKIE_SECURE,
        path="/",
    )


def clean_email(value: str) -> str:
    email = value.strip().lower()
    if "@" not in email or "." not in email.rsplit("@", 1)[-1]:
        raise HTTPException(status_code=422, detail="Enter a valid email address")
    return email


@app.get("/")
def index() -> FileResponse:
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/privacy")
def privacy_page() -> FileResponse:
    return FileResponse(ROOT / "static" / "privacy.html")


@app.get("/terms")
def terms_page() -> FileResponse:
    return FileResponse(ROOT / "static" / "terms.html")


@app.get("/api/health")
def health() -> dict[str, Any]:
    try:
        con = connect(); con.execute("SELECT 1").fetchone(); con.close()
        db = "ok"
    except Exception:
        db = "error"
    return {"status": "ok" if db == "ok" else "degraded", "database": db, "version": APP_VERSION, "time": now_iso()}


@app.post("/api/auth/signup", status_code=201)
def signup(payload: SignupIn, response: Response, request: Request) -> dict[str, Any]:
    rate_limit(request, "signup", 8, 900)
    email = clean_email(payload.email)
    con = connect()
    if con.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
        con.close()
        raise HTTPException(status_code=409, detail="An account already exists with this email")
    ts = now_iso()
    cur = con.execute(
        "INSERT INTO users(name,email,password_hash,created_at,updated_at) VALUES(?,?,?,?,?)",
        (payload.name.strip(), email, hash_password(payload.password), ts, ts),
    )
    con.commit()
    row = con.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    con.close()
    create_session(response, row["id"])
    try:
        issue_verification_email(row["id"], email)
    except Exception:
        # Account creation should still succeed if an email provider is temporarily unavailable.
        pass
    return {"user": serialize_user(row), "verification_sent": True}


@app.post("/api/auth/login")
def login(payload: LoginIn, response: Response, request: Request) -> dict[str, Any]:
    rate_limit(request, "login", 12, 900)
    email = clean_email(payload.email)
    con = connect()
    row = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    con.close()
    if not row or not verify_password(payload.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    create_session(response, row["id"])
    return {"user": serialize_user(row)}



@app.post("/api/auth/resend-verification")
def resend_verification(request: Request, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    rate_limit(request, "resend-verification", 4, 3600)
    if user.get("email_verified"):
        return {"ok": True}
    issue_verification_email(user["id"], user["email"])
    return {"ok": True}


@app.post("/api/auth/verify-email")
def verify_email(payload: dict[str, str], request: Request) -> dict[str, bool]:
    rate_limit(request, "verify-email", 20, 3600)
    raw = (payload.get("token") or "").strip()
    if not raw:
        raise HTTPException(status_code=422, detail="Verification token required")
    user_id = consume_auth_token(raw, "verify_email")
    if not user_id:
        raise HTTPException(status_code=400, detail="This verification link is invalid or has expired")
    con = connect()
    con.execute("UPDATE users SET email_verified=1,updated_at=? WHERE id=?", (now_iso(), user_id))
    con.commit(); con.close()
    return {"ok": True}


@app.post("/api/auth/password-reset/request")
def request_password_reset(payload: EmailIn, request: Request) -> dict[str, bool]:
    rate_limit(request, "password-reset-request", 5, 3600)
    email = clean_email(payload.email)
    con = connect(); row = con.execute("SELECT id,email FROM users WHERE email=?", (email,)).fetchone(); con.close()
    if row:
        try:
            issue_reset_email(row["id"], row["email"])
        except Exception:
            pass
    # Do not reveal whether an address has an account.
    return {"ok": True}


@app.post("/api/auth/password-reset/confirm")
def confirm_password_reset(payload: PasswordResetConfirmIn, request: Request) -> dict[str, bool]:
    rate_limit(request, "password-reset-confirm", 10, 3600)
    user_id = consume_auth_token(payload.token, "password_reset")
    if not user_id:
        raise HTTPException(status_code=400, detail="This reset link is invalid or has expired")
    con = connect()
    con.execute("UPDATE users SET password_hash=?,updated_at=? WHERE id=?", (hash_password(payload.password), now_iso(), user_id))
    con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
    con.commit(); con.close()
    return {"ok": True}


@app.post("/api/auth/logout")
def logout(response: Response, pathway_session: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE)) -> dict[str, bool]:
    if pathway_session:
        con = connect()
        con.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(pathway_session),))
        con.commit()
        con.close()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@app.get("/api/me")
def me(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    return {"user": user}


@app.patch("/api/me")
def update_me(payload: ProfileIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    fields, params = [], []
    if payload.name is not None:
        fields.append("name=?")
        params.append(payload.name.strip())
    if payload.grade is not None:
        fields.append("grade=?")
        params.append(payload.grade.strip())
    if fields:
        fields.append("updated_at=?")
        params.append(now_iso())
        params.append(user["id"])
        con = connect()
        con.execute(f"UPDATE users SET {', '.join(fields)} WHERE id=?", params)
        con.commit()
        row = con.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        con.close()
        return {"user": serialize_user(row)}
    return {"user": user}



@app.delete("/api/me")
def delete_account(response: Response, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    con.execute("DELETE FROM users WHERE id=?", (user["id"],))
    con.commit(); con.close()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@app.put("/api/me/onboarding")
def onboarding(payload: OnboardingIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    interests = [x.strip() for x in payload.interests if x.strip()][:20]
    goals = [x.strip() for x in payload.goals if x.strip()][:20]
    skills = [x.strip() for x in payload.skills if x.strip()][:20]
    primary_goal = (goals[0] if goals else payload.goal).strip() or "Explore careers"
    con = connect()
    con.execute(
        "UPDATE users SET grade=?,interests_json=?,goals_json=?,skills_json=?,goal=?,onboarding_completed=1,updated_at=? WHERE id=?",
        (payload.grade.strip(), dumps(interests), dumps(goals), dumps(skills), primary_goal, now_iso(), user["id"]),
    )
    con.commit()
    row = con.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    con.close()
    return {"user": serialize_user(row)}


def get_table(content_type: str) -> str:
    mapping = {"career": "careers", "program": "programs", "scholarship": "scholarships"}
    if content_type not in mapping:
        raise HTTPException(status_code=404, detail="Unknown content type")
    return mapping[content_type]


@app.get("/api/content")
def list_content(
    type: Optional[Literal["career", "program", "scholarship"]] = None,
    q: str = "",
    include_preview: bool = False,
    user: Optional[dict[str, Any]] = Depends(get_user_from_cookie),
) -> dict[str, Any]:
    types = [type] if type else ["career", "program", "scholarship"]
    result: list[dict[str, Any]] = []
    can_preview = bool(include_preview and user and user.get("is_admin"))
    con = connect()
    for t in types:
        table = get_table(t)
        if can_preview or t == "career":
            where = ["status != 'archived'"]
        else:
            where = ["status='verified'"]
        params: list[Any] = []
        if q.strip():
            where.append("(title LIKE ? OR subtitle LIKE ? OR description LIKE ? OR tags_json LIKE ?)")
            needle = f"%{q.strip()}%"
            params.extend([needle, needle, needle, needle])
        rows = con.execute(f"SELECT * FROM {table} WHERE {' AND '.join(where)} ORDER BY featured DESC, title COLLATE NOCASE", params).fetchall()
        result.extend(content_row_to_dict(r, t) for r in rows)
    con.close()
    return {"items": result}


@app.get("/api/content/{content_type}/{item_id}")
def content_detail(content_type: str, item_id: str, user: Optional[dict[str, Any]] = Depends(get_user_from_cookie)) -> dict[str, Any]:
    table = get_table(content_type)
    con = connect()
    row = con.execute(f"SELECT * FROM {table} WHERE id=? AND status!='archived'", (item_id,)).fetchone()
    con.close()
    if not row:
        raise HTTPException(status_code=404, detail="Item not found")
    if content_type in {"program", "scholarship"} and row["status"] != "verified" and not (user and user.get("is_admin")):
        raise HTTPException(status_code=404, detail="Item not found")
    return {"item": content_row_to_dict(row, content_type)}


@app.get("/api/saved")
def saved(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    rows = con.execute("SELECT item_type,item_id,created_at FROM saved_items WHERE user_id=? ORDER BY created_at DESC", (user["id"],)).fetchall()
    con.close()
    return {"items": [dict(r) for r in rows]}


@app.post("/api/saved", status_code=201)
def save_item(payload: SaveIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    table = get_table(payload.item_type)
    con = connect()
    if not con.execute(f"SELECT 1 FROM {table} WHERE id=? AND status!='archived'", (payload.item_id,)).fetchone():
        con.close()
        raise HTTPException(status_code=404, detail="Item not found")
    con.execute(
        "INSERT OR IGNORE INTO saved_items(user_id,item_type,item_id,created_at) VALUES(?,?,?,?)",
        (user["id"], payload.item_type, payload.item_id, now_iso()),
    )
    con.commit()
    con.close()
    return {"ok": True}


@app.delete("/api/saved/{item_type}/{item_id}")
def unsave_item(item_type: Literal["career", "program", "scholarship"], item_id: str, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    con.execute("DELETE FROM saved_items WHERE user_id=? AND item_type=? AND item_id=?", (user["id"], item_type, item_id))
    con.commit()
    con.close()
    return {"ok": True}


def score_item(item: dict[str, Any], user: dict[str, Any]) -> tuple[int, str]:
    interests = set(user.get("interests") or [])
    skills = set(user.get("skills") or [])
    goals = [str(x).lower() for x in (user.get("goals") or [user.get("goal") or ""])]
    tags = set(item.get("tags") or [])
    career_skills = set(item.get("skills") or [])
    interest_matches = sorted(interests.intersection(tags))
    skill_matches = sorted(skills.intersection(career_skills.union(tags)))
    score = 34 * len(interest_matches) + 14 * len(skill_matches)
    if item["type"] == "scholarship" and any("scholar" in g for g in goals):
        score += 24
    if item["type"] == "program" and any("program" in g or "university" in g for g in goals):
        score += 24
    if item["type"] == "career" and any("career" in g or "path" in g for g in goals):
        score += 24
    if interest_matches and skill_matches:
        reason = f"Matches your interests in {', '.join(interest_matches[:2])} and strengths such as {', '.join(skill_matches[:2])}."
    elif interest_matches:
        reason = "Matches your interests in " + " and ".join(interest_matches[:2]) + "."
    elif skill_matches:
        reason = "Connects with strengths you selected, including " + " and ".join(skill_matches[:2]) + "."
    else:
        reason = "Included as another option that may be worth exploring."
    return score, reason


@app.get("/api/recommendations")
def recommendations(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    items = list_content(include_preview=False, user=user)["items"]
    scored = []
    for item in items:
        score, reason = score_item(item, user)
        scored.append({**item, "score": score, "reason_text": reason})
    scored.sort(key=lambda x: (-x["score"], x["title"].lower()))
    return {"items": scored[:12]}



def career_quiz_score(item: dict[str, Any], answers: list[str]) -> tuple[int, list[str]]:
    selected = {x.strip() for x in answers if x.strip()}
    traits = set(item.get("tags") or []).union(set(item.get("skills") or []))
    matches = sorted(selected.intersection(traits))
    score = len(matches) * 18
    # A small industry-level bonus helps broad answers like "Healthcare" match directly.
    if item.get("industry") in selected or item.get("subtitle") in selected:
        score += 24
        if item.get("industry") not in matches:
            matches.insert(0, item.get("industry"))
    return score, matches[:5]


@app.post("/api/career-quiz")
def career_quiz(payload: CareerQuizIn, user: Optional[dict[str, Any]] = Depends(get_user_from_cookie)) -> dict[str, Any]:
    careers = list_content(type="career", include_preview=False, user=user)["items"]
    ranked = []
    for career in careers:
        score, matches = career_quiz_score(career, payload.answers)
        ranked.append({
            **career,
            "quiz_score": score,
            "quiz_matches": matches,
            "quiz_reason": ("Strong overlap with " + ", ".join(matches[:3]) + ".") if matches else "Worth exploring as a contrast to your current answers.",
        })
    ranked.sort(key=lambda x: (-x["quiz_score"], x["title"].lower()))
    return {"items": ranked[:6]}


def build_plan_tasks(item: dict[str, Any], user: dict[str, Any]) -> list[tuple[str, str, int]]:
    stage = (user.get("grade") or "").lower()
    user_skills = set(user.get("skills") or [])
    tasks: list[tuple[str, str, int]] = []

    if item["type"] == "career":
        required_skills = item.get("skills") or []
        missing = [x for x in required_skills if x not in user_skills][:3]
        for skill in missing:
            tasks.append((f"Build your {skill.lower()} skills with a course, project, club, or real responsibility.", "Skills", 1))
        for subject in (item.get("school_subjects") or [])[:3]:
            tasks.append((f"Strengthen {subject} if it is relevant to your current school stage.", "Academics", 1))
        if any(x in stage for x in ["11", "12", "college", "university", "career"]):
            tasks.append(("Find one realistic experience connected to this field: job shadowing, a project, volunteering, a competition, research, co-op, or an internship.", "Experience", 1))
        else:
            tasks.append(("Try one small project or activity that lets you experience this field before making a long-term decision.", "Explore", 1))
        for tip in (item.get("success_tips") or [])[:3]:
            tasks.append((tip, "Career preparation", 2))
        tasks.append(("Read the full career profile again after you have tried one related experience and decide whether the daily work still interests you.", "Reflection", 3))

    elif item["type"] == "program":
        for req in (item.get("requirements") or [])[:4]:
            tasks.append((f"Confirm: {req}", "Admission requirement", 1))
        if item.get("when_to_apply"):
            tasks.append((item["when_to_apply"], "Application timing", 1))
        for tip in (item.get("admission_tips") or [])[:3]:
            tasks.append((tip, "Strengthen application", 2))
        if item.get("deadline"):
            tasks.append((f"Add the application deadline to your calendar: {item['deadline']}", "Deadline", 1))
        tasks.append(("Open the official program page before submitting anything and confirm that requirements and dates have not changed.", "Verify", 1))

    # Deduplicate while keeping order.
    seen = set()
    out = []
    for title, category, priority in tasks:
        key = title.strip().lower()
        if key and key not in seen:
            seen.add(key)
            out.append((title.strip(), category, priority))
    return out[:12]


@app.get("/api/plan/tasks")
def list_plan_tasks(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    rows = con.execute(
        "SELECT id,item_type,item_id,title,category,completed,priority,sort_order,created_at FROM plan_tasks WHERE user_id=? ORDER BY completed,priority,sort_order,id",
        (user["id"],),
    ).fetchall()
    con.close()
    return {"items": [{**dict(r), "completed": bool(r["completed"])} for r in rows]}


@app.post("/api/plan/generate", status_code=201)
def generate_plan(payload: PlanGenerateIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    table = get_table(payload.item_type)
    con = connect()
    row = con.execute(f"SELECT * FROM {table} WHERE id=? AND status!='archived'", (payload.item_id,)).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Item not found")
    item = content_row_to_dict(row, payload.item_type)
    tasks = build_plan_tasks(item, user)
    for i, (title, category, priority) in enumerate(tasks):
        con.execute(
            "INSERT OR IGNORE INTO plan_tasks(user_id,item_type,item_id,title,category,completed,priority,sort_order,created_at) VALUES(?,?,?,?,?,0,?,?,?)",
            (user["id"], payload.item_type, payload.item_id, title, category, priority, i, now_iso()),
        )
    con.commit()
    rows = con.execute(
        "SELECT id,item_type,item_id,title,category,completed,priority,sort_order,created_at FROM plan_tasks WHERE user_id=? AND item_type=? AND item_id=? ORDER BY priority,sort_order,id",
        (user["id"], payload.item_type, payload.item_id),
    ).fetchall()
    con.close()
    return {"items": [{**dict(r), "completed": bool(r["completed"])} for r in rows]}


@app.patch("/api/plan/tasks/{task_id}")
def update_plan_task(task_id: int, payload: PlanTaskPatch, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    row = con.execute("SELECT id FROM plan_tasks WHERE id=? AND user_id=?", (task_id, user["id"])).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Task not found")
    con.execute("UPDATE plan_tasks SET completed=? WHERE id=?", (1 if payload.completed else 0, task_id))
    con.commit(); con.close()
    return {"ok": True}


@app.delete("/api/plan/tasks/{task_id}")
def delete_plan_task(task_id: int, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    con.execute("DELETE FROM plan_tasks WHERE id=? AND user_id=?", (task_id, user["id"]))
    con.commit(); con.close()
    return {"ok": True}


def serialize_application(con: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    tasks = con.execute(
        "SELECT id,title,completed,due_date,sort_order FROM application_tasks WHERE application_id=? ORDER BY sort_order,id",
        (row["id"],),
    ).fetchall()
    return {
        "id": row["id"],
        "program_id": row["program_id"],
        "institution": row["institution"],
        "program_name": row["program_name"],
        "status": row["status"],
        "deadline": row["deadline"],
        "notes": row["notes"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "tasks": [{**dict(t), "completed": bool(t["completed"])} for t in tasks],
    }


@app.get("/api/applications")
def list_applications(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    rows = con.execute("SELECT * FROM applications WHERE user_id=? ORDER BY updated_at DESC", (user["id"],)).fetchall()
    result = [serialize_application(con, r) for r in rows]
    con.close()
    return {"items": result}


@app.post("/api/applications", status_code=201)
def create_application(payload: ApplicationIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    ts = now_iso()
    con = connect()
    cur = con.execute(
        """INSERT INTO applications(user_id,program_id,institution,program_name,status,deadline,notes,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?)""",
        (user["id"], payload.program_id, payload.institution.strip(), payload.program_name.strip(), payload.status, payload.deadline, payload.notes, ts, ts),
    )
    app_id = cur.lastrowid
    for i, title in enumerate(["Review official requirements", "Prepare required documents", "Complete supplemental requirements", "Submit application"]):
        con.execute("INSERT INTO application_tasks(application_id,title,sort_order) VALUES(?,?,?)", (app_id, title, i))
    con.commit()
    row = con.execute("SELECT * FROM applications WHERE id=?", (app_id,)).fetchone()
    result = serialize_application(con, row)
    con.close()
    return {"application": result}


@app.patch("/api/applications/{application_id}")
def update_application(application_id: int, payload: ApplicationPatch, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    row = con.execute("SELECT * FROM applications WHERE id=? AND user_id=?", (application_id, user["id"])).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Application not found")
    fields, params = [], []
    for field in ["institution", "program_name", "status", "deadline", "notes"]:
        value = getattr(payload, field)
        if value is not None:
            fields.append(f"{field}=?")
            params.append(value)
    if fields:
        fields.append("updated_at=?")
        params.extend([now_iso(), application_id, user["id"]])
        con.execute(f"UPDATE applications SET {', '.join(fields)} WHERE id=? AND user_id=?", params)
        con.commit()
    row = con.execute("SELECT * FROM applications WHERE id=?", (application_id,)).fetchone()
    result = serialize_application(con, row)
    con.close()
    return {"application": result}


@app.delete("/api/applications/{application_id}")
def delete_application(application_id: int, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    cur = con.execute("DELETE FROM applications WHERE id=? AND user_id=?", (application_id, user["id"]))
    con.commit()
    con.close()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Application not found")
    return {"ok": True}


@app.post("/api/applications/{application_id}/tasks", status_code=201)
def add_task(application_id: int, payload: TaskIn, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    if not con.execute("SELECT 1 FROM applications WHERE id=? AND user_id=?", (application_id, user["id"])).fetchone():
        con.close()
        raise HTTPException(status_code=404, detail="Application not found")
    order = con.execute("SELECT COALESCE(MAX(sort_order),-1)+1 AS n FROM application_tasks WHERE application_id=?", (application_id,)).fetchone()["n"]
    cur = con.execute("INSERT INTO application_tasks(application_id,title,due_date,sort_order) VALUES(?,?,?,?)", (application_id,payload.title.strip(),payload.due_date,order))
    con.commit()
    row = con.execute("SELECT id,title,completed,due_date,sort_order FROM application_tasks WHERE id=?", (cur.lastrowid,)).fetchone()
    con.close()
    return {"task": {**dict(row), "completed": bool(row["completed"])}}


@app.patch("/api/tasks/{task_id}")
def update_task(task_id: int, payload: TaskPatch, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    con = connect()
    row = con.execute(
        """SELECT t.* FROM application_tasks t JOIN applications a ON a.id=t.application_id
           WHERE t.id=? AND a.user_id=?""",
        (task_id, user["id"]),
    ).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Task not found")
    fields, params = [], []
    if payload.title is not None:
        fields.append("title=?"); params.append(payload.title)
    if payload.due_date is not None:
        fields.append("due_date=?"); params.append(payload.due_date)
    if payload.completed is not None:
        fields.append("completed=?"); params.append(1 if payload.completed else 0)
    if fields:
        params.append(task_id)
        con.execute(f"UPDATE application_tasks SET {', '.join(fields)} WHERE id=?", params)
        con.execute("UPDATE applications SET updated_at=? WHERE id=?", (now_iso(), row["application_id"]))
        con.commit()
    row = con.execute("SELECT id,title,completed,due_date,sort_order FROM application_tasks WHERE id=?", (task_id,)).fetchone()
    con.close()
    return {"task": {**dict(row), "completed": bool(row["completed"])}}


@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    con = connect()
    row = con.execute(
        """SELECT t.id FROM application_tasks t JOIN applications a ON a.id=t.application_id
           WHERE t.id=? AND a.user_id=?""",
        (task_id, user["id"]),
    ).fetchone()
    if not row:
        con.close()
        raise HTTPException(status_code=404, detail="Task not found")
    con.execute("DELETE FROM application_tasks WHERE id=?", (task_id,))
    con.commit(); con.close()
    return {"ok": True}


def validate_verified(payload: AdminContentIn) -> None:
    if payload.status == "verified" and (not payload.source_url or not payload.last_verified_date):
        raise HTTPException(status_code=422, detail="Verified records require an official source URL and verification date")


def admin_write(content_type: str, payload: AdminContentIn, admin: dict[str, Any], item_id: Optional[str] = None) -> dict[str, Any]:
    validate_verified(payload)
    table = get_table(content_type)
    item_id = item_id or payload.id or f"{content_type}-{secrets.token_hex(6)}"
    ts = now_iso()
    con = connect()
    existing = con.execute(f"SELECT 1 FROM {table} WHERE id=?", (item_id,)).fetchone()
    common = (payload.title.strip(), payload.subtitle.strip(), payload.description.strip(), dumps(payload.tags), payload.source_url, payload.status, payload.last_verified_date, 1 if payload.featured else 0, ts)
    if content_type == "career":
        if existing:
            con.execute("""UPDATE careers SET title=?,subtitle=?,description=?,tags_json=?,source_url=?,status=?,last_verified_date=?,featured=?,updated_at=?,education=?,day_to_day=? WHERE id=?""", (*common,payload.education or "",payload.day_to_day or "",item_id))
        else:
            con.execute("""INSERT INTO careers(id,title,subtitle,description,tags_json,source_url,status,last_verified_date,featured,updated_at,education,day_to_day,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (item_id,*common,payload.education or "",payload.day_to_day or "",ts,))
    elif content_type == "program":
        if existing:
            con.execute("""UPDATE programs SET title=?,subtitle=?,description=?,tags_json=?,source_url=?,status=?,last_verified_date=?,featured=?,updated_at=?,university=?,field=?,province=?,requirements_json=?,deadline=?,supplemental=? WHERE id=?""", (*common,payload.university or payload.subtitle,payload.field or "",payload.province or "Ontario",dumps(payload.requirements),payload.deadline,payload.supplemental,item_id))
        else:
            con.execute("""INSERT INTO programs(id,title,subtitle,description,tags_json,source_url,status,last_verified_date,featured,updated_at,university,field,province,requirements_json,deadline,supplemental,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (item_id,*common,payload.university or payload.subtitle,payload.field or "",payload.province or "Ontario",dumps(payload.requirements),payload.deadline,payload.supplemental,ts))
    else:
        if existing:
            con.execute("""UPDATE scholarships SET title=?,subtitle=?,description=?,tags_json=?,source_url=?,status=?,last_verified_date=?,featured=?,updated_at=?,organization=?,amount=?,eligibility=?,deadline=? WHERE id=?""", (*common,payload.organization or "",payload.amount,payload.eligibility or "",payload.deadline,item_id))
        else:
            con.execute("""INSERT INTO scholarships(id,title,subtitle,description,tags_json,source_url,status,last_verified_date,featured,updated_at,organization,amount,eligibility,deadline,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (item_id,*common,payload.organization or "",payload.amount,payload.eligibility or "",payload.deadline,ts))
    con.execute("INSERT INTO content_change_log(admin_user_id,item_type,item_id,action,created_at) VALUES(?,?,?,?,?)", (admin["id"],content_type,item_id,"updated" if existing else "created",ts))
    con.commit()
    row = con.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
    result = content_row_to_dict(row, content_type)
    con.close()
    return result


@app.get("/api/admin/stats")
def admin_stats(admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    con = connect()
    stats = {
        "users": con.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"],
        "careers": con.execute("SELECT COUNT(*) AS n FROM careers WHERE status!='archived'").fetchone()["n"],
        "programs": con.execute("SELECT COUNT(*) AS n FROM programs WHERE status!='archived'").fetchone()["n"],
        "scholarships": con.execute("SELECT COUNT(*) AS n FROM scholarships WHERE status!='archived'").fetchone()["n"],
        "needs_review": sum(con.execute(f"SELECT COUNT(*) AS n FROM {t} WHERE status='needs_review'").fetchone()["n"] for t in ["careers","programs","scholarships"]),
    }
    con.close()
    return stats


@app.post("/api/admin/content/{content_type}", status_code=201)
def admin_create(content_type: Literal["career", "program", "scholarship"], payload: AdminContentIn, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return {"item": admin_write(content_type, payload, admin)}


@app.put("/api/admin/content/{content_type}/{item_id}")
def admin_update(content_type: Literal["career", "program", "scholarship"], item_id: str, payload: AdminContentIn, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return {"item": admin_write(content_type, payload, admin, item_id)}


@app.delete("/api/admin/content/{content_type}/{item_id}")
def admin_archive(content_type: Literal["career", "program", "scholarship"], item_id: str, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    table = get_table(content_type)
    con = connect()
    cur = con.execute(f"UPDATE {table} SET status='archived',updated_at=? WHERE id=?", (now_iso(),item_id))
    if cur.rowcount:
        con.execute("INSERT INTO content_change_log(admin_user_id,item_type,item_id,action,created_at) VALUES(?,?,?,?,?)", (admin["id"],content_type,item_id,"archived",now_iso()))
    con.commit(); con.close()
    if not cur.rowcount:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"ok": True}


@app.get("/api/admin/change-log")
def admin_log(admin: dict[str, Any] = Depends(require_admin), limit: int = Query(default=50, ge=1, le=200)) -> dict[str, Any]:
    con = connect()
    rows = con.execute("""SELECT l.*,u.email AS admin_email FROM content_change_log l JOIN users u ON u.id=l.admin_user_id ORDER BY l.id DESC LIMIT ?""", (limit,)).fetchall()
    con.close()
    return {"items": [dict(r) for r in rows]}


@app.get("/{path:path}")
def spa_fallback(path: str) -> FileResponse:
    if path.startswith("api/"):
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(ROOT / "static" / "index.html")
