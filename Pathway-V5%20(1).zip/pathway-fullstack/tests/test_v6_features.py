import importlib
import os
import tempfile
from pathlib import Path


def test_career_match_and_personal_plan():
    tmp=tempfile.NamedTemporaryFile(suffix='.db',delete=False);tmp.close()
    outbox=Path(tmp.name+'.outbox')
    os.environ['PATHWAY_DB_PATH']=tmp.name
    os.environ['PATHWAY_OUTBOX_PATH']=str(outbox)
    os.environ['PATHWAY_BASE_URL']='http://testserver'
    try:
        from fastapi.testclient import TestClient
        import app as app_module
        importlib.reload(app_module)
        with TestClient(app_module.app) as client:
            content=client.get('/api/content').json()['items']
            finance=next(x for x in content if x['id']=='career-finance')
            assert finance['pay_range']
            assert len(finance['levels']) >= 4
            cs=next(x for x in content if x['id']=='prog-utoronto-cs')
            assert cs['when_to_apply']
            assert cs['application_steps']

            assert client.post('/api/auth/signup',json={'name':'Student','email':'v6@example.com','password':'strongpass123'}).status_code==201
            onboard=client.put('/api/me/onboarding',json={
                'grade':'Grade 11',
                'interests':['Technology','Engineering'],
                'goals':['Explore careers','Find university programs'],
                'skills':['Math','Problem Solving']
            })
            assert onboard.status_code==200
            assert len(onboard.json()['user']['goals'])==2

            quiz=client.post('/api/career-quiz',json={'answers':['Technology','Math','Problem Solving']})
            assert quiz.status_code==200
            assert quiz.json()['items'][0]['title']=='Software Engineering'

            generated=client.post('/api/plan/generate',json={'item_type':'career','item_id':'career-software'})
            assert generated.status_code==201
            assert len(generated.json()['items']) >= 5
            task_id=generated.json()['items'][0]['id']
            assert client.patch(f'/api/plan/tasks/{task_id}',json={'completed':True}).status_code==200
            tasks=client.get('/api/plan/tasks').json()['items']
            assert any(t['id']==task_id and t['completed'] for t in tasks)
    finally:
        Path(tmp.name).unlink(missing_ok=True);outbox.unlink(missing_ok=True)
